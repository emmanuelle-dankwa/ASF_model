################################################################
# INFECTIOUS PRESSURE ON HERDS GIVEN WILD BOAR MODEL ESTIMATES #
#                 ASF CHALLENGE - UK TEAM                      #
#                                                              #
#                     Phase 2 - 2020/11/23                     #
################################################################



rm(list = ls()) # remove (almost) everything in the working environment

# Set to your working directory
wd = "~/pig_herd_component/Phase2"

###########
# LIBRARY #
###########

library(sp)    # R Package: point.in.polygon function
library(tidyr) # R Package: crossing function

########
# DATA #
########

# Set working directory
setwd(paste(wd, "/Data_Outbreak", sep = ""))
herds =  read.csv("herds_day_80.csv")


##############
# PARAMETERS #
##############

fence   = TRUE  # Scenario: fencing
increas = FALSE # Scenario: increased hunting pressure on wild boars inside the fence

# Set working directory
setwd(paste(wd, "/Model_Predict/input", sep = ""))

patchcentres = readRDS("patchcentres.RDS")
npatches_x = npatches_y =  nrow(patchcentres)
patchcentres_x = patchcentres$X
patchcentres_y = patchcentres$Y


##############################
# IMPORT WILD BOAR ESTIMATES #
##############################

# Set working directory
setwd(paste(wd, "/Model_Predict/input", sep = ""))

res = readRDS("param_estims_phase2.RDS")
abc.estims          = res$estims           # 500 (iterations) x 1 (number of parameters: beta) matrix
abc.status.matrices = res$mat              # list of length 500 (iterations); with each list component having 80 status matrices, one for each day
abc.locations       = res$locations        # list of length 500 (iterations); with each list component having a matrix of individual boars (95144 rows)

res2 = readRDS(paste("forward.run.", ifelse(increas, "increased", "normal"), ".pressure.110.RDS", sep = ""))
fwd.status.matrices = res2$status.matrices # list of length 500 (iterations); with each list component having 30 status matrices, one for each day
fwd.locations       = res2$locations       # list of length 500 (iterations); with each list component having a matrix of individual boars (95144 rows)


##################
# INITIALIZATION #
##################

timings.max = max(fwd.locations[[1]]$date.removed2)
final.pressure = list()                             # List to save pressure vectors at each iteration
abc.times = 1:(timings.max-length(fwd.status.matrices[[1]]))
fwd.times = (timings.max-length(fwd.status.matrices[[1]]))+(1:length(fwd.status.matrices[[1]]))
outdoor.herd.indices = which(herds$is_outdoor==1)   # Get indices for outdoor farms. Pressures are not calculated for indoor farms as the probability of contact with WB in those farms is negligible. 

### Determine patches that fall within fence ###
if(fence){ # if fence = TRUE
  # Vertices of fence are: A,B,C,D, beginning from lower-left vertex and labelling counterclockwise
  A = c(773676.4, 6347189)
  B = c(833676.4, 6347189)
  C = c(833676.4, 6437189)
  D = c(773676.4, 6437189)
  
  rectangular.fence = data.frame(id = LETTERS[1:4], 
                                  X = c(A[1], B[1], C[1], D[1]),
                                  Y = c(A[2], B[2], C[2], D[2]))
  
  
  all.patch.centres = tidyr::crossing(X = patchcentres$X, Y = patchcentres$Y) 
  
  # Determine responses to "Is patch i in fence"?
  in.fence = sp::point.in.polygon(point.x = all.patch.centres$X, point.y= all.patch.centres$Y,
                                   pol.x = rectangular.fence$X, pol.y = rectangular.fence$Y)
  
  in.fence.matrix = matrix(in.fence, nrow = npatches_x, ncol = npatches_y)
  
  # Identify outdoor herds in relation to fence
  herdsInFence = outdoor.herd.indices[sp::point.in.polygon(point.x = herds$X[outdoor.herd.indices], point.y= herds$Y[outdoor.herd.indices],
                                                            pol.x = rectangular.fence$X, pol.y = rectangular.fence$Y) != 0]
  herdsNotInFence = outdoor.herd.indices[sp::point.in.polygon(point.x = herds$X[outdoor.herd.indices], point.y= herds$Y[outdoor.herd.indices],
                                                               pol.x = rectangular.fence$X, pol.y = rectangular.fence$Y) == 0]
}


######################################################
# COMPUTE INFECTIOUS PRESSURES BY WILD BOAR ON HERDS #
######################################################
# Use distance kernel function:  K(d, alpha_wb) = beta_wb*exp(-d/alpha_wb); beta_wb is rate of infection from WB to herd,
# d is the distance between infected wild boar and herds, 
# alpha is the length scale of transmission.

for(i in 1:length(abc.status.matrices)){

  updated.boar = fwd.locations[[i]]
  infectiousPressureWB = matrix (0, nrow = nrow(herds), ncol = timings.max)   # Matrix to store infectious pressure from WB
  
  # Set kernel parameters 
  beta_wb  = abc.estims[i,1]
  alpha_wb = 870

  # From ABC estimation (day 1 to 80)
  for(t in abc.times){

    ## WORK OUT INFECTIOUS PRESSURE ON EACH HERD ##    
    if (fence & t>=60){   # IMPLEMENT FENCE AFTER DAY 60
      
      # Identify infected patches positions inside the fence
      rowInFence = as.data.frame(which(abc.status.matrices[[i]][[t]] == 1 & in.fence.matrix == 1, arr.ind = TRUE))$row
      colInFence = as.data.frame(which(abc.status.matrices[[i]][[t]] == 1 & in.fence.matrix == 1, arr.ind = TRUE))$col
      LinIdx_I   = (colInFence-1)* nrow(abc.status.matrices[[i]][[t]]) + rowInFence
      
      # Count number of infected boars in infected patches inside the fence
      mat = updated.boar[updated.boar$patch %in% LinIdx_I,]
      numb.inf.boar.in.inf.patches = sapply(1:length(LinIdx_I), function(i) sum(mat$patch == LinIdx_I[i] & mat$infectionStatus == 1 & mat$date.infected <= t))
      
      for (k in herdsInFence){ # if herd is in fence, infection pressure only by patches in fence
        infectiousPressureWB[k, t] = sum(beta_wb*exp(-(sqrt((patchcentres_x[colInFence] - herds$X[k])^2 +
                                                             (patchcentres_y[rowInFence] - herds$Y[k])^2))/alpha_wb) * numb.inf.boar.in.inf.patches)
      }

      # Identify infected patches positions outside the fence
      rowNotInFence = as.data.frame(which(abc.status.matrices[[i]][[t]] == 1 & in.fence.matrix == 0, arr.ind = TRUE))$row
      colNotInFence = as.data.frame(which(abc.status.matrices[[i]][[t]] == 1 & in.fence.matrix == 0, arr.ind = TRUE))$col
      LinIdx_I   = (colNotInFence-1)* nrow(abc.status.matrices[[i]][[t]]) + rowNotInFence
      
      # Count number of infected boars in infected patches outside the fence
      mat = updated.boar[updated.boar$patch %in% LinIdx_I,]
      numb.inf.boar.in.inf.patches = sapply(1:length(LinIdx_I), function(i) sum(mat$patch == LinIdx_I[i] & mat$infectionStatus == 1 & mat$date.infected <= t))
      
      for (k in herdsNotInFence){ # if herd is not in fence, infection pressure only by patches outside fence
        infectiousPressureWB[k, t] = sum(beta_wb*exp(-(sqrt((patchcentres_x[colNotInFence] - herds$X[k])^2 +
                                                             (patchcentres_y[rowNotInFence] - herds$Y[k])^2))/alpha_wb) * numb.inf.boar.in.inf.patches)
      }
      
    } else {              # IF LESS THAN DAY 60 OR FENCE = FALSE, COMPUTE PRESSURES 'AS USUAL'

      # Identify infected patches
      row = as.data.frame(which(abc.status.matrices[[i]][[t]] == 1, arr.ind = TRUE))$row
      col = as.data.frame(which(abc.status.matrices[[i]][[t]] == 1, arr.ind = TRUE))$col
      LinIdx_I   = (col-1)* nrow(abc.status.matrices[[i]][[t]]) + row
      
      # Count number of infected boars in infected patches
      mat = updated.boar[updated.boar$patch %in% LinIdx_I,]
      numb.inf.boar.in.inf.patches = sapply(1:length(LinIdx_I), function(i) sum(mat$patch == LinIdx_I[i] & mat$infectionStatus == 1 & mat$date.infected <= t))
      
      for (k in outdoor.herd.indices){
        infectiousPressureWB[k, t] = sum(beta_wb*exp(-(sqrt((patchcentres_x[col] - herds$X[k])^2 +
                                                             (patchcentres_y[row] - herds$Y[k])^2))/alpha_wb) * numb.inf.boar.in.inf.patches)
      }
    }
    
    ### UPDATE BOAR NUMBERS
    boar.removed = which(updated.boar$date.removed2 == t)
    updated.boar = updated.boar[-boar.removed, ]
    
  }

  # Forward predictions (day 81 to 110)
  for(t in fwd.times){
  
    ## WORK OUT INFECTIOUS PRESSURE ON EACH HERD ##    
    if (fence & t>=60){   # IMPLEMENT FENCE AFTER DAY 60
      
      # Identify infected patches positions inside the fence
      rowInFence = as.data.frame(which(fwd.status.matrices[[i]][[t-max(abc.times)]] == 1 & in.fence.matrix == 1, arr.ind = TRUE))$row
      colInFence = as.data.frame(which(fwd.status.matrices[[i]][[t-max(abc.times)]] == 1 & in.fence.matrix == 1, arr.ind = TRUE))$col
      LinIdx_I   = (colInFence-1)* nrow(fwd.status.matrices[[i]][[t-max(abc.times)]]) + rowInFence
      
      # Count number of infected boars in infected patches inside the fence
      mat = updated.boar[updated.boar$patch %in% LinIdx_I,]
      numb.inf.boar.in.inf.patches = sapply(1:length(LinIdx_I), function(i) sum(mat$patch == LinIdx_I[i] & mat$infectionStatus == 1 & mat$date.infected <= t))
      
      for (k in herdsInFence){ # if herd is in fence, infection pressure only by patches in fence
        infectiousPressureWB[k, t] = sum(beta_wb*exp(-(sqrt((patchcentres_x[colInFence] - herds$X[k])^2 +
                                                             (patchcentres_y[rowInFence] - herds$Y[k])^2))/alpha_wb) * numb.inf.boar.in.inf.patches)
      }
      
      # Identify infected patches positions outside the fence
      rowNotInFence = as.data.frame(which(fwd.status.matrices[[i]][[t-max(abc.times)]] == 1 & in.fence.matrix == 0, arr.ind = TRUE))$row
      colNotInFence = as.data.frame(which(fwd.status.matrices[[i]][[t-max(abc.times)]] == 1 & in.fence.matrix == 0, arr.ind = TRUE))$col
      LinIdx_I   = (colNotInFence-1)* nrow(fwd.status.matrices[[i]][[t-max(abc.times)]]) + rowNotInFence
      
      # Count number of infected boars in infected patches outside the fence
      mat = updated.boar[updated.boar$patch %in% LinIdx_I,]
      numb.inf.boar.in.inf.patches = sapply(1:length(LinIdx_I), function(i) sum(mat$patch == LinIdx_I[i] & mat$infectionStatus == 1 & mat$date.infected <= t))
      
      for (k in herdsNotInFence){ # if herd is not in fence, infection pressure only by patches outside fence
        infectiousPressureWB[k, t] = sum(beta_wb*exp(-(sqrt((patchcentres_x[colNotInFence] - herds$X[k])^2 +
                                                             (patchcentres_y[rowNotInFence] - herds$Y[k])^2))/alpha_wb) * numb.inf.boar.in.inf.patches)
      }
      
    } else {              # IF LESS THAN DAY 60 OR FENCE = FALSE, COMPUTE PRESSURES 'AS USUAL'
      
      # Identify infected patches
      row = as.data.frame(which(fwd.status.matrices[[i]][[t-max(abc.times)]] == 1, arr.ind = TRUE))$row
      col = as.data.frame(which(fwd.status.matrices[[i]][[t-max(abc.times)]] == 1, arr.ind = TRUE))$col
      LinIdx_I   = (col-1)* nrow(fwd.status.matrices[[i]][[t-max(abc.times)]]) + row
      
      # Count number of infected boars in infected patches
      mat = updated.boar[updated.boar$patch %in% LinIdx_I,]
      numb.inf.boar.in.inf.patches = sapply(1:length(LinIdx_I), function(i) sum(mat$patch == LinIdx_I[i] & mat$infectionStatus == 1 & mat$date.infected <= t))
      
      for (k in outdoor.herd.indices){
        infectiousPressureWB[k, t] = sum(beta_wb*exp(-(sqrt((patchcentres_x[col] - herds$X[k])^2 +
                                                             (patchcentres_y[row] - herds$Y[k])^2))/alpha_wb) * numb.inf.boar.in.inf.patches)
      }
    }
    
    ### UPDATE BOAR NUMBERS
    boar.removed = which(updated.boar$date.removed2 == t)
    updated.boar = updated.boar[-boar.removed, ]
    
  }    
  
  final.pressure[[i]] = infectiousPressureWB
}

# List of length 500, with each component containing a matrix of infection pressures for each herd at each day.
saveRDS(final.pressure, file = paste("forward.pressure.", ifelse(fence & increas, "increased", "normal"), "hunting.110.RDS", sep = ""))
