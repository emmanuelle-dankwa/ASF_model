########################################################
# SIMULATED PIG MOVEMENTS BASED ON ERGM AND GLM MODELS #
#             ASF CHALLENGE - UK TEAM                  #
#                                                      #
#                 Phase 2 - 2020/11/23                 #
########################################################


rm(list = ls()) # remove (almost) everything in the working environment

# Set to your working directory
wd = "~/pig_herd_component/Phase2"

##########
## SEED ##
##########

SEED = as.numeric(Sys.getenv("SEED")) # Cluster
#SEED = 1                             # Local
set.seed(SEED)

###########
# LIBRARY #
###########

library(VGAM)    # Package VGAM: function predict for vglm posnegbinomial model
library(network) # Software Tools for the Statistical Analysis of Network Data
library(sna)     # Software Tools for the Statistical Analysis of Network Data
library(ergm)    # Software Tools for the Statistical Analysis of Network Data

########
# DATA #
########

# Set working directory
setwd(paste(wd, "/Data_Outbreak", sep = ""))

herds      = read.csv("herds_day_80.csv", header = TRUE)                 # Characteristics of all pig sites
moves      = read.csv("moves_Players_day_80.csv", header = TRUE)         # List of all known movements of live pigs
moves      = moves[-which(moves$qty == 0),]                              # Remove movements of 0 animals
delta      = abs(min(moves$date)) + 1                                    # Number of days in the data before the first detected case (2 months)
moves$date = moves$date + delta                                          # Shift movement dates to start at t=1
max.date   = max(moves$date)                                             # Total number of days in the data

#########################
# CONNECTED HERDS: ERGM #
#########################

# Keep the last month of data to assess the predictive ability
moves2 = moves[moves$date > 110,]                                   
net2   = network(unique(moves2[,c("source","dest")]), matrix.type = "edgelist", directed = TRUE, multiple = FALSE)

# Attribute herd characteristics to each node
net2 %v% "size"          = herds$size
net2 %v% "production"    = as.character(herds$production)
net2 %v% "is_outdoor"    = herds$is_outdoor
net2 %v% "is_commercial" = herds$is_commercial
net2 %v% "multisite"     = herds$multisite

setwd(paste(wd, "/Moves_ERGM", sep = ""))
load(file = "final_ERGM.Rdata")

# Randomly sample a network from the specified model
sim = simulate(net2 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodematch("multisite", diff = TRUE, levels = -c(1,19,21,26,36,45,60,61,63,74,83,95,96,99,105,116,118,126)) + nodecov("size") + nodemix("is_commercial", levels2 = c(2:4)),
               coef = coef(netmodel.3), burnin = 1e+6, verbose = TRUE, seed = SEED, nsim = 1)

mov.pred = as.data.frame(as.edgelist(sim))                     # Keep source and destination herds in the simulated network
colnames(mov.pred) = c("source", "dest")                       # Column names
mov.pred$source.type   = herds$production[mov.pred$source]     # Production type of the source
mov.pred$dest.type     = herds$production[mov.pred$dest]       # Production type of the destination
mov.pred = mov.pred[mov.pred$source.type != "F",]              # Remove impossible edges (F->F, F->BF, F->B)
mov.pred = mov.pred[mov.pred$dest.type   != "B",]              # Remove impossible edges (F->B, BF->B, B->B)

# Prediction accuracy
TOT = 7467448                     # TP + FP + FN + TN (all possible pairs of herds)
TP = sum(sapply(1:nrow(mov.pred), # True positives
                function(X) any((mov.pred$source[X] == moves2$source) & (mov.pred$dest[X] == moves2$dest))))
FP = nrow(mov.pred) - TP          # False positives
FN = nrow(moves2) - TP            # False negatives
TN = TOT - TP - FP - FN           # True negatives

Se = TP/(TP+FN)                   # Sensitivity
Sp = TN/(TN+FP)                   # Specificity


##################
# MOVEMENT DATES #
##################

date = moves$date[match(unique(moves$source),moves$source)]                          # Known movement dates
date = date %% 30                                                                    # Outgoing movements every 30 days from sources
date[date == 0] = 30                                                                 # Dates that are multiples of 30
#hist(date)                                                                          # Known movement dates follow an uniform distribution
herds$date = 0                                                                       # Initialization
herds$date[match(unique(moves$source), herds$population_id)] = date                  # Known movement dates for sources
herds$date[herds$date == 0] = sample(1:30, size = sum(herds$date == 0), replace = T) # Sample unknown movement dates from uniform distribution

mov.pred$date = herds$date[mov.pred$source]                                          # Attribute movement date (between 1 and 30) depending on source herd


############################
# NUMBER OF MOVEMENTS: GLM #
############################

setwd(paste(wd, "/Moves_GLM", sep = ""))
load(file = "posnegbinom.Rdata")

# Model covariates
mov.pred$source.size   = herds$size[mov.pred$source]                        # Herd size of the source
mov.pred$dest.size     = herds$size[mov.pred$dest]                          # Herd size of the destination

mov.pred$source.com    = herds$is_commercial[mov.pred$source]               # Is the source commercial
mov.pred$dest.com      = herds$is_commercial[mov.pred$dest]                 # Is the destination commercial

mov.pred$source.out    = herds$is_outdoor[mov.pred$source]                  # Is the source outdoor
mov.pred$dest.out      = herds$is_outdoor[mov.pred$dest]                    # Is the destination outdoor

mov.pred$source.multi  = herds$multisite[mov.pred$source]                   # ID of the source multisite (0 if not)
mov.pred$dest.multi    = herds$multisite[mov.pred$dest]                     # ID of the destination multisite (0 if not)
mov.pred$multi         = ((mov.pred$source.multi == mov.pred$dest.multi) &  # Is the pair on the same multisite
                          (mov.pred$source.multi != 0))

# Model prediction
mov.pred$qty = round(predict(mod2, newdata = mov.pred, type = "response"))


########
# SAVE #
########

setwd(paste(wd, "/Moves_Simul/sim", sep = ""))
save(mov.pred, file = paste("mov_pred_", SEED, ".Rdata", sep = ""))

setwd(paste(wd, "/Moves_Simul/Se", sep = ""))
save(Se, file = paste("mov_Se_", SEED, ".Rdata", sep = ""))

setwd(paste(wd, "/Moves_Simul/Sp", sep = ""))
save(Sp, file = paste("mov_Sp_", SEED, ".Rdata", sep = ""))