################################################################
# INFECTIOUS PRESSURE ON HERDS GIVEN WILD BOAR MODEL ESTIMATES #
#                 ASF CHALLENGE - UK TEAM                      #
#                                                              #
#                     Phase 1 - 2020/10/08                     #
################################################################


rm(list = ls()) # remove (almost) everything in the working environment

# Set to your working directory
wd = "~/pig_herd_component/Phase1"

###############
## SCENARIOS ##
###############

fence    = FALSE           # Scenario: fencing
increased.pressure = FALSE # Scenario: increased hunting pressure on wild boars inside the fence

###########
# LIBRARY #
###########

library(sp)    # R Package: point.in.polygon function
library(tidyr) # R Package: crossing function

########
# DATA #
########

# Set working directory
setwd(paste(wd, "/Data_Outbreak", sep = ""))
herds = read.csv("herds_day_50.csv")

##############################
# IMPORT WILD BOAR ESTIMATES #
##############################

# Set working directory
setwd(paste(wd, "/Model_Predict/input", sep = ""))

res = readRDS("results_gen_4.RDS")
abc.estims                 = res$estims # 500 (iterations) x 4 (number of parameters) matrix. V1, V2, V3 and V4 correspond to beta, alpha, patchToBoarRate_1 and patchToBoarRate_2 respectively (see wb-sir-model-v1.R for details on parameters)
abc.estims.status.matrices = res$mat    # list of length 500 (iterations); with each list component having 50 status matrices, one for each day

if (!fence){
  fwd.estims.status.matrices = readRDS("forward.run.RDS")[[1]]  # list of length 500 (iterations); with each list component having 28 status matrices, one for each day
} else {
  fwd.estims.status.matrices = readRDS(paste("forward.run.",
                                             ifelse(increased.pressure, "fence.increased.pressure", "fence"),
                                             ".RDS", sep = ""))[[1]]  # list of length 500 (iterations); with each list component having 28 status matrices, one for each day
}

##############
# PARAMETERS #
##############

patchcentres = readRDS("patchcentres.RDS")         # Infection status matrix for WB patches for each day
nBoarsMatrix = readRDS("nBoarsMatrix.RDS")         # Number of WB per patch
npatches_x = npatches_y =  nrow(patchcentres)
patchcentres_x = patchcentres$X
patchcentres_y = patchcentres$Y


##################
# INITIALIZATION #
##################

timings.max = 78
infectiousPressureWB = matrix (0, nrow = nrow(herds), ncol = timings.max)   # Matrix to store infectious pressure from WB
final.pressure = list()                                                     # List to save pressure vectors at each iteration
outdoor.herd.indices = which(herds$is_outdoor==1)                           # Get indices for outdoor farms. Pressures are not calculated for indoor farms as the probability of contact with WB in those farms is negligible. 

# Determine patches that fall within fence
if(fence){ # if fence = TRUE
  # Vertices of fence are: A,B,C,D, beginning from lower-left vertex and labelling counterclockwise
  A = c(773676.4, 6347189)
  B = c(833676.4, 6347189)
  C = c(833676.4, 6437189)
  D = c(773676.4, 6437189)
  
  rectangular.fence = data.frame(id = LETTERS[1:4], 
                                  X = c(A[1], B[1], C[1], D[1]),
                                  Y = c(A[2], B[2], C[2], D[2]))
  
  
  all.patch.centres = tidyr::crossing(X = patchcentres$X, Y = patchcentres$Y) 
  
  # Determine responses to "Is patch i in fence"?
  in.fence = sp::point.in.polygon(point.x = all.patch.centres$X, point.y= all.patch.centres$Y,
                                   pol.x = rectangular.fence$X, pol.y = rectangular.fence$Y)
  
  in.fence.matrix = matrix(in.fence, nrow = npatches_x, ncol = npatches_y)
  
  # Identify outdoor herds in relation to fence
  herdsInFence = outdoor.herd.indices[sp::point.in.polygon(point.x = herds$X[outdoor.herd.indices], point.y= herds$Y[outdoor.herd.indices],
                                                            pol.x = rectangular.fence$X, pol.y = rectangular.fence$Y) != 0]
  herdsNotInFence = outdoor.herd.indices[sp::point.in.polygon(point.x = herds$X[outdoor.herd.indices], point.y= herds$Y[outdoor.herd.indices],
                                                               pol.x = rectangular.fence$X, pol.y = rectangular.fence$Y) == 0]
}


## REDUCTION IN WILD BOAR NUMBERS ##

## How many wild boar are there within the fence? ##

if(increased.pressure){
  
  nboar.in.fence = sum(nBoarsMatrix[which(in.fence.matrix==1)]) # 33721
  
  ## Hunting 90% of these will result in 
  
  nboar.in.fence.to.be.hunted = round(0.9*nboar.in.fence)  # ...30349 = expected number of hunted wild boar 
  
  ## Given that this hunting will take place over 4 weeks and at a uniform rate, how many will be killed in each day? ##
  
  nboar.in.fence.to.be.hunted.each.day = round(nboar.in.fence.to.be.hunted/19) # 1597, from day 60 to day 78.
  
  ## So, reduce number of boar in fenced area by 1597 at each day ##
}

# RANDOM SAMPLING WITHOUT REPLACEMENT
sampler = function(m, size){
  d = unlist(lapply(1:length(m), function(x) rep(x, m[x])))
  s = sample(d, size = size, replace = FALSE)
  return(s)
}

# Define function to update boar numbers 
update.boar.numbers.in.fence = function(x, total){
  s = sampler(m = x, size = total)
  x[as.numeric(levels(factor(s)))] = x[as.numeric(levels(factor(s)))] - table(factor(s))
  return(x)
}

######################################################
# COMPUTE INFECTIOUS PRESSURES BY WILD BOAR ON HERDS #
######################################################
# Use distance kernel function:  K(d, alpha_wb) = beta_wb*exp(-d/alpha_wb); beta_wb is rate of infection from WB to herd,
# d is the distance between infected wild boar and herds, 
# alpha is the length scale of transmission.

for(i in 1:length(abc.estims.status.matrices)){
 
  nBoarsMatrix = readRDS("nBoarsMatrix.RDS")         # Number of WB per patch (source('wb-sir-model-fixed-time-step.R'))com
  
  # Set patchToBoarRate parameters
  patchToBoarRate_1 = abc.estims[i, 3]      
  patchToBoarRate_2 = abc.estims[i, 4] 

  # Set kernel parameters 
  beta_wb  = abc.estims[i, 1]
  alpha_wb = abc.estims[i, 2]
  
  # From ABC estimation (day 1 to 50)
  for(t in 1:length(abc.estims.status.matrices[[1]])){
    row = as.data.frame(which(abc.estims.status.matrices[[i]][[t]] == 1, arr.ind = TRUE))$row
    col = as.data.frame(which(abc.estims.status.matrices[[i]][[t]] == 1, arr.ind = TRUE))$col
    
    if(t< 28){   # time-dependent 
      patchToBoarRate = patchToBoarRate_1
    }else{
      if(t>=28 & t < 38){
        patchToBoarRate = patchToBoarRate_1 + ((patchToBoarRate_2 - patchToBoarRate_1)/ (38-28))*(t - 28)
      }else{
        patchToBoarRate = patchToBoarRate_2
      }
    }
    
    for (k in outdoor.herd.indices){
      infectiousPressureWB[k, t] = sum(beta_wb*exp(-(sqrt((patchcentres_x[col] - herds$X[k])^2 +
                                                          (patchcentres_y[row] - herds$Y[k])^2))/alpha_wb) * nBoarsMatrix[which(abc.estims.status.matrices[[i]][[t]]==1)]*patchToBoarRate)
    }
  }

  # Forward predictions (day 51 to 78)
  for(t in length(abc.estims.status.matrices[[i]])+(1:length(fwd.estims.status.matrices[[i]]))){
  
    patchToBoarRate = patchToBoarRate_2

    if (fence & t>=60){   # IMPLEMENT FENCE AFTER DAY 60

      ## IF INCREASED PRESSURE, DECREASE THE NUMBER OF WILD BOARS IN FENCE ###
      if(increased.pressure){
        nBoarsMatrix[which(in.fence.matrix==1)] = update.boar.numbers.in.fence(nBoarsMatrix[which(in.fence.matrix==1)],
                                                                                total = min(nboar.in.fence.to.be.hunted.each.day, sum(nBoarsMatrix[which(in.fence.matrix==1)])))
      }
      
      # Identify infected patch position in relation to fence
      rowInFence = as.data.frame(which(fwd.estims.status.matrices[[i]][[t-length(abc.estims.status.matrices[[i]])]] == 1 & in.fence.matrix == 1, arr.ind = TRUE))$row
      colInFence = as.data.frame(which(fwd.estims.status.matrices[[i]][[t-length(abc.estims.status.matrices[[i]])]] == 1 & in.fence.matrix == 1, arr.ind = TRUE))$col

      rowNotInFence = as.data.frame(which(fwd.estims.status.matrices[[i]][[t-length(abc.estims.status.matrices[[i]])]] == 1 & in.fence.matrix == 0, arr.ind = TRUE))$row
      colNotInFence = as.data.frame(which(fwd.estims.status.matrices[[i]][[t-length(abc.estims.status.matrices[[i]])]] == 1 & in.fence.matrix == 0, arr.ind = TRUE))$col
      
      for (k in herdsInFence){ # if herd is in fence, infection pressure only by patches in fence
        infectiousPressureWB[k, t] = sum(beta_wb*exp(-(sqrt((patchcentres_x[colInFence] - herds$X[k])^2 +
                                                               (patchcentres_y[rowInFence] - herds$Y[k])^2))/alpha_wb) * nBoarsMatrix[cbind(rowInFence,colInFence)]*patchToBoarRate)
      }
      
      for (k in herdsNotInFence){ # if herd is not in fence, infection pressure only by patches outside fence
        infectiousPressureWB[k, t] = sum(beta_wb*exp(-(sqrt((patchcentres_x[colNotInFence] - herds$X[k])^2 +
                                                            (patchcentres_y[rowNotInFence] - herds$Y[k])^2))/alpha_wb) * nBoarsMatrix[cbind(rowNotInFence,colNotInFence)]*patchToBoarRate)
      }

    } else {              # IF LESS THAN DAY 60 OR FENCE = FALSE, COMPUTE PRESSURES 'AS USUAL'

      row = as.data.frame(which(fwd.estims.status.matrices[[i]][[t-length(abc.estims.status.matrices[[i]])]] == 1, arr.ind = TRUE))$row
      col = as.data.frame(which(fwd.estims.status.matrices[[i]][[t-length(abc.estims.status.matrices[[i]])]] == 1, arr.ind = TRUE))$col

      for (k in outdoor.herd.indices){
        infectiousPressureWB[k, t] = sum(beta_wb*exp(-(sqrt((patchcentres_x[col] - herds$X[k])^2 +
                                                            (patchcentres_y[row] - herds$Y[k])^2))/alpha_wb) * nBoarsMatrix[cbind(row,col)]*patchToBoarRate)
      }
    }
  }  
  
  final.pressure[[i]] = infectiousPressureWB
}

if (!fence){
  saveRDS(final.pressure, file = "forward.pressure.RDS")   # List of length 500, with each component containing a matrix of infection pressured for each herd at each day.
} else {
  saveRDS(final.pressure, file = paste("forward.pressure.",
                                       ifelse(increased.pressure, "fence.increased.hunting", "fence"),
                                       ".RDS", sep = ""))  # List of length 500, with each component containing a matrix of infection pressured for each herd at each day.
}
