############################################################
# ZERO-TRUNCATED NEGATIVE BINOMIAL MODEL FOR PIG MOVEMENTS #
#               ASF CHALLENGE - UK TEAM                    #
#                                                          #
#                   Phase 1 - 2020/10/08                   #
############################################################

rm(list = ls()) # remove (almost) everything in the working environment

# Set to your working directory
wd = "~/pig_herd_component/Phase1"

###########
# LIBRARY #
###########

library(SimInf) # R Package for Data-Driven Stochastic Disease Spread Simulations: distance_matrix function
library(MASS)   # R Package: stepAIC
library(VGAM)   # R Package: vglm posnegbinomial model
library(ggsci)  # R Package: Scientific Journal Themed Color Palettes

########
# DATA #
########

# Set working directory
setwd(paste(wd, "/Data_Outbreak", sep = ""))

herds      = read.csv("herds_day_50.csv", header = TRUE)                 # Characteristics of all pig sites
d_ij       = distance_matrix(x = herds$X, y = herds$Y, cutoff = 1000000) # Create a distance matrix for all coordinates
d_ij       = as.matrix(d_ij)                                             # Converts to a classic matrix
moves      = read.csv("moves_Players_day_50.csv", header = TRUE)         # List of all known movements of live pigs
moves      = moves[-which(moves$qty == 0),]                              # Remove movements of 0 animals
delta      = abs(min(moves$date)) + 1                                    # Number of days in the data before the first detected case (2 months)
moves$date = moves$date + delta                                          # Data provided 2 months before the first detected case

###########
# DATASET #
###########

# All movements
dat = moves

dat$dist          = d_ij[cbind(dat$source,dat$dest)]         # Distance between each pair of herds

dat$source.size   = herds$size[dat$source]                   # Herd size of the source
dat$dest.size     = herds$size[dat$dest]                     # Herd size of the destination

dat$source.com    = herds$is_commercial[dat$source]          # Is the source commercial
dat$dest.com      = herds$is_commercial[dat$dest]            # Is the destination commercial

dat$source.out    = herds$is_outdoor[dat$source]             # Is the source outdoor
dat$dest.out      = herds$is_outdoor[dat$dest]               # Is the destination outdoor

dat$source.multi  = herds$multisite[dat$source]              # ID of the source multisite (0 if not)
dat$dest.multi    = herds$multisite[dat$dest]                # ID of the destination multisite (0 if not)
dat$multi         = ((dat$source.multi == dat$dest.multi) &  # Is the pair on the same multisite
                     (dat$source.multi != 0))

#########################
# GLM: TRAINING DATASET #
#########################

set.seed(123)
subsize = round((2/3) * nrow(dat))
train = sample(1:nrow(dat), subsize)

# Complete model
mod1 = vglm(qty ~ dist + source.size + dest.size + source.type + dest.type +
                  source.com + dest.com + source.out + dest.out + multi,
            family = posnegbinomial(), data = dat, subset = train)
summary(mod1)
AIC(mod1)

# Choose a model by AIC in a Stepwise Algorithm
step4(mod1)

# Final negative binomial model
mod2 = vglm(qty ~ source.size + dest.size + source.type + dest.type +
              source.com + dest.com + source.out + multi,
            family = posnegbinomial(), data = dat, subset = train)
summary(mod2)
AIC(mod2) # 68676.2

# Residual plots
res2 = resid(mod2)
plot(log(predict(mod2)), res2)
abline(h=0, lty=2)
qqnorm(res2)
qqline(res2)


########################
# GLM: TESTING DATASET #
########################

nb.probs = predict(mod2, newdata = dat[-train,], type = 'response')

# Set working directory
setwd(paste(wd, "/Moves_GLM", sep = ""))

# Goodness of fit
jpeg("posnegbinom_model.jpeg", res = 300, height = 6, width = 6, units = "in")

par(mar = c(5, 4, 2, 2) + 0.1, cex.axis = 1.2, cex.lab = 1.2)
h1 = hist(dat$qty[-train], ylim = c(0, 4500), xaxt = "n", col = "grey", xlab = "Number of pigs in a shipment", main = "Zero-truncated negative binomial model")
h2 = hist(nb.probs, breaks = c(h1$breaks[-length(h1$breaks)], max(nb.probs)), plot = F)
points(h1$mids, h2$counts,
       pch = 19, col = pal_lancet("lanonc")(3)[2], type = "b")
axis(1, at = h1$breaks, labels = c(h1$breaks[-length(h1$breaks)], bquote("+ \U221E")))
legend("topright", legend = c("Observed data", "Simulated data"),
       bty = "n", pch = c(22, 21), col = c("black", pal_lancet("lanonc")(3)[2]), pt.bg = c("grey", pal_lancet("lanonc")(3)[2]), cex = 1.2)

dev.off()

save(mod2, file = "posnegbinom.Rdata")
