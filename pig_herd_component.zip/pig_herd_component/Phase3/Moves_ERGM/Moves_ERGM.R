####################################################
# EXPONENTIAL RANDOM GRAPH MODEL FOR PIG MOVEMENTS #
#           ASF CHALLENGE - UK TEAM                #
#                                                  #
#               Phase 3 - 2021/01/13               #
####################################################


rm(list = ls()) # remove (almost) everything in the working environment

# Set to your working directory
wd = "~/pig_herd_component/Phase3"


###########
# LIBRARY #
###########

library(SimInf)  # R Package for Data-Driven Stochastic Disease Spread Simulations: distance_matrix function
library(statnet) # R Package: Software Tools for the Statistical Analysis of Network Data
library(ggsci)   # R Package: Scientific Journal Themed Color Palettes

########
# DATA #
########

# Set working directory
setwd(paste(wd, "/Data_Outbreak", sep = ""))

herds      = read.csv("herds_day_110.csv", header = TRUE)                # Characteristics of all pig sites
d_ij       = distance_matrix(x = herds$X, y = herds$Y, cutoff = 1000000) # Create a distance matrix for all coordinates
d_ij       = as.matrix(d_ij)                                             # Converts to a classic matrix
moves      = read.csv("moves_Players_day_110.csv", header = TRUE)        # List of all known movements of live pigs
moves      = moves[-which(moves$qty == 0),]                              # Remove movements of 0 animals
delta      = abs(min(moves$date)) + 1                                    # Number of days in the data before the first detected case (2 months)
moves$date = moves$date + delta                                          # Shift movement dates to start at t=1

#######
# SNA #
#######

# Set working directory
setwd(paste(wd, "/Moves_ERGM", sep = ""))

set.seed(123)

# Keep the first 140 days of data to fit the model
moves1 = moves[moves$date <= (max(moves$date)-30),]
net1 = network(unique(moves1[,c("source","dest")]), matrix.type = "edgelist", directed = TRUE, multiple = FALSE)
summary(net1)

# Attribute herd characteristics to each node
net1 %v% "size"          = herds$size
net1 %v% "production"    = as.character(herds$production)
net1 %v% "is_outdoor"    = herds$is_outdoor
net1 %v% "is_commercial" = herds$is_commercial
net1 %v% "multisite"     = herds$multisite
list.vertex.attributes(net1)

# Plot
set.seed(123)
jpeg("data_network.jpeg", res = 300, height = 12, width = 12, units = "in")
plot(net1, vertex.col = pal_lancet("lanonc")(3)[c(1,3,2)][as.numeric(herds$production)], main = "Observed", cex.main = 4)
par(xpd = T)
legend(x = (par("usr")[2]-par("usr")[1])/2, y = par("usr")[3]+25, legend = c("B", "BF", "F"), col = pal_lancet("lanonc")(3)[c(1,3,2)], bty = "n", pch = 19, horiz = T, cex = 3)
dev.off()


##########################
# ERGM: TRAINING DATASET #
##########################

# Constraint for ergm to avoid impossible edges (F->F, F->BF, F->B, BF->B, B->B)
#absent = rbind(expand.grid(source = herds$population_id[herds$production %in% c("F")  & herds$population_id %in% as.numeric(net1 %v% "vertex.names")],
#                           dest   = herds$population_id[herds$production %in% c("F")  & herds$population_id %in% as.numeric(net1 %v% "vertex.names")]),
#               expand.grid(source = herds$population_id[herds$production %in% c("F")  & herds$population_id %in% as.numeric(net1 %v% "vertex.names")],
#                           dest   = herds$population_id[herds$production %in% c("BF") & herds$population_id %in% as.numeric(net1 %v% "vertex.names")]),
#               expand.grid(source = herds$population_id[herds$production %in% c("F")  & herds$population_id %in% as.numeric(net1 %v% "vertex.names")],
#                           dest   = herds$population_id[herds$production %in% c("B")  & herds$population_id %in% as.numeric(net1 %v% "vertex.names")]), 
#               expand.grid(source = herds$population_id[herds$production %in% c("BF") & herds$population_id %in% as.numeric(net1 %v% "vertex.names")],
#                           dest   = herds$population_id[herds$production %in% c("B")  & herds$population_id %in% as.numeric(net1 %v% "vertex.names")]),
#               expand.grid(source = herds$population_id[herds$production %in% c("B")  & herds$population_id %in% as.numeric(net1 %v% "vertex.names")],
#                           dest   = herds$population_id[herds$production %in% c("B")  & herds$population_id %in% as.numeric(net1 %v% "vertex.names")]),
#               cbind(source = herds$population_id[herds$production %in% c("BF")  & herds$population_id %in% as.numeric(net1 %v% "vertex.names")],
#                     dest   = herds$population_id[herds$production %in% c("BF")  & herds$population_id %in% as.numeric(net1 %v% "vertex.names")]))
#absent = network(absent[,c("source","dest")], matrix.type = "edgelist", directed = TRUE, multiple = FALSE)
#/!\ Takes a while
#save(absent, file = "absent_network.Rdata")
load(file = "absent_network.Rdata")


# BERNOULLI MODEL (NULL MODEL OR EDGES)
netmodel.1 = ergm(net1 ~ edges)
summary(netmodel.1)                           # AIC = 206749
exp(netmodel.1$coef)/(1+exp(netmodel.1$coef)) # Equals to the network density (see summary(net1))

# Goodness of fit
gof1 = gof(netmodel.1, verbose = TRUE, burnin = 1e+5,
           interval = 1e+5, control.gof.ergm(seed = 123))
jpeg("sim1_gof.jpeg", res = 300, height = 9, width = 6, units = "in")
par(mfrow = c(3, 2))
plot(gof1,  plotlogodds = TRUE)
dev.off()

# Randomly sample a network from the specified model
#sim.1 = simulate(netmodel.1, burnin = 1e+6, verbose = TRUE, seed = 9, constraints = ~ fixedas(absent = absent))
#/!\ Takes a while
#save(sim.1, file = "sim1_network.Rdata")
load(file = "sim1_network.Rdata")

# Comparison simulated/observed network
mixingmatrix(sim.1, "production")
mixingmatrix(net1, "production")

# Plot
set.seed(123)
jpeg("sim1_network.jpeg", res = 300, height = 12, width = 12, units = "in")
plot(sim.1, vertex.col = pal_lancet("lanonc")(3)[c(1,3,2)][as.numeric(herds$production)], main = "Edges", cex.main = 4)
par(xpd = T)
legend(x = par("usr")[1]+400, y = par("usr")[3]+25, legend = c("B", "BF", "F"), col = pal_lancet("lanonc")(3)[c(1,3,2)], bty = "n", pch = 19, horiz = T, cex = 3)
dev.off()


# EDGES + NETWORK STATISTICS

# Number of isolates
#netmodel.2 = ergm(net1 ~ edges + isolates, control = control.ergm(seed = 9))
#summary(netmodel.2) # AIC = 206078

# Number of asymmetric links
#netmodel.2 = ergm(net1 ~ edges + asymmetric, control = control.ergm(seed = 9))
#summary(netmodel.2) # AIC = 206750

# Geometrically weighted dyadwise shared partners
#netmodel.2 = ergm(net1 ~ edges + gwdsp(0.5, fixed = TRUE), control = control.ergm(seed = 9))
#summary(netmodel.2) # AIC = 189637  

# Geometrically weighted edgewise shared partners
#netmodel.2 = ergm(net1 ~ edges + gwesp(0.5, fixed = TRUE), control = control.ergm(seed = 9))
#summary(netmodel.2) # AIC = 205075

# Geometrically weighted in-degree distribution
#netmodel.2 = ergm(net1 ~ edges + gwidegree(0.5, fixed = TRUE), control = control.ergm(seed = 9))
#summary(netmodel.2) # AIC = 206229

# Geometrically weighted out-degree distribution
#netmodel.2 = ergm(net1 ~ edges + gwodegree(0.5, fixed = TRUE), control = control.ergm(seed = 9))
#summary(netmodel.2) # No convergence and model degeneracy


# Two terms
#netmodel.2 = ergm(net1 ~ edges + gwdsp(0.5, fixed = TRUE) + gwesp(0.5, fixed = TRUE), control = control.ergm(seed = 9))
#summary(netmodel.2) # AIC = 187446

#netmodel.2 = ergm(net1 ~ edges + gwdsp(0.5, fixed = TRUE) + isolates, control = control.ergm(seed = 9))
#summary(netmodel.2) # Model degeneracy

#netmodel.2 = ergm(net1 ~ edges + gwdsp(0.5, fixed = TRUE) + gwidegree(0.5, fixed = TRUE), control = control.ergm(seed = 9))
#summary(netmodel.2) # No convergence and model degeneracy

#netmodel.2 = ergm(net1 ~ edges + gwdsp(0.5, fixed = TRUE) + asymmetric, control = control.ergm(seed = 9))
#summary(netmodel.2) # AIC = 189600 

#netmodel.2 = ergm(net1 ~ edges + gwdsp(0.5, fixed = TRUE) + gwodegree(0.5, fixed = TRUE), control = control.ergm(seed = 9))
#summary(netmodel.2) # No convergence and model degeneracy


# Three terms (Final model)
netmodel.2 = ergm(net1 ~ edges + gwdsp(0.5, fixed = TRUE) + gwesp(0.5, fixed = TRUE) + isolates , control = control.ergm(seed = 9))
summary(netmodel.2) # AIC = 186264

#netmodel.2 = ergm(net1 ~ edges + gwdsp(0.5, fixed = TRUE) + gwesp(0.5, fixed = TRUE) + asymmetric, control = control.ergm(seed = 9))
#summary(netmodel.2) # No convergence

# Diagnostic plots for MCMC sampled statistics
pdf("model2diagnostics.pdf")
mcmc.diagnostics(netmodel.2)
dev.off()

# Goodness of fit
gof2 = gof(netmodel.2, verbose = TRUE, burnin = 1e+5,
           interval = 1e+5, control.gof.ergm(seed = 123))
jpeg("sim2_gof.jpeg", res = 300, height = 9, width = 6, units = "in")
par(mfrow = c(3, 2))
plot(gof2,  plotlogodds = TRUE)
dev.off()

# Randomly sample a network from the specified model
#sim.2 = simulate(netmodel.2, burnin = 1e+6, verbose = TRUE, seed = 9, constraints = ~ fixedas(absent = absent)) # Adding constraints does not work (?)
#/!\ Takes a while
#save(sim.2, file = "sim2_network.Rdata")
load(file = "sim2_network.Rdata")

# Comparison simulated/observed network
mixingmatrix(sim.2, "production")
mixingmatrix(net1, "production")

# Plot
set.seed(123)
jpeg("sim2_network.jpeg", res = 300, height = 12, width = 12, units = "in")
plot(sim.2, vertex.col = pal_lancet("lanonc")(3)[c(1,3,2)][as.numeric(herds$production)], main = "Edges + structure", cex.main = 4)
par(xpd = T)
legend(x = par("usr")[1]+400, y = par("usr")[3]+25, legend = c("B", "BF", "F"), col = pal_lancet("lanonc")(3)[c(1,3,2)], bty = "n", pch = 19, horiz = T, cex = 3)
dev.off()


# EDGES + ATTRIBUTES

# Number of ingoing edges
#netmodel.3 = ergm(net1 ~ edges + nodeifactor("production", levels = c("F")), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 206646

#netmodel.3 = ergm(net1 ~ edges + nodeifactor("is_commercial", levels = c("1")), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 206664 

#netmodel.3 = ergm(net1 ~ edges + nodeifactor("is_outdoor", levels = c("1")), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 206751

#netmodel.3 = ergm(net1 ~ edges + nodeifactor("multisite"), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 206437


# Number of outgoing edges
#netmodel.3 = ergm(net1 ~ edges + nodeofactor("production", levels = c("B")), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 169332

#netmodel.3 = ergm(net1 ~ edges + nodeofactor("is_commercial", levels = c("1")), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 202003

#netmodel.3 = ergm(net1 ~ edges + nodeofactor("is_outdoor", levels = c("1")), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 204840

#netmodel.3 = ergm(net1 ~ edges + nodeofactor("multisite", levels = -c(1,19,21,26,36,45,60,61,63,83,95,96,99,105,116,118,126)), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 196463


# Uniform homophily
#netmodel.3 = ergm(net1 ~ edges + nodematch("production", diff = FALSE), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 196931

#netmodel.3 = ergm(net1 ~ edges + nodematch("is_commercial", diff = FALSE), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 205419

#netmodel.3 = ergm(net1 ~ edges + nodematch("is_outdoor", diff = FALSE), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 206398

#netmodel.3 = ergm(net1 ~ edges + nodematch("multisite", diff = FALSE), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 206377


# Differential homophily
#netmodel.3 = ergm(net1 ~ edges + nodematch("production", diff = TRUE,  levels = "BF"), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 206570

#netmodel.3 = ergm(net1 ~ edges + nodematch("is_commercial", diff = TRUE), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 204184

#netmodel.3 = ergm(net1 ~ edges + nodematch("is_outdoor", diff = TRUE), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 205874

#netmodel.3 = ergm(net1 ~ edges + nodematch("multisite", diff = TRUE, levels = -c(1,19,21,26,36,45,60,61,63,83,95,96,99,105,116,118,126)), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 194442


# Selective mixing
#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 165471

#netmodel.3 = ergm(net1 ~ edges + nodemix("is_commercial", levels2 = c(2:4)), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 201920 

#netmodel.3 = ergm(net1 ~ edges + nodemix("is_outdoor", levels2 = c(2:4)), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 204844


# Euclidean distance between pairs
#netmodel.3 = ergm(net1 ~ edges + edgecov(d_ij),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 206678


# Size of the node
#netmodel.3 = ergm(net1 ~ edges + nodecov("size"),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 191187


# Two terms
#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodeofactor("production", levels = c("B")),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # Incorrect estimates

#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodecov("size"),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 161072

#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodematch("multisite", diff = TRUE, levels = -c(1,19,21,26,36,45,60,61,63,83,95,96,99,105,116,118,126)),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 153316

#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodeofactor("multisite", levels = -c(1,19,21,26,36,45,60,61,63,83,95,96,99,105,116,118,126)), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 162951

#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodematch("production", diff = FALSE), 
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # Incorrect estimates

#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodemix("is_commercial", levels2 = c(2:4)),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 164463

#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodeofactor("is_commercial", levels = c("1")),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 164697 


# Three terms
#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodematch("multisite", diff = TRUE, levels = -c(1,19,21,26,36,45,60,61,63,83,95,96,99,105,116,118,126)) + nodecov("size"),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 149370

#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodematch("multisite", diff = TRUE, levels = -c(1,9,19,21,26,36,45,60,61,63,68,77,83,91:92,95,96,99,105,116,118,119,125,126)) + nodeofactor("multisite", levels = -c(1,9,14,17,19,21,26,29,33,36,41,45,48,54:55,58:63,67:68,73,77:78,80:81,83,88,91:92,95,96,99,105,116,118,119,125,126)),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 150250

#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodematch("multisite", diff = TRUE, levels = -c(1,19,21,26,36,45,60,61,63,83,95,96,99,105,116,118,126)) + nodemix("is_commercial", levels2 = c(2:4)),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 152628

#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodematch("multisite", diff = TRUE, levels = -c(1,19,21,26,36,45,60,61,63,83,95,96,99,105,116,118,126)) + nodeofactor("is_commercial", levels = c("1")),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 152710


# Four terms (final model)
#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodematch("multisite", diff = TRUE, levels = -c(1,19,21,26,36,45,60,61,63,83,95,96,99,105,116,118,126)) + nodecov("size") + nodeofactor("multisite", levels = -c(1,2,9,14,17,19,21,26:27,29,33,35:36,41,45,48,54:55,58:63,67:68,73,77:78,80:81,83,88,91:92,95,96,99,105,116,118,119,125,126)),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # Incorrect estimates

#netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodematch("multisite", diff = TRUE, levels = -c(1,19,21,26,36,45,60,61,63,83,95,96,99,105,116,118,126)) + nodecov("size") + nodeofactor("is_commercial", levels = c("1")),             
#                  verbose = TRUE, control = control.ergm(seed = 9))
#summary(netmodel.3) # AIC = 149100

netmodel.3 = ergm(net1 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodematch("multisite", diff = TRUE, levels = -c(1,19,21,26,36,45,60,61,63,83,95,96,99,105,116,118,126)) + nodecov("size") + nodemix("is_commercial", levels2 = c(2:4)),             
                  verbose = TRUE, control = control.ergm(seed = 9))
summary(netmodel.3) # AIC = 149075
save(netmodel.3, file = "final_ERGM.Rdata")

# Goodness of fit
gof3 = gof(netmodel.3, verbose = TRUE, burnin = 1e+5,
           interval = 1e+5, control.gof.ergm(seed = 123))
jpeg("sim3_gof.jpeg", res = 300, height = 9, width = 6, units = "in")
par(mfrow = c(3, 2))
plot(gof3,  plotlogodds = TRUE)
dev.off()

# Randomly sample a network from the specified model
#sim.3 = simulate(netmodel.3, burnin = 1e+6, verbose = TRUE, seed = 9, constraints = ~ fixedas(absent = absent))
#/!\ Takes a while
#save(sim.3, file = "sim3_network.Rdata")
load(file = "sim3_network.Rdata")

# Comparison simulated/observed network
mixingmatrix(sim.3, "production")
mixingmatrix(net1, "production")

# Plot
set.seed(123)
jpeg("sim3_network.jpeg", res = 300, height = 12, width = 12, units = "in")
plot(sim.3, vertex.col = pal_lancet("lanonc")(3)[c(1,3,2)][as.numeric(herds$production)], main = "Edges + attributes", cex.main = 4)
par(xpd = T)
legend(x = (par("usr")[2]-par("usr")[1])/2, y = par("usr")[3]+25, legend = c("B", "BF", "F"), col = pal_lancet("lanonc")(3)[c(1,3,2)], bty = "n", pch = 19, horiz = T, cex = 3)
dev.off()


# EDGES + ATTRIBUTES + NETWORK STATISTICS
# No convergence and model degeneracy


#########################
# ERGM: TESTING DATASET #
#########################

# Keep the last month of data to assess the predictive ability
moves2 = moves[moves$date >  (max(moves$date)-30),]
net2 = network(unique(moves2[,c("source","dest")]), matrix.type = "edgelist", directed = TRUE, multiple = FALSE)
summary(net2)

# Attribute herd characteristics to each node
net2 %v% "size"          = herds$size
net2 %v% "production"    = as.character(herds$production)
net2 %v% "is_outdoor"    = herds$is_outdoor
net2 %v% "is_commercial" = herds$is_commercial
net2 %v% "multisite"     = herds$multisite

# Plot
set.seed(123)
jpeg("test_data_network.jpeg", res = 300, height = 12, width = 12, units = "in")
plot(net2, vertex.col = pal_lancet("lanonc")(3)[c(1,3,2)][as.numeric(herds$production)])
dev.off()

load(file = "final_ERGM.Rdata")

# Randomly sample a network from the specified model
#sim.4 = simulate(net2 ~ edges + nodemix("production", levels2 = c(4,7:8)) + nodematch("multisite", diff = TRUE, levels = -c(1,19,21,26,36,45,60,61,63,83,95,96,99,105,116,118,126)) + nodecov("size") + nodemix("is_commercial", levels2 = c(2:4)),
#                 coef = coef(netmodel.3), burnin = 1e+6, verbose = TRUE, seed = 9, constraints = ~ fixedas(absent = absent))
#/!\ Takes a while
#save(sim.4, file = "sim4_network.Rdata")
load(file = "sim4_network.Rdata")

# Comparison simulated/observed network
mixingmatrix(sim.4, "production")
mixingmatrix(net2, "production")

# Plot
set.seed(123)
jpeg("sim4_network.jpeg", res = 300, height = 12, width = 12, units = "in")
plot(sim.4, vertex.col = pal_lancet("lanonc")(3)[c(1,3,2)][as.numeric(herds$production)])
dev.off()


##########################
# STOCHASTIC REPETITIONS #
##########################

Sens = c()
Spec = c()

for (SEED in 1:32){
  setwd(paste(wd, "/Moves_Simul/Se", sep = ""))
  load(paste("mov_Se_", SEED, ".Rdata", sep = ""))
  Sens = c(Sens, Se)
  setwd(paste(wd, "/Moves_Simul/Sp", sep = ""))
  load(paste("mov_Sp_", SEED, ".Rdata", sep = ""))
  Spec = c(Spec, Sp)
}

quantile(Sens, probs = c(0.025, 0.5, 0.975))
quantile(Spec, probs = c(0.025, 0.5, 0.975))
