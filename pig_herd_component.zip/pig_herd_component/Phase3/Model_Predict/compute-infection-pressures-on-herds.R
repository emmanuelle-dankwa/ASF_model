################################################################
# INFECTIOUS PRESSURE ON HERDS GIVEN WILD BOAR MODEL ESTIMATES #
#                 ASF CHALLENGE - UK TEAM                      #
#                                                              #
#                     Phase 3 - 2021/01/13                     #
################################################################


###########
# LIBRARY #
###########

library(sp)    # R Package: point.in.polygon function
library(tidyr) # R Package: crossing function

##############################
# IMPORT WILD BOAR ESTIMATES #
##############################

# Set working directory
setwd(paste(wd, "/Model_Predict/input", sep = ""))

if (increas){
  
  res                 = readRDS("param_estims_phase_3.RDS")
  abc.estims          = res$estims                             # 500 (iterations) x 1 (number of parameters: beta) matrix
  abc.status.matrices = res$mat[[SEED]]                        # list having 51 status matrices, one for each day (from day 60 to day 110)
  abc.locations       = res$locations[[SEED]]                  # list having a matrix of individual boars (84603 rows)
  rm(res)
  
  locations59         <- readRDS("locations.day.59.RDS")
  locations60         <- readRDS("locations60.RDS")   
  bck.locations       <- rbind(locations59, locations60[,colnames(locations59)])      
  bck.status.matrices = list()
  
  for(i in min(bck.locations$date.infected, na.rm = T):max(locations59$date.removed)){
    infectionStatusMatrix = matrix(0, nrow = nrow(abc.status.matrices[[1]]), ncol = ncol(abc.status.matrices[[1]]))
    infectionStatusMatrix[bck.locations$patch[bck.locations$infectionStatus > 0 & bck.locations$date.infected <= i & bck.locations$date.removed > i & (bck.locations$date.infected+104) > i]] = 1
    bck.status.matrices[[i-min(bck.locations$date.infected, na.rm = T)+1]] = infectionStatusMatrix
  }
  
  res2 = readRDS(paste("forward.run.", ifelse(increas, "increased", "normal"), ".pressure.140.RDS", sep = ""))
  fwd.status.matrices = res2$status.matrices[[SEED]]    # list having 30 status matrices, one for each day
  fwd.locations       = res2$locations[[SEED]]          # list having a matrix of individual boars (84603 rows)
  rm(res2)
  
} else {
  
  res = readRDS("param_estims_phase2.RDS")
  abc.estims          = res$estims                      # 500 (iterations) x 1 (number of parameters: beta) matrix
  abc.status.matrices = res$mat[[SEED]]                 # list having 80 status matrices, one for each day
  abc.locations       = res$locations[[SEED]]           # list having a matrix of individual boars (95144 rows)
  rm(res)
  
  res2 = readRDS(paste("forward.run.", ifelse(increas, "increased", "normal"), ".pressure.140.RDS", sep = ""))
  fwd.status.matrices = res2$status.matrices[[SEED]]    # list having 81 status matrices, one for each day (from 60 to 140)
  fwd.locations       = res2$locations[[SEED]]          # list having a matrix of individual boars (95144 rows)

  rm(res2)
}


##############
# PARAMETERS #
##############

patchcentres = readRDS("patchcentres.RDS")         
npatches_x = npatches_y =  nrow(patchcentres)
patchcentres_x = patchcentres$X
patchcentres_y = patchcentres$Y
max.infection.range = 8000

##################
# INITIALIZATION #
##################

timings.max = max(fwd.locations$date.removed2)
timings.int = ifelse(increas, max(abc.locations$date.removed2) - length(abc.status.matrices),
                              timings.max - length(fwd.status.matrices))
timings.min = ifelse(increas, min(bck.locations$date.infected, na.rm = T), 1)
abc.times   = timings.min:(timings.max-length(fwd.status.matrices))
fwd.times   = (timings.max-length(fwd.status.matrices))+(1:length(fwd.status.matrices))
final.pressure = list()                             # List to save pressure vectors at each iteration
outdoor.herd.indices = which(herds$is_outdoor == 1) # Get indices for outdoor farms. Pressures are not calculated for indoor farms as the probability of contact with WB in those farms is negligible. 

### Determine patches that fall within fence ###
if(fence){ # if fence = TRUE
  # Vertices of fence are: A,B,C,D, beginning from lower-left vertex and labelling counterclockwise
  A = c(773676.4, 6347189)
  B = c(833676.4, 6347189)
  C = c(833676.4, 6437189)
  D = c(773676.4, 6437189)
  
  rectangular.fence = data.frame(id = LETTERS[1:4], 
                                  X = c(A[1], B[1], C[1], D[1]),
                                  Y = c(A[2], B[2], C[2], D[2]))
  
  
  all.patch.centres = tidyr::crossing(X = patchcentres$X, Y = patchcentres$Y) 
  
  # Determine responses to "Is patch i in fence"?
  in.fence = sp::point.in.polygon(point.x = all.patch.centres$X, point.y= all.patch.centres$Y,
                                   pol.x = rectangular.fence$X, pol.y = rectangular.fence$Y)
  
  in.fence.matrix = matrix(in.fence, nrow = npatches_x, ncol = npatches_y)
  
  # Identify outdoor herds in relation to fence
  herdsInFence    = outdoor.herd.indices[sp::point.in.polygon(point.x = herds$X[outdoor.herd.indices], point.y= herds$Y[outdoor.herd.indices],
                                                               pol.x = rectangular.fence$X, pol.y = rectangular.fence$Y) != 0]
  herdsNotInFence = outdoor.herd.indices[sp::point.in.polygon(point.x = herds$X[outdoor.herd.indices], point.y= herds$Y[outdoor.herd.indices],
                                                               pol.x = rectangular.fence$X, pol.y = rectangular.fence$Y) == 0]
}

######################################################
# COMPUTE INFECTIOUS PRESSURES BY WILD BOAR ON HERDS #
######################################################
# Use distance kernel function:  K(d, alpha_wb) = beta_wb*exp(-d/alpha_wb); beta_wb is rate of infection from WB to herd,
# d is the distance between infected wild boar and herds, 
# alpha is the length scale of transmission.

  if (increas){
    updated.boar = bck.locations
  } else {
    updated.boar = abc.locations
  }
  infectiousPressureWB = matrix (0, nrow = nrow(herds), ncol = length(abc.times)+length(fwd.times))   # Matrix to store infectious pressure from WB
  infectionStatusMatrix = matrix(0, nrow = nrow(patchcentres), ncol = nrow(patchcentres))
  infectionStatusMatrix[unique(updated.boar$patch[updated.boar$infectionStatus > 0 & updated.boar$date.infected <= timings.min & updated.boar$date.removed > timings.min & (updated.boar$date.infected+104) > timings.min])] = 1
  
  # Set kernel parameters 
  beta_wb  = abc.estims[SEED, 1]
  alpha_wb = ifelse(increas, 1000, 870)

  # From ABC estimation (day 1 to 110)
  for(t in abc.times){

    ## WORK OUT INFECTIOUS PRESSURE ON EACH HERD ##    
    if (fence & t>=(timings.int+1)){   # IMPLEMENT FENCE AFTER DAY 60
      
      # Identify infected patches positions inside the fence
      rowInFence = as.data.frame(which(infectionStatusMatrix == 1 & in.fence.matrix == 1, arr.ind = TRUE))$row
      colInFence = as.data.frame(which(infectionStatusMatrix == 1 & in.fence.matrix == 1, arr.ind = TRUE))$col
      LinIdx_I   = (colInFence-1)*nrow(infectionStatusMatrix) + rowInFence
      
      # Count number of infected boars in infected patches inside the fence
      mat = updated.boar[updated.boar$patch %in% LinIdx_I,]
      numb.inf.boar.in.inf.patches = sapply(1:length(LinIdx_I), function(i) sum(mat$patch == LinIdx_I[i] & mat$infectionStatus > 0 & mat$date.infected <= t & (mat$date.infected+104) > t))
      
      for (k in herdsInFence){ # if herd is in fence, infection pressure only by patches in fence
        # Identify patches inside the fence which fall within the infection range
        dist = sqrt((patchcentres_x[colInFence] - herds$X[k])^2 + (patchcentres_y[rowInFence] - herds$Y[k])^2)
        in.infect.range = which(dist <= max.infection.range)
        
        infectiousPressureWB[k, t-timings.min+1] = sum(beta_wb*exp(-dist[in.infect.range]/alpha_wb) * numb.inf.boar.in.inf.patches[in.infect.range])
      }

      for (k in herdsNotInFence){ # if herd is not in fence, infection pressure only by patches in fence within max.infection.range/2
        # Identify patches inside the fence which fall within max.infection.range/2
        dist = sqrt((patchcentres_x[colInFence] - herds$X[k])^2 + (patchcentres_y[rowInFence] - herds$Y[k])^2)
        in.infect.range.within.fence = which(dist <= max.infection.range/2)        
        
        infectiousPressureWB[k, t-timings.min+1] = sum(beta_wb*exp(-dist[in.infect.range.within.fence]/alpha_wb) * numb.inf.boar.in.inf.patches[in.infect.range.within.fence])
      }
      
      # Identify infected patches positions outside the fence
      rowNotInFence = as.data.frame(which(infectionStatusMatrix == 1 & in.fence.matrix == 0, arr.ind = TRUE))$row
      colNotInFence = as.data.frame(which(infectionStatusMatrix == 1 & in.fence.matrix == 0, arr.ind = TRUE))$col
      LinIdx_I      = (colNotInFence-1)*nrow(infectionStatusMatrix) + rowNotInFence
      
      # Count number of infected boars in infected patches outside the fence
      mat = updated.boar[updated.boar$patch %in% LinIdx_I,]
      numb.inf.boar.in.inf.patches = sapply(1:length(LinIdx_I), function(i) sum(mat$patch == LinIdx_I[i] & mat$infectionStatus > 0 & mat$date.infected <= t & (mat$date.infected+104) > t))
      
      for (k in herdsNotInFence){ # if herd is not in fence, infection pressure only by patches outside fence
        # Identify patches outside the fence which fall within the infection range
        dist = sqrt((patchcentres_x[colNotInFence] - herds$X[k])^2 + (patchcentres_y[rowNotInFence] - herds$Y[k])^2)
        in.infect.range = which(dist <= max.infection.range)
        
        infectiousPressureWB[k, t-timings.min+1] = infectiousPressureWB[k, t-timings.min+1] +
                                                    sum(beta_wb*exp(-dist[in.infect.range]/alpha_wb) * numb.inf.boar.in.inf.patches[in.infect.range])
      }
 
      for (k in herdsInFence){ # if herd is in fence, infection pressure only by patches outside fence within max.infection.range/2
        # Identify patches outside the fence which fall within max.infection.range/2
        dist = sqrt((patchcentres_x[colNotInFence] - herds$X[k])^2 + (patchcentres_y[rowNotInFence] - herds$Y[k])^2)
        in.infect.range.outside.fence = which(dist <= max.infection.range/2)        
        
        infectiousPressureWB[k, t-timings.min+1] = infectiousPressureWB[k, t-timings.min+1] +
                                                    sum(beta_wb*exp(-dist[in.infect.range.outside.fence]/alpha_wb) * numb.inf.boar.in.inf.patches[in.infect.range.outside.fence])
      }
      
    } else {              # IF LESS THAN DAY 60 OR FENCE = FALSE, COMPUTE PRESSURES 'AS USUAL'

      # Identify infected patches
      row = as.data.frame(which(infectionStatusMatrix == 1, arr.ind = TRUE))$row
      col = as.data.frame(which(infectionStatusMatrix == 1, arr.ind = TRUE))$col
      LinIdx_I   = (col-1)* nrow(infectionStatusMatrix) + row
      
      # Count number of infected boars in infected patches
      mat = updated.boar[updated.boar$patch %in% LinIdx_I,]
      numb.inf.boar.in.inf.patches = sapply(1:length(LinIdx_I), function(i) sum(mat$patch == LinIdx_I[i] & mat$infectionStatus > 0 & mat$date.infected <= t & (mat$date.infected+104) > t))
      
      for (k in outdoor.herd.indices){
        # Identify patches which fall within the infection range
        dist = sqrt((patchcentres_x[col] - herds$X[k])^2 + (patchcentres_y[row] - herds$Y[k])^2)
        in.infect.range = which(dist <= max.infection.range)
        
        infectiousPressureWB[k, t-timings.min+1] = sum(beta_wb*exp(-dist[in.infect.range]/alpha_wb) * numb.inf.boar.in.inf.patches[in.infect.range])
      }
    }
    
    ### UPDATE BOAR NUMBERS
    if (t == (timings.int+1) & increas){
      updated.boar = abc.locations
    }
    if (t == max(abc.times)){
      updated.boar = fwd.locations
    }
    if (t>=(timings.int+1)){
      boar.removed = which(updated.boar$date.removed2 == t)
    } else {
      boar.removed = which(updated.boar$date.removed == t)
    }
    if (length(boar.removed) != 0){
      updated.boar = updated.boar[-boar.removed, ]
    }
    infectionStatusMatrix = matrix(0, nrow = nrow(patchcentres), ncol = nrow(patchcentres))
    infectionStatusMatrix[unique(updated.boar$patch[updated.boar$infectionStatus > 0 & updated.boar$date.infected <= t & (updated.boar$date.infected+104) > t])] = 1
  }

  # Forward predictions (day 111 to 140)
  for(t in fwd.times){
    
    ## WORK OUT INFECTIOUS PRESSURE ON EACH HERD ##    
    if (fence & t>=(timings.int+1)){   # IMPLEMENT FENCE AFTER DAY 60
      
      # Identify infected patches positions inside the fence
      rowInFence = as.data.frame(which(infectionStatusMatrix == 1 & in.fence.matrix == 1, arr.ind = TRUE))$row
      colInFence = as.data.frame(which(infectionStatusMatrix == 1 & in.fence.matrix == 1, arr.ind = TRUE))$col
      LinIdx_I   = (colInFence-1)*nrow(infectionStatusMatrix) + rowInFence
      
      # Count number of infected boars in infected patches inside the fence
      mat = updated.boar[updated.boar$patch %in% LinIdx_I,]
      numb.inf.boar.in.inf.patches = sapply(1:length(LinIdx_I), function(i) sum(mat$patch == LinIdx_I[i] & mat$infectionStatus > 0 & mat$date.infected <= t & (mat$date.infected+104) > t))
      
      for (k in herdsInFence){ # if herd is in fence, infection pressure only by patches in fence
        # Identify patches inside the fence which fall within the infection range
        dist = sqrt((patchcentres_x[colInFence] - herds$X[k])^2 + (patchcentres_y[rowInFence] - herds$Y[k])^2)
        in.infect.range = which(dist <= max.infection.range)
        
        infectiousPressureWB[k, t-timings.min+1] = sum(beta_wb*exp(-dist[in.infect.range]/alpha_wb) * numb.inf.boar.in.inf.patches[in.infect.range])
      }
      
      for (k in herdsNotInFence){ # if herd is not in fence, infection pressure only by patches in fence within max.infection.range/2
        # Identify patches inside the fence which fall within max.infection.range/2
        dist = sqrt((patchcentres_x[colInFence] - herds$X[k])^2 + (patchcentres_y[rowInFence] - herds$Y[k])^2)
        in.infect.range.within.fence = which(dist <= max.infection.range/2)        
        
        infectiousPressureWB[k, t-timings.min+1] = sum(beta_wb*exp(-dist[in.infect.range.within.fence]/alpha_wb) * numb.inf.boar.in.inf.patches[in.infect.range.within.fence])
      }
      
      # Identify infected patches positions outside the fence
      rowNotInFence = as.data.frame(which(infectionStatusMatrix == 1 & in.fence.matrix == 0, arr.ind = TRUE))$row
      colNotInFence = as.data.frame(which(infectionStatusMatrix == 1 & in.fence.matrix == 0, arr.ind = TRUE))$col
      LinIdx_I      = (colNotInFence-1)*nrow(infectionStatusMatrix) + rowNotInFence
      
      # Count number of infected boars in infected patches outside the fence
      mat = updated.boar[updated.boar$patch %in% LinIdx_I,]
      numb.inf.boar.in.inf.patches = sapply(1:length(LinIdx_I), function(i) sum(mat$patch == LinIdx_I[i] & mat$infectionStatus > 0 & mat$date.infected <= t & (mat$date.infected+104) > t))
      
      for (k in herdsNotInFence){ # if herd is not in fence, infection pressure only by patches outside fence
        # Identify patches outside the fence which fall within the infection range
        dist = sqrt((patchcentres_x[colNotInFence] - herds$X[k])^2 + (patchcentres_y[rowNotInFence] - herds$Y[k])^2)
        in.infect.range = which(dist <= max.infection.range)
        
        infectiousPressureWB[k, t-timings.min+1] = infectiousPressureWB[k, t-timings.min+1] +
          sum(beta_wb*exp(-dist[in.infect.range]/alpha_wb) * numb.inf.boar.in.inf.patches[in.infect.range])
      }
      
      for (k in herdsInFence){ # if herd is in fence, infection pressure only by patches outside fence within max.infection.range/2
        # Identify patches outside the fence which fall within max.infection.range/2
        dist = sqrt((patchcentres_x[colNotInFence] - herds$X[k])^2 + (patchcentres_y[rowNotInFence] - herds$Y[k])^2)
        in.infect.range.outside.fence = which(dist <= max.infection.range/2)        
        
        infectiousPressureWB[k, t-timings.min+1] = infectiousPressureWB[k, t-timings.min+1] +
          sum(beta_wb*exp(-dist[in.infect.range.outside.fence]/alpha_wb) * numb.inf.boar.in.inf.patches[in.infect.range.outside.fence])
      }
      
    } else {              # IF LESS THAN DAY 60 OR FENCE = FALSE, COMPUTE PRESSURES 'AS USUAL'
      
      # Identify infected patches
      row = as.data.frame(which(infectionStatusMatrix == 1, arr.ind = TRUE))$row
      col = as.data.frame(which(infectionStatusMatrix == 1, arr.ind = TRUE))$col
      LinIdx_I   = (col-1)* nrow(infectionStatusMatrix) + row
      
      # Count number of infected boars in infected patches
      mat = updated.boar[updated.boar$patch %in% LinIdx_I,]
      numb.inf.boar.in.inf.patches = sapply(1:length(LinIdx_I), function(i) sum(mat$patch == LinIdx_I[i] & mat$infectionStatus > 0 & mat$date.infected <= t & (mat$date.infected+104) > t))
      
      for (k in outdoor.herd.indices){
        # Identify patches which fall within the infection range
        dist = sqrt((patchcentres_x[col] - herds$X[k])^2 + (patchcentres_y[row] - herds$Y[k])^2)
        in.infect.range = which(dist <= max.infection.range)
        
        infectiousPressureWB[k, t-timings.min+1] = sum(beta_wb*exp(-dist[in.infect.range]/alpha_wb) * numb.inf.boar.in.inf.patches[in.infect.range])
      }
    }
    
    ### UPDATE BOAR NUMBERS
    boar.removed = which(updated.boar$date.removed2 == t)
    if (length(boar.removed) != 0){
      updated.boar = updated.boar[-boar.removed, ]
    }
    infectionStatusMatrix = matrix(0, nrow = nrow(patchcentres), ncol = nrow(patchcentres))
    infectionStatusMatrix[unique(updated.boar$patch[updated.boar$infectionStatus > 0 & updated.boar$date.infected <= t & (updated.boar$date.infected+104) > t])] = 1
  }
  
