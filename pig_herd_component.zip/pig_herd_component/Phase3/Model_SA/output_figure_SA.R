#########################################
# ASF MODEL FOR PIG HERDS - PREDICTIONS #
#     ASF CHALLENGE - UK TEAM           #
#                                       #
#         Phase 3 - 2021/01/13          #
#########################################

rm(list = ls()) # remove (almost) everything in the working environment

# Set to your working directory
wd = "~/pig_herd_component/Phase3"


###########
# LIBRARY #
###########

library(ggsci)    # R Package: Scientific Journal Themed Color Palettes
library(rgdal)    # R Package: function readOGR
library(SDMTools) # R Package: function legend.gradient

###############
## SCENARIOS ##
###############

forward  = FALSE # Forward predictions (30 days) or not
fwddays  = 30    # Number of time steps (days) in the forward predictions
fence    = TRUE  # Scenario: fencing
increas  = TRUE  # Scenario: increased hunting pressure on wild boars inside the fence


########
# DATA #
########

# Set working directory
setwd(paste(wd, "/Data_Outbreak", sep = ""))

moves       = read.csv("moves_Players_day_110.csv", header = TRUE)          # List of all known movements of live pigs
delta       = abs(min(moves$date)) + 1                                      # Number of days in the data before the first detected case (2 months)
moves$date  = moves$date + delta                                            # Shift movement dates to start at t=1
max.date    = max(moves$date)                                               # Total number of days in the data
timeseries  = read.csv("TimeSeries_day_110_all.csv", header = TRUE)         # Characteristics of the outbreaks and wild boar cases
timeseries  = timeseries[timeseries$HOST == "pig herd",]                    # Keep only outbreaks in pig herds
num.series1 = rep(NA, max.date)                                             # Dates of herd outbreaks (suspected)
num.series1[unique(timeseries$DATE.SUSP[!timeseries$DET %in% c("NPC", "PPC")] + delta)] = table(timeseries$DATE.SUSP[!timeseries$DET %in% c("NPC", "PPC")] + delta)
num.series1[!is.na(num.series1)] = cumsum(num.series1[!is.na(num.series1)]) # Cumulative number of herd outbreaks
num.series2 = rep(NA, max.date)                                             # Dates of herd outbreaks (confirmed)
num.series2[unique(timeseries$DATE.CONF[!timeseries$DET %in% c("NPC")] + delta)] = table(timeseries$DATE.CONF[!timeseries$DET %in% c("NPC")] + delta)
num.series2[!is.na(num.series2)] = cumsum(num.series2[!is.na(num.series2)]) # Cumulative number of herd outbreaks
herds = read.csv("herds_day_110.csv", header = TRUE)                        # Characteristics of all pig sites


################
# MODEL OUTPUT #
################

for (parname in c("mir", "alpha", "infc", "infd")){
  
  npar = ifelse(parname == "infd", 3, 4)
  results = array(data = NA, dim = c(npar, 7),
                  dimnames = list(NULL, c("values",
                                          "det_median", "det_lower", "det_upper",
                                          "inf_median", "inf_lower", "inf_upper")))
  
  num.susp.herds  = array(0, dim = c(npar, 100, max.date + forward * fwddays))
  prob.susp.herds = array(0, dim = c(npar, 100, nrow(herds)))
  num.conf.herds  = array(0, dim = c(npar, 100, max.date + forward * fwddays))
  prob.conf.herds = array(0, dim = c(npar, 100, nrow(herds)))
  num.inf.herds   = array(0, dim = c(npar, 100, max.date + forward * fwddays))
  prob.inf.herds  = array(0, dim = c(npar, 100, nrow(herds)))
  
  for (PAR in 1:npar){
    
    mir   = ifelse(parname == "mir",   c(2000, 8000, 14000, 20000)[PAR], 8000)
    infc  = ifelse(parname == "infc",  c(  10,   50,    90,   130)[PAR],   90)
    alpha = ifelse(parname == "alpha", c( 600,  800,  1000,  1200)[PAR], 1000)
    infd  = ifelse(parname == "infd",  c(   5,    7,    10,    14)[PAR],   14)
    
    setwd(paste(wd,
                "/Model_SA/output_",
                parname, "_",
                ifelse(parname == "mir",     mir,
                ifelse(parname == "infc",   infc,
                ifelse(parname == "alpha", alpha, infd))),
                sep = ""))
    
    files = list.files()
    
    for (SEED in 1:length(files)){
      load(file = paste("simul_", SEED, ".Rdata", sep = ""))
      Mat  = simul$Mat
      susp = simul$susp
      CO   = simul$CO
      
      det.herds = susp
      num.susp.herds[PAR, SEED, ] = cumsum(colSums(det.herds))
      prob.susp.herds[PAR, SEED,] = (rowSums(det.herds) != 0)
      
      conf.herds = CO
      num.conf.herds[PAR, SEED, ] = cumsum(colSums(conf.herds))
      prob.conf.herds[PAR, SEED,] = (rowSums(conf.herds) != 0)
      
      Mat2 = Mat["E",,] + Mat["Isc",,] + Mat["Ic",,] + Mat["D",,] 
      inf.herds = matrix(sapply(1:nrow(Mat2), FUN = function(X) c(FALSE, Mat2[X,-1] != 0 & Mat2[X,-ncol(susp)] == 0)),
                         nrow = nrow(Mat2), ncol = ncol(Mat2), byrow = T)   
      
      num.inf.herds[PAR, SEED, ] = cumsum(colSums(inf.herds))
      prob.inf.herds[PAR, SEED,] = (rowSums(inf.herds) != 0)
    }
    
    results[PAR,] = c(ifelse(parname == "mir",     mir,
                      ifelse(parname == "infc",   infc,
                      ifelse(parname == "alpha", alpha, infd))),
                      quantile(num.conf.herds[PAR, , dim(num.conf.herds)[3]], probs = c(0.5, 0.025, 0.975)),
                      quantile(num.inf.herds[PAR, , dim(num.inf.herds)[3]], probs = c(0.5, 0.025, 0.975)))
    
  }
  
  results2 = data.frame(values = apply(combn(1:npar, 2), 2, function(x) paste0(x[1], "-", x[2])),
                        t(apply(apply(combn(1:npar, 2), 2, function(x) 100*(num.conf.herds[x[1], , dim(num.conf.herds)[3]] - num.conf.herds[x[2], , dim(num.conf.herds)[3]])/num.conf.herds[x[2], , dim(num.conf.herds)[3]]),
                                2, quantile, probs = c(0.5, 0.025, 0.975))),
                        t(apply(apply(combn(1:npar, 2), 2, function(x) 100*(num.conf.herds[x[2], , dim(num.conf.herds)[3]] - num.conf.herds[x[1], , dim(num.conf.herds)[3]])/num.conf.herds[x[1], , dim(num.conf.herds)[3]]),
                                2, quantile, probs = c(0.5, 0.025, 0.975))))
  
  print(parname)
  print(results)
  print(results2)
}
