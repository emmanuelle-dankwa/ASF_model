#########################################
# ASF MODEL FOR PIG HERDS - PREDICTIONS #
#     ASF CHALLENGE - UK TEAM           #
#                                       #
#         Phase 3 - 2021/01/13          #
#########################################

rm(list = ls()) # remove (almost) everything in the working environment

# Set to your working directory
wd = "~/pig_herd_component/Phase3"

###########
# LIBRARY #
###########

library(ggsci)    # R Package: Scientific Journal Themed Color Palettes
library(rgdal)    # R Package: function readOGR
library(SDMTools) # R Package: function legend.gradient

###############
## SCENARIOS ##
###############

forward  = TRUE  # Forward predictions (30 days) or not
fwddays  = 120   # Number of time steps (days) in the forward predictions
fence    = FALSE # Scenario: fencing
increas  = FALSE # Scenario: increased hunting pressure on wild boars inside the fence

########
# DATA #
########

# Set working directory
setwd(paste(wd, "/Data_Outbreak", sep = ""))

moves       = read.csv("moves_Players_day_110.csv", header = TRUE)          # List of all known movements of live pigs
delta       = abs(min(moves$date)) + 1                                      # Number of days in the data before the first detected case (2 months)
moves$date  = moves$date + delta                                            # Shift movement dates to start at t=1
max.date    = max(moves$date)                                               # Total number of days in the data
timeseries  = read.csv("TimeSeries_day_110_all.csv", header = TRUE)         # Characteristics of the outbreaks and wild boar cases
timeseries  = timeseries[timeseries$HOST == "pig herd",]                    # Keep only outbreaks in pig herds
num.series1 = rep(NA, max.date)                                             # Dates of herd outbreaks (suspected)
num.series1[unique(timeseries$DATE.SUSP[!timeseries$DET %in% c("NPC", "PPC")] + delta)] = table(timeseries$DATE.SUSP[!timeseries$DET %in% c("NPC", "PPC")] + delta)
num.series1[!is.na(num.series1)] = cumsum(num.series1[!is.na(num.series1)]) # Cumulative number of herd outbreaks
num.series2 = rep(NA, max.date)                                             # Dates of herd outbreaks (confirmed)
num.series2[unique(timeseries$DATE.CONF[!timeseries$DET %in% c("NPC")] + delta)] = table(timeseries$DATE.CONF[!timeseries$DET %in% c("NPC")] + delta)
num.series2[!is.na(num.series2)] = cumsum(num.series2[!is.na(num.series2)]) # Cumulative number of herd outbreaks
herds = read.csv("herds_day_110.csv", header = TRUE)                        # Characteristics of all pig sites


################
# MODEL OUTPUT #
################

setwd(paste(wd, "/Model_Predict_230_NoWB/output", sep = ""))
files = list.files()

num.susp.herds  = matrix(0, nrow = length(files), ncol = max.date + forward * fwddays)
prob.susp.herds = matrix(0, nrow = length(files), ncol = nrow(herds))
num.conf.herds  = matrix(0, nrow = length(files), ncol = max.date + forward * fwddays)
prob.conf.herds = matrix(0, nrow = length(files), ncol = nrow(herds))
num.inf.herds   = matrix(0, nrow = length(files), ncol = max.date + forward * fwddays)
prob.inf.herds  = matrix(0, nrow = length(files), ncol = nrow(herds))
ext             = rep(FALSE, length(files))

for (SEED in 1:length(files)){
  load(file = paste("simul_", SEED, ".Rdata", sep = ""))
  Mat  = simul$Mat
  susp = simul$susp
  CO   = simul$CO

  det.herds = susp
  num.susp.herds[SEED, ] = cumsum(colSums(det.herds))
  prob.susp.herds[SEED,] = (rowSums(det.herds) != 0)

  conf.herds = CO
  num.conf.herds[SEED, ] = cumsum(colSums(conf.herds))
  prob.conf.herds[SEED,] = (rowSums(conf.herds) != 0)
  
  Mat2 = Mat["E",,] + Mat["Isc",,] + Mat["Ic",,] + Mat["D",,] 
  inf.herds = matrix(sapply(1:nrow(Mat2), FUN = function(X) c(FALSE, Mat2[X,-1] != 0 & Mat2[X,-ncol(susp)] == 0)),
                     nrow = nrow(Mat2), ncol = ncol(Mat2), byrow = T)   
  
  num.inf.herds[SEED, ] = cumsum(colSums(inf.herds))
  prob.inf.herds[SEED,] = (rowSums(inf.herds) != 0)
  ext[SEED] = sum(inf.herds[,ncol(inf.herds)]) == 0
}

sum(ext)/length(files)

########
# PLOT #
########

setwd(paste(wd, "/Model_Predict_230_NoWB/figure", sep = ""))

abc.times <- 1:max.date
fwd.times <- max.date:(max.date + forward * fwddays)


jpeg("pig_herds_suspected_num.jpeg", res = 300, height = 6, width = 6, units = "in")

plot(apply(num.susp.herds, 2, median), xlim = c(0,max.date + forward * fwddays), ylim = c(0,150), xaxt = "n", xlab = "Time (days)", ylab = "Number of pig herds", main = "Pig herds detected:\ndate of the suspicious detection", type = "n")
polygon(c(abc.times, rev(abc.times)), c(apply(num.susp.herds, 2, quantile, probs = c(.025))[abc.times], rev(apply(num.susp.herds, 2, quantile, probs = c(.975))[abc.times])), col = adjustcolor(pal_lancet("lanonc")(2)[1], alpha = 0.3), border = "white")
lines(abc.times, apply(num.susp.herds, 2, median)[abc.times], col = pal_lancet("lanonc")(2)[1], lwd = 2)
axis(side = 1, at = seq(0,max(fwd.times),10), labels = seq(0,max(fwd.times),10)-delta)
polygon(c(fwd.times, rev(fwd.times)), c(apply(num.susp.herds, 2, quantile, probs = c(.025))[fwd.times], rev(apply(num.susp.herds, 2, quantile, probs = c(.975))[fwd.times])), col = adjustcolor(pal_lancet("lanonc")(2)[1], alpha = 0.1), border = "white")
lines(fwd.times, apply(num.susp.herds, 2, median)[fwd.times], col = adjustcolor(pal_lancet("lanonc")(2)[1], alpha = 0.5), lwd = 2)
abline(v = min(fwd.times), lty = 2)
points(which(!is.na(num.series1)), num.series1[which(!is.na(num.series1))], type = "b", pch = 19, lwd = 1, col = pal_lancet("lanonc")(2)[2])
legend("topleft", c("Observed", "Model (median)", "Model (95% CI)"), col = c(pal_lancet("lanonc")(2)[2:1], adjustcolor(pal_lancet("lanonc")(2)[1], alpha = 0.3)), lty = c(1,1,NA), lwd = c(2,2,NA), pch = c(NA,NA,15), pt.cex = 2, bg = "white", bty = "n", cex = 1, inset = .02)

dev.off()


jpeg("pig_herds_confirmed_num.jpeg", res = 300, height = 6, width = 6, units = "in")

plot(apply(num.conf.herds, 2, median), xlim = c(0,max.date + forward * fwddays), ylim = c(0,150), xaxt = "n", xlab = "Time (days)", ylab = "Number of pig herds", main = "Pig herds detected:\ndate of the confirmation", type = "n")
polygon(c(abc.times, rev(abc.times)), c(apply(num.conf.herds, 2, quantile, probs = c(.025))[abc.times], rev(apply(num.conf.herds, 2, quantile, probs = c(.975))[abc.times])), col = adjustcolor(pal_lancet("lanonc")(2)[1], alpha = 0.3), border = "white")
lines(abc.times, apply(num.conf.herds, 2, median)[abc.times], col = pal_lancet("lanonc")(2)[1], lwd = 2)
axis(side = 1, at = seq(0,max(fwd.times),10), labels = seq(0,max(fwd.times),10)-delta)
polygon(c(fwd.times, rev(fwd.times)), c(apply(num.conf.herds, 2, quantile, probs = c(.025))[fwd.times], rev(apply(num.conf.herds, 2, quantile, probs = c(.975))[fwd.times])), col = adjustcolor(pal_lancet("lanonc")(2)[1], alpha = 0.1), border = "white")
lines(fwd.times, apply(num.conf.herds, 2, median)[fwd.times], col = adjustcolor(pal_lancet("lanonc")(2)[1], alpha = 0.5), lwd = 2)
abline(v = min(fwd.times), lty = 2)
points(which(!is.na(num.series2)), num.series2[which(!is.na(num.series2))], type = "b", pch = 19, lwd = 1, col = pal_lancet("lanonc")(2)[2])
legend("topleft", c("Observed", "Model (median)", "Model (95% CI)"), col = c(pal_lancet("lanonc")(2)[2:1], adjustcolor(pal_lancet("lanonc")(2)[1], alpha = 0.3)), lty = c(1,1,NA), lwd = c(2,2,NA), pch = c(NA,NA,15), pt.cex = 2, bg = "white", bty = "n", cex = 1, inset = .02)

dev.off()


my_spdf = readOGR( 
  dsn = paste(substr(wd, start = 1, stop = nchar(wd)-1), "1/Data_Island/Island_ADMIN.shp", sep = ""),
  verbose=FALSE
)

A <- c(773676.4, 6347189)
B <- c(833676.4, 6347189)
C <- c(833676.4, 6437189)
D <- c(773676.4, 6437189)
A2 <- c(773676.4-15000, 6347189-15000)
B2 <- c(833676.4+15000, 6347189-15000)
C2 <- c(833676.4+15000, 6437189+15000)
D2 <- c(773676.4-15000, 6437189+15000)

jpeg("pig_herds_confirmed_prob.jpeg", res = 300, height = 6, width = 6, units = "in")

par(mar=c(0,0,2,0))
plot(my_spdf, col = "#f2f2f2", lwd = 0.25, border = 0, main = "Pig herds detected (confirmed)")
lines(x = c(A[1], B[1]), y = c(A[2], B[2]), type = "l", lwd = 2)
lines(x = c(C[1], B[1]), y = c(C[2], B[2]), type = "l", lwd = 2)
lines(x = c(C[1], D[1]), y = c(C[2], D[2]), type = "l", lwd = 2)
lines(x = c(A[1], D[1]), y = c(A[2], D[2]), type = "l", lwd = 2)
lines(x = c(A2[1], B2[1]), y = c(A2[2], B2[2]), type = "l", lwd = 2)
lines(x = c(C2[1], B2[1]), y = c(C2[2], B2[2]), type = "l", lwd = 2)
lines(x = c(C2[1], D2[1]), y = c(C2[2], D2[2]), type = "l", lwd = 2)
lines(x = c(A2[1], D2[1]), y = c(A2[2], D2[2]), type = "l", lwd = 2)
par(new = T)
col = heat.colors(10)[10:1]
points(herds$X[which(colSums(prob.conf.herds)/dim(prob.conf.herds)[1] != 0)], herds$Y[which(colSums(prob.conf.herds)/dim(prob.conf.herds)[1] != 0)],
       pch = 21, cex = .8, col = "black", bg = col[findInterval((colSums(prob.conf.herds)/dim(prob.conf.herds)[1])[colSums(prob.conf.herds)/dim(prob.conf.herds)[1] != 0], seq(0,1,0.1), rightmost.closed = T)])

legend.gradient(cbind(x = c(450000,470000,470000,450000), y = c(6440000,6540000,6440000,6540000)), cols = col, limits = c("0","1"), title = "Proportion of\nsimulations", cex = 1)

dev.off()


jpeg("pig_herds_detected_data.jpeg", res = 300, height = 6, width = 6, units = "in")

par(mar=c(0,0,2,0))
plot(my_spdf, col = "#f2f2f2", lwd = 0.25, border = 0, main = "Pig herds detected (data)")
lines(x = c(A[1], B[1]), y = c(A[2], B[2]), type = "l", lwd = 2)
lines(x = c(C[1], B[1]), y = c(C[2], B[2]), type = "l", lwd = 2)
lines(x = c(C[1], D[1]), y = c(C[2], D[2]), type = "l", lwd = 2)
lines(x = c(A[1], D[1]), y = c(A[2], D[2]), type = "l", lwd = 2)
lines(x = c(A2[1], B2[1]), y = c(A2[2], B2[2]), type = "l", lwd = 2)
lines(x = c(C2[1], B2[1]), y = c(C2[2], B2[2]), type = "l", lwd = 2)
lines(x = c(C2[1], D2[1]), y = c(C2[2], D2[2]), type = "l", lwd = 2)
lines(x = c(A2[1], D2[1]), y = c(A2[2], D2[2]), type = "l", lwd = 2)
par(new = T)
col = heat.colors(10)[10:1]
points(timeseries$X[!timeseries$DET %in% c("NPC")], timeseries$Y[!timeseries$DET %in% c("NPC")],
       pch = 21, cex = .8, col = "black", bg = col[10])

dev.off()


jpeg("pig_herds_infected_num.jpeg", res = 300, height = 6, width = 6, units = "in")

plot(apply(num.inf.herds, 2, median), xlim = c(0,max.date + forward * fwddays), ylim = c(0,150), xaxt = "n", xlab = "Time (days)", ylab = "Number of pig herds", main = "Pig herds infected", type = "n")
polygon(c(abc.times, rev(abc.times)), c(apply(num.inf.herds, 2, quantile, probs = c(.025))[abc.times], rev(apply(num.inf.herds, 2, quantile, probs = c(.975))[abc.times])), col = adjustcolor(pal_lancet("lanonc")(2)[1], alpha = 0.3), border = "white")
lines(abc.times, apply(num.inf.herds, 2, median)[abc.times], col = pal_lancet("lanonc")(2)[1], lwd = 2)
axis(side = 1, at = seq(0,max(fwd.times),10), labels = seq(0,max(fwd.times),10)-delta)
polygon(c(fwd.times, rev(fwd.times)), c(apply(num.inf.herds, 2, quantile, probs = c(.025))[fwd.times], rev(apply(num.inf.herds, 2, quantile, probs = c(.975))[fwd.times])), col = adjustcolor(pal_lancet("lanonc")(2)[1], alpha = 0.1), border = "white")
lines(fwd.times, apply(num.inf.herds, 2, median)[fwd.times], col = adjustcolor(pal_lancet("lanonc")(2)[1], alpha = 0.5), lwd = 2)
abline(v = min(fwd.times), lty = 2)
legend("topleft", c("Model (median)", "Model (95% CI)"), col = c(pal_lancet("lanonc")(2)[1], adjustcolor(pal_lancet("lanonc")(2)[1], alpha = 0.3)), lty = c(1,NA), lwd = c(2,NA), pch = c(NA,15), pt.cex = 2, bg = "white", bty = "n", cex = 1, inset = .02)

dev.off()


jpeg("pig_herds_infected_prob.jpeg", res = 300, height = 6, width = 6, units = "in")

par(mar=c(0,0,2,0))
plot(my_spdf, col = "#f2f2f2", lwd = 0.25, border = 0, main = "Pig herds infected")
lines(x = c(A[1], B[1]), y = c(A[2], B[2]), type = "l", lwd = 2)
lines(x = c(C[1], B[1]), y = c(C[2], B[2]), type = "l", lwd = 2)
lines(x = c(C[1], D[1]), y = c(C[2], D[2]), type = "l", lwd = 2)
lines(x = c(A[1], D[1]), y = c(A[2], D[2]), type = "l", lwd = 2)
lines(x = c(A2[1], B2[1]), y = c(A2[2], B2[2]), type = "l", lwd = 2)
lines(x = c(C2[1], B2[1]), y = c(C2[2], B2[2]), type = "l", lwd = 2)
lines(x = c(C2[1], D2[1]), y = c(C2[2], D2[2]), type = "l", lwd = 2)
lines(x = c(A2[1], D2[1]), y = c(A2[2], D2[2]), type = "l", lwd = 2)
par(new = T)
col = heat.colors(10)[10:1]
points(herds$X[which(colSums(prob.inf.herds)/dim(prob.inf.herds)[1] != 0)], herds$Y[which(colSums(prob.inf.herds)/dim(prob.inf.herds)[1] != 0)],
       pch = 21, cex = .8, col = "black", bg = col[findInterval((colSums(prob.inf.herds)/dim(prob.inf.herds)[1])[colSums(prob.inf.herds)/dim(prob.inf.herds)[1] != 0], seq(0,1,0.1), rightmost.closed = T)])
legend.gradient(cbind(x = c(450000,470000,470000,450000), y = c(6440000,6540000,6440000,6540000)), cols = col, limits = c("0","1"), title = "Proportion of\nsimulations", cex = 1)

dev.off()

write.csv(cbind(herds[which(colSums(prob.inf.herds)/dim(prob.inf.herds)[1] != 0), c("population_id", "X", "Y")],
                prob.inf = (colSums(prob.inf.herds)/dim(prob.inf.herds)[1])[colSums(prob.inf.herds)/dim(prob.inf.herds)[1] != 0],
                prob.susp = (colSums(prob.susp.herds)/dim(prob.susp.herds)[1])[colSums(prob.inf.herds)/dim(prob.inf.herds)[1] != 0],
                prob.conf = (colSums(prob.conf.herds)/dim(prob.conf.herds)[1])[colSums(prob.inf.herds)/dim(prob.inf.herds)[1] != 0]),
          file = "Detected_Herds_day_230_Fence_Increased_Pressure.csv", row.names = FALSE)
