###########################################
# AFRICAN SWINE FEVER MODEL FOR PIG HERDS #
#      ASF CHALLENGE - UK TEAM            #
#                                         #
#          Phase 3 - 2021/01/13           #
###########################################

rm(list = ls()) # remove (almost) everything in the working environment

# Set to your working directory
wd = "~/pig_herd_component/Phase3"

###############
## SCENARIOS ##
###############

forward  = TRUE  # Forward predictions (120 days) or not
fwddays  = 120   # Number of time steps (days) in the forward predictions
wildboar = TRUE  # Include infection from wild boars or not
fence    = TRUE  # Scenario: fencing
increas  = TRUE  # Scenario: increased hunting pressure on wild boars inside the fence

cullPZ   = FALSE # Scenario: culling pig herds in protection zones
incrSZ   = FALSE # Scenario: increasing the size of surveillance zone (from 10km to 15km)
cullTR   = FALSE # Scenario: culling herds that have traded pigs with infected farms less than 3 weeks before detection
cullWB   = TRUE  # Scenario: culling herds located at less than 3 km from positive wild boar carcasses

##########
## SEED ##
##########

SEED = as.numeric(Sys.getenv("SEED")) # Cluster
#SEED = 1                             # Local

###########
# LIBRARY #
###########

library(mc2d)   # R Package: PERT Distribution 
library(SimInf) # R Package for Data-Driven Stochastic Disease Spread Simulations: distance_matrix function
library(Rfast)  # R Package: Fast R Functions (colsums, rowsums)

########
# DATA #
########

# Set working directory
setwd(paste(wd, "/Data_Outbreak", sep = ""))

herds      = read.csv("herds_day_110.csv", header = TRUE)              # Characteristics of all pig sites
d_ij       = distance_matrix(x = herds$X, y = herds$Y, cutoff = 2000)  # Create a distance matrix for all coordinates within the cutoff (2000 m)
moves      = read.csv("moves_Players_day_110.csv", header = TRUE)      # List of all known movements of live pigs
moves      = moves[-which(moves$qty == 0),]                            # Remove movements of 0 animals
delta      = abs(min(moves$date)) + 1                                  # Number of days in the data before the first detected case (2 months)
moves$date = moves$date + delta                                        # Shift movement dates to start at t=1
max.date   = max(moves$date)                                           # Total number of days in the data
is.fa      = herds$production %in% c("B", "BF")                        # Farrowing pig sites (produce piglets)
is.fi      = herds$production %in% c("BF", "F")                        # Finishing pig sites (send animals to abattoir)
d_PZ       = distance_matrix(x = herds$X, y = herds$Y, cutoff = 3000)  # Create a distance matrix within the cutoff (Protection Zone: 3km)
d_PZ       = as.matrix(d_PZ != 0)                                      # Herds within 3km of each others
d_SZ       = distance_matrix(x = herds$X, y = herds$Y,                 # Create a distance matrix within the cutoff (Surveillance Zone: 10km)
                             cutoff = if(incrSZ){15000} else {10000}) 
d_SZ       = as.matrix(d_SZ != 0)                                      # Herds within 10km of each others

# Predicted pig movements (120 days)
if (forward){                                                          
  # Set working directory
  setwd(paste(wd, "/Moves_Simul/sim", sep = ""))
  
  load(file = paste("mov_pred_", SEED, ".Rdata", sep = ""))
  moves = rbind(moves, mov.pred2[,c("date","source","source.type","dest","dest.type","qty")])
}


##############################
# INPUT FROM WILD BOAR MODEL #
##############################

# Set working directory
setwd(paste(wd, "/Model_Predict_230", sep = ""))

if (wildboar){
  # Daily infection pressure from infected WB (patches) on all herds (except the 2 months before the first detected herd)
  source("compute-infection-pressures-on-herds.R")
  wb.pressure = infectiousPressureWB
  
  # Daily infection pressure from infected WB (patches) on all herds (include the 2 months before the first detected herd)
  wb.pressure = cbind(matrix(0, nrow = nrow(herds), ncol = max.date + forward * fwddays - ncol(wb.pressure)), wb.pressure)
  
} else {
  wb.pressure = matrix(0, nrow = nrow(herds), ncol = max.date + forward * fwddays)
}

if (wildboar & cullWB){
  
  fwd.locations = readRDS(paste("forward.run.increased.pressure.230.RDS", sep = ""))$locations[[SEED]]
  
  WB = matrix(FALSE, nrow = nrow(herds), ncol = max(fwd.locations$date.removed2))
  
  for (t in 1:ncol(WB)){
    mat = fwd.locations[fwd.locations$date.removed2 == t & fwd.locations$infectionStatus > 0 & fwd.locations$date.infected <= t & (fwd.locations$date.infected+104) > t,]
    WB[,t] = sapply(1:nrow(herds), function(i) any(sqrt((mat$X - herds$X[i])^2 + (mat$Y - herds$Y[i])^2) <= 3000))
  }
  
  WB = cbind(matrix(FALSE, nrow = nrow(herds), ncol = delta), WB)
  
} else {
  WB = matrix(FALSE, nrow = nrow(herds), ncol = max.date + forward * fwddays)
}


##################
# MODEL FUNCTION #
##################

# WITHIN-HERD MODEL AND LOCAL SPREAD
transition = function(Mat, beta, alpha, phi, gamma, mu, tau, loc, SZ, PZ, TR, wb){
  
  # Initialization
  S   = Mat["S",]
  E   = Mat["E",]
  Isc = Mat["Isc",]
  Ic  = Mat["Ic",]
  R   = Mat["R",]
  D   = Mat["D",]
  N   = S + E + Isc + Ic + R
  
  # Movement restrictions (SZ and PZ and TR)
  loc[SZ|PZ|TR,] = 0
  
  # Local spread
  p = (Isc+Ic+D)/N            # (I+D)/N
  p[is.na(p)] = 0             # If N==0 and D==0
  p[p == Inf] = 0             # If N==0 and D!=0
  sp = as.vector(loc %*% p)   # sum_j((rho/d_ij)*(I_j+D_j)/N_j)
  wb[herds$is_outdoor==0] = 0 # Set wild boar pressure for indoor herds to 0 
  
  # Random sampling  
  exp = rbinom(n, S,   1-exp(-(beta*p) - sp - wb))
  inf = rbinom(n, E,   1-exp(-1/alpha))
  sym = rbinom(n, Isc, 1-exp(-1/phi))
  rec = rbinom(n, Ic,  1-exp(-1/(gamma-phi)))
  die = rbinom(n, rec, mu)
  dec = rbinom(n, D,   1-exp(-1/tau))
  
  # Update
  Mat["S",]    = S   - exp         # dS/dt = S - beta*S*(I+D)/N - sum_j((rho/d_ij)*(I_j+D_j)/N_j)
  Mat["E",]    = E   + exp - inf   # dE/dt = E + beta*S*(I+D)/N + sum_j((rho/d_ij)*(I_j+D_j)/N_j) - (1/alpha)*E
  Mat["Isc",]  = Isc + inf - sym   # dIsc/dt = Isc + (1/alpha)*E - (1/phi)*Isc
  Mat["Ic",]   = Ic  + sym - rec   # dIc/dt = Ic + (1/phi)*Isc - (1/(gamma-phi))*Ic
  Mat["R",]    = R   + rec - die   # dR/dt = R + (1-u)*(1/(gamma-phi))*Ic
  Mat["D",]    = D   + die - dec   # dD/dt = D + u*(1/(gamma-phi))*Ic - (1/tau)*D
  Mat["Morb",] = sym               # New clinical cases
  Mat["Mort",] = die               # New ASFV-related deaths
  
  return(Mat)
}

# RANDOM SAMPLING WITHOUT REPLACEMENT
sampler = function(m, size){
  d = unlist(lapply(1:length(m), function(x) rep(x, m[x])))
  if(length(d) == 1 & size != 0){
    s = d
  } else {
    s = sample(d, size = min(length(d), size), replace = FALSE)
  }
  return(s)
}

# BETWEEN HERDS MODEL VIA ANIMAL MOVEMENT
movements = function(Mat, moves, is.fa, is.fi, SZ, PZ, TR){
  
  n = dim(Mat)[2]                                   # Number of herds
  compartments = rownames(Mat)                      # Health compartments
  N = colsums(Mat)                                  # Herd sizes
  
  mov  = matrix(0, n, n)                            # Movement matrix
  mov[cbind(moves$source,moves$dest)] = moves$qty   # Rows: sources, Colums: destinations
  mov[SZ|PZ|TR,] = 0                                # Restriction of outgoing movements (SZ and PZ and TR)
  mov[,SZ|PZ|TR] = 0                                # Restriction of ingoing movements (SZ and PZ and TR)
  
  # Make sure that the number of outgoing movements is not higher than the number of animals in the herd  
  o.mov = rowsums(mov)                              # Number of outgoing movements
  X = which(N < o.mov)
  for (x in X){
    s = sampler(m = mov[x,], size = N[x])
    mov[x,] = 0
    mov[x, as.numeric(levels(factor(s)))] = table(factor(s))
    o.mov[x] = sum(mov[x,])
  }
  
  # Make sure that the number of ingoing movements is not higher than the number of animals in the herd  
  i.mov = colsums(mov)                              # Number of ingoing movements
  X = which(N < i.mov)
  for (x in X){
    s = sampler(m = mov[,x], size = N[x])
    mov[,x] = 0
    mov[as.numeric(levels(factor(s))), x] = table(factor(s))
    i.mov[x] = sum(mov[,x])
  }
  
  # Keep only herds with outgoing movements for the for loop
  o.mov  = rowsums(mov)                             # Number of outgoing movements (update)
  is.mov = which(o.mov != 0)
  
  # Calculate the number of animals staying in herd i (necessary for r2dtable)
  mov[cbind(is.mov,is.mov)] = N[is.mov] - o.mov[is.mov]
  
  # Initialization
  tmp = ent = out = bth = abt = array(0, c(length(compartments), n), dimnames = list(compartments))
  
  for (i in is.mov){
    tmp = r2dtable(1,Mat[,i],mov[i,])[[1]]  # Random sampling of S, E, I and R moving from i (source) to j (destination)
    tmp[,i] = 0                             # Remove "movements" of animals staying in i (source = destination)
    out[,i] = rowsums(tmp)                  # Outgoing movements from i (all animals moving out of the source)
    ent = ent + tmp                         # Ingoing movements in all j from i
  }
  
  Mat = Mat - out + ent                     # Update Mat
  
  # Susceptible births in farrowing sites (compensate outgoing movements)
  bth["S", is.fa] = colsums(out[,is.fa])
  # Random sampling of animals going to abattoir in finishing sites (compensate entry movements)
  ent.sum = colsums(ent)
  X = which(ent.sum != 0 & is.fi)
  for (x in X){
    s = sampler(m = Mat[,x], size = ent.sum[x])
    abt[as.numeric(levels(factor(s))), x] = table(factor(s))
  }
  
  Mat = Mat - abt + bth                     # Update Mat
  
  return(Mat)
}

# FUNCTION TO RUN THE WHOLE MODEL
model = function(n, Mat, tspan, beta, phi, mu, tau, rho, d_ij, moves, is.fa, is.fi){
  
  # INITIALIZATION
  loc  = rho/d_ij
  loc[loc == Inf] = 0
  Mat2 = Mat[,,1]
  
  # TIME LOOP  
  for (t in tspan[-length(tspan)]){
    
    if (t == 29){
      Mat2["S",3594] = herds$size[3594] - 1
      Mat2["E",3594] = 1      
    }
    
    # CULLING
    CO[CU[,t] & !CO[,t], min(t+2, length(tspan))] = (colSums(Mat2[c("Isc","Ic","R"),]) != 0)[CU[,t] & !CO[,t]]  # Tests for herds culled outside classic surveillance (control scenarios) (PCR for Isc and Ic; serology for R)
    Mat2[,CU[,t]] = 0 
    
    # REPOPULATION
    RP[RP[,t] & (PZ[,t] | SZ[,t]), t+1] = TRUE   # Repopulation postponed if still in Protection or Surveillance Zone on day t
    RP[RP[,t] & (PZ[,t] | SZ[,t]), t]   = FALSE  # No repopulation on day t if still in Protection or Surveillance Zone
    Mat2["S", RP[,t]] = herds$size[RP[,t]] 
    
    # WITHIN-HERD MODEL AND LOCAL SPREAD 
    alpha = rpert(n, min = 3, mode = 4, max = 5)
    gamma = rpert(n, min = 3, mode = 7, max = 14)
    Mat2  = transition(Mat = Mat2, beta, alpha, phi, gamma, mu, tau, loc, SZ = SZ[,t], PZ = PZ[,t], TR = TR[,t], wb = wb.pressure[,t])
    
    # BETWEEN HERDS MODEL VIA ANIMAL MOVEMENT
    Mat2[c("S","E","Isc","Ic","R"),] = movements(Mat = Mat2[c("S","E","Isc","Ic","R"),], moves = moves[moves$date == t,], is.fa, is.fi, SZ = SZ[,t], PZ = PZ[,t], TR = TR[,t])
    
    # UPDATE MAT
    Mat[,,t+1] = Mat2
    
    # PASSIVE SURVEILLANCE
    thrs4 = rep(thrs2, n)
    thrs4[(SZ|PZ|TR)[,t]] = thrs3   # Increased awareness (SZ and PZ and TR)
    susp[,t+1] = (rowsums(Mat["Morb",,max(1,(t+1)-14+1):(t+1)]) + rowsums(Mat["Mort",,max(1,(t+1)-14+1):(t+1)]) >= thrs4) &
                 (rowsums(Mat["Mort",,max(1,(t+1)-14+1):(t+1)])/herds$size >= thrs1) &
                 (rowsums(susp[,max(1,t-14+1):(t+1)]) == 0) & (colSums(Mat2) != 0)
    hrd_susp = (susp[,t+1] == TRUE) & (susp[,t] == FALSE) & (colSums(Mat2) != 0)
    CO[hrd_susp, min(t+1+conf,          length(tspan))] = susp[hrd_susp, t+1]
    CU[hrd_susp, min(t+conf+cull,       length(tspan))] = TRUE
    RP[hrd_susp, min(t+conf+cull+repop, length(tspan))] = TRUE
    
    # PROTECTION AND SURVEILLANCE ZONES
    hrd_sz = apply(rbind(hrd_susp, matrix(d_SZ[hrd_susp,], ncol = n)), 2, sum) != 0
    SZ[hrd_sz, min(t+conf+cull, length(tspan)):min(t+conf+SZend, length(tspan))] = TRUE
    hrd_pz = apply(rbind(hrd_susp, matrix(d_PZ[hrd_susp,], ncol = n)), 2, sum) != 0
    PZ[hrd_pz, min(t+conf+cull, length(tspan)):min(t+conf+PZend, length(tspan))] = TRUE
    
    # MOVEMENT TRACING OF PIGS
    hrd_tr = c(moves$source[moves$dest %in% which(hrd_susp) & moves$date >= (t+conf-TRbck+1) & moves$date <= min(t+conf, length(tspan))],
               moves$dest[moves$source %in% which(hrd_susp) & moves$date >= (t+conf-TRbck+1) & moves$date <= min(t+conf, length(tspan))])
    TR[hrd_tr, min(t+conf+cull, length(tspan)):min(t+conf+TRend, length(tspan))] = TRUE
    
    if (t > max.date - 20){
      # Scenario: culling pig herds in protection zones
      hrd_cull_pz = cullPZ & (PZ[,t+1] == TRUE) & (PZ[,t] == FALSE) & (colSums(Mat2) != 0)
      CU[hrd_cull_pz, min(t+cull, length(tspan))] = TRUE
      RP[hrd_cull_pz, min(t+cull+repop, length(tspan))] = TRUE
      
      # Scenario: culling herds that have traded pigs with infected farms less than 3 weeks before detection    
      hrd_cull_tr = cullTR & (TR[,t+1] == TRUE) & (TR[,t] == FALSE) & (colSums(Mat2) != 0)
      CU[hrd_cull_tr, min(t+cull, length(tspan))] = TRUE
      RP[hrd_cull_tr, min(t+cull+repop, length(tspan))] = TRUE
      
      # Scenario: culling herds located at less than 3 km from positive wild boar carcasses
      hrd_cull_wb = cullWB & (WB[,t+1] == TRUE) & (WB[,t] == FALSE) & (colSums(Mat2) != 0)
      delay = runif(length(hrd_cull_wb), min = 5, max = 7)
      CU[hrd_cull_wb, min(t+cull+delay, length(tspan))] = TRUE
      RP[hrd_cull_wb, min(t+cull+delay+repop, length(tspan))] = TRUE      
    }
    
  }
  
  return(list("Mat" = Mat, "susp" = susp, "CO" = CO))
}


##################
# INITIALIZATION #
##################

n = nrow(herds)
compartments = c("S", "E", "Isc", "Ic", "R", "D", "Morb", "Mort")
tspan = seq(from = 1, to = max.date + forward * fwddays, by = 1)
u0 = rbind(S = herds$size, E = double(n), Isc = double(n), Ic = double(n), R = double(n), D = double(n), Morb = double(n), Mort = double(n))
Mat = array(0, c(length(compartments), n, length(tspan)), dimnames = list(compartments))
Mat[,,1] = u0


##############
# PARAMETERS #
##############

beta  = 0.6         # per day
phi   = 2           # days
mu    = 0.95        # probability
tau   = 1/log(2)    # days
rho   = 0.005*1000  # meters per day

conf  = 3           # days
cull  = 1           # days
SZend = 30          # days
PZend = TRend = 40  # days
TRbck = 21          # days
repop = 50          # days
thrs1 = 0.06        # mortality rate threshold
thrs2 = 5           # minimum number of clinical or dead animals
thrs3 = 1           # minimum number of clinical or dead animals (increased awareness)

# Booleans
susp  = matrix(FALSE, n, length(tspan))
CO    = matrix(FALSE, n, length(tspan))
PZ    = matrix(FALSE, n, length(tspan))
SZ    = matrix(FALSE, n, length(tspan))
CU    = matrix(FALSE, n, length(tspan))
RP    = matrix(FALSE, n, length(tspan))
TR    = matrix(FALSE, n, length(tspan))


#############
# MODEL RUN #
#############

# For reproducibility
set.seed(SEED)

#t1 = Sys.time()
#Rprof()
simul = model(n, Mat, tspan, beta, phi, mu, tau, rho, d_ij, moves, is.fa, is.fi)
#Mat  = simul$Mat
#susp = simul$susp
#CO   = simul$CO
#Rprof(NULL)
#summaryRprof()
#t2 = Sys.time()
#t2-t1

setwd(paste(wd, "/Model_Predict_230/output", sep = ""))
save(simul, file = paste("simul_", SEED, ".Rdata", sep = ""))
