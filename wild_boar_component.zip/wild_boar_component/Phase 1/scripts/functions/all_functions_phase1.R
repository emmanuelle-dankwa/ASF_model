### THIS SCRIPT CONTAINS CODE FOR... ###
### MISC FUNCTIONS REQUIRED FOR COMPUTING PREDICTIONS FROM A TRANSMISSION MODEL OF ASFV IN WILD BOAR ###
### ASF CHALLENGE - UK TEAM ###


# SECTIONS IN THIS SCRIPT: #

  # 1. FUNCTIONS FOR INPUT DATA PREPARATION 
  # 2. FUNCTIONS FOR MODEL SIMULATION
  # 3. FUNCTIONS FOR PARAMETER ESTIMATION
  # 4. FUNCTIONS FOR PREDICTION

  




#### FUNCTIONS FOR INPUT DATA PREPARATION ####

# 1. Run the code in an Rmd file 

## Input:
# x: location of Rmd file 

## Output:  
# Results of running code in x

source_rmd <- function(x, ...) {
  source(knitr::purl(x, output = tempfile()), ...)
}




# 2. Simulate the appropriate number of random points 
#     for wild boar locations in each administrative region

## Inputs: 

# shp.file = shape file of island
# hunt.bag = full hunting bag data frame (from previous chunk)

## Output:

# A list with 25 elements, with each element corresponding to one of the 25 regions
# Each element contains 'x' spatial points, i.e. XY coordinates, where 'x' is the number of
# simulated boar locations.

simulate.boar.locations <- function(shp.file = merry_shp, hunt.bag = hunting_bag){
  
  rand_coords <- list()    # Create list to store output
  
  for(i in 1:nrow(hunt.bag)){
    # 
    if(i==8 | i==20 ){ # define separately: duplicate polygons for 10th and 24th ADm region
      j <- which(as.integer(shp.file@data$ID) == hunt.bag$ADM[i]) # Obtain index of ADM region as in shape file
      a <- shp.file@polygons[[j]]
      a@Polygons <- a@Polygons[1]
      rand_coords_tmp <- sp::spsample(a,  n = hunt.bag$number.to.simulate[i], "random") # Sample points randomly
      rand_coords[[i]] <- rand_coords_tmp
    }else{
      j <- which(as.integer(shp.file@data$ID) == hunt.bag$ADM[i]) # Obtain index of ADM region as in shape file
      rand_coords_tmp <- sp::spsample(shp.file@polygons[[j]],  n = hunt.bag$number.to.simulate[i], "random") # Sample points randomly
      rand_coords[[i]] <- rand_coords_tmp
      
    }
    
  } 
  return(rand_coords)
}



#### FUNCTIONS FOR MODEL SIMULATION ####


# 1. Function to select which sounder populations will be decreased (through hunting). Used in function #3. 

## Inputs: 

## m: vector containing number of wild boar in each patch located within fence
## size: number of wild boar to be hunted each day within fence 

sampler = function(m, size){
  d = unlist(lapply(1:length(m), function(x) rep(x, m[x])))
  s = sample(d, size = size, replace = FALSE)
  return(s)
}


# 2. Function to simulate hunting (to decrease boar numbers within fence)

## Inputs: 

## x: number of wild boar in each patch located in fence
## total: number of wild boar hunted each day within fence 

update.boar.numbers <- function(x, total){
  s <- sampler(m = x, size = total)
  x[as.numeric(levels(factor(s)))] <- min(0, x[as.numeric(levels(factor(s)))] - table(factor(s)))
  return(x)
}








#### FUNCTIONS FOR PARAMETER ESTIMATION #### 


# 1.  Function for computing the minimum convex polygon (MCP) of a set of points

 ## Inputs:
  # x: coord: coordinates of points within the MCP

## Output: 
# Area of MCP

mcp.area <- function(coord){
  x <- coord$X
  y <- coord$Y
  grDevices::chull(x,y)->i  # Identify MCP vertices 
  geometry::polyarea(x = cbind(x[i]), y = cbind(y[i]), d = 1)/1000000 # Handles zero rows without thrwing an error, unlike areapl (Splancs package)
  # return(splancs::areapl(cbind(x[i],y[i]))/1000000)
}




# 2. Compare distance values to threshold 

## Inputs:
# x: distances corresponding to accepted parameter sets

## Output:
# Euclidean distance between x and (0,0,0)

distance_from_threshold <- function(x){
  
  # Compute distances from threshold 
  sqrt(sum((x[1])^2, (x[2])^2, (x[3])^2))
}




# 3. Calculate distance between observations and model simulations.
# 
# Calculate distance based on:
# Daily number of detected cases in wild boar
# Area of minimum convex polygon (MCP) enclosing infected patches
# Maximum number of detected cases

## Inputs: 
# res: model output


## Output: 
# Vector of distances between model output and observations

calc_distance <- function(res){
  
  # Compute distance based on daily number of cases in wild boar #
  
  times.model <- res$summarized.res$day  # event times in model
  detected.cases.model <- res$summarized.res[res$summarized.res$day %in% times.model, "new.cases.wb"]$new.cases.wb # daily number of detected cases in model
  
  times.observed <- observed.positive$day # observed event times
  detected.cases.observed <- observed.positive$count # daily number of detected cases (observed)
  
  dist1 <- c()                       # Store distances 
  for(i in 1:length(times.model)){
    
    dist1[i] <- (detected.cases.model[i]-detected.cases.observed[times.observed==times.model[i]])^2 # Calculate Euclidean distance between model and observed. Times may not be regular in simulations hence the specification of time
  }
  dist1 <- sqrt(sum(dist1)) # return total distance
  
  
  # Compute distance based on area of MCP #
  
  # MCP from model simulations
  mcp.model <- sapply(res$coord.infected, function(x){if (nrow(x)<3){x <- 0}else{x <- mcp.area(x)}})
  mcp.data <- sapply(observed.positive.locations, function(x){if (nrow(x)<3){x <- 0}else{x <- mcp.area(x)}})
  
  dist2 <- c()                       # Store distances 
  for(i in 1:length(times.model)){
    
    dist2[i] <- (mcp.model[i]-mcp.data[times.observed==times.model[i]])^2 # Calculate Euclidean distance between model and observed. Times may not be regular in simulations hence the specification of time
  }
  dist2 <- sqrt(sum(dist2))
  
  
  # Compute distance based on maximum number of cases #
  
  dist3 <- abs(sum(detected.cases.observed) - sum(res$summarized.res$new.cases.wb))
  
  c(dist1, dist2, dist3)
}









# Reference for code below: (Minter & Retkute, 2019)



# 4. Perturbation kernel for ABC 
## Inputs:
# mean: parameter estimates from previous iteration
# sigma: covariance based on M nearest neighbours

kern <- function(mean, sigma, upp, low){   
  return(tmvtnorm::rtmvnorm(n = 1, mean , sigma, lower = low, upper = upp)) 
}



# 5. Identity function: H(x)= 1 if x=T
H <- function(x) as.numeric(x>0)



# 6. Probability that prior is zero
## Inputs:
# par: parameter set
prior.non.zero<-function(par, upp = p.upp, low = p.low){
  n.par <- length(par)
  prod(sapply(1:n.par, function(a) H(par[a]-low[a])* H(upp[a]-par[a])))
}



# 7. Covariance based on M neighbours

## Inputs:
# p1, p2; vectors for which Euclidean distance is calculated.

Norm.Eucl.dist<-function(p1,p2,  upp = p.upp, low = p.low){
  sqrt(sum(((p1-p2)/(upp-low))^2)) }

## Inputs:
# M: number of nearest neighbours
# theta: the parameter set for which the covariance will be calculated.
# Theta: full parameter set in generation

getSigmaNeighbours<-function(M, theta, Theta, N, upp, low){
  dist<- sapply(1:N, function(a) Norm.Eucl.dist(as.numeric(theta), as.numeric(Theta[a,]), upp, low))
  temp<-data.frame(no=seq(1,N), dist)
  temp<-temp[order(temp$dist),]
  sigma<-cov(Theta[temp$no[1:(M+1)],])
  return(sigma)
}



# 8. 
# Run ABC-SMC algorithm. 
# NOTE: this function could be run on multiple cores

## Inputs: 
# vals: list of priors
# N: Number of accepted particles per core. 
# tolerance: vector of threshold values for each summary statistic
# verbose: logical; verbose? If TRUE, output of model simulations are printed.

## Output: 
# List with the following elements: 
# estims: Data frame of N accepted particles (parameter values).
# status.matrices: List of length N. Each list element is a list with the daily infection indicator matrices 
#                  corresponding to the accepted simulation. 
# series: List of length N. Each list element is a data frame containing the daily and cumulative counts of detected boar 
#         as predicted by the corresponding accepted simulation. 
# locations: List of length N. Each list element is a data frame containing infection information for all boar in the landscape,
#            as predicted by the corresponding accepted simulation.
#             


run_ABC_SMC_phase1 <- function(vals, N= 500, timings.max.val = 50, verbose.val = F, n=5, tol = tolerance, M= 50){
  
  p.low <- vals[, "p.low"]
  p.upp <-  vals[, "p.upp"]
  
  
  print(paste("p.low:", p.low))
  print(paste("p.upp:", p.upp))
  
  # OTHER
  
  # Number of parameters being estimated
  # 
  n.par <- length(p.low)
  # print(n.par)
  # Number of generations; 
  # Preferred particles are those from the last generation as those have the strictest tolerances
  G <- length(tol$epsilon_cases)
  
  # M: Number of neighbours for covariance matrix calculations. Should always be less than or equal to N (if equal to N, then ABC-SMC)
  # n: Number of simulations for each parameter set 
  # n.par: Number of parameters
  
  # Empty matrices to store results (5 model parameters)
  res.old<-matrix(ncol=n.par,nrow=N)
  res.new<-matrix(ncol=n.par,nrow=N)
  
  # Empty vectors to store weights
  w.old <- matrix(ncol=1,nrow=N)
  w.new <- matrix(ncol=1,nrow=N)
  
  
  # Save infection status matrix for accepted simulations
  status.matrices <- list()                  
  # Save counts for accepted simulations
  counts <- list()
  
  for(g in 1:G){  
    
    #Initiate counter
    i<-1    
    while(i <= N){ # While the number of accepted particles is less than N_particles
      print(paste("Progress..........", i))
      if(g==1){
        # Sample from prior distributions 
        beta_star<- runif(1,min=p.low[1], max=p.upp[1])
        alpha_star<-runif(1, min=p.low[2], max=p.upp[2])
        patchToBoarRate_1_star <- runif(1, min=p.low[3], max=p.upp[3])
        patchToBoarRate_2_star <- runif(1, min=p.low[4], max=p.upp[4])
        print(paste("Particle value: ", c(beta_star, alpha_star, patchToBoarRate_1_star, patchToBoarRate_2_star)))
      }else{
        #  Select particle from previous generation
        
        p<-sample(seq(1,N),1,prob=w.old)
        sigma <- Sigma[[p]]
        par<- kern(res.old[p,], sigma + diag(ncol(sigma))*0.05, p.upp, p.low)
        beta_star<-par[1]
        alpha_star<-par[2]
        patchToBoarRate_1_star <- par[3]
        patchToBoarRate_2_star <- par[4]
        
      }
      #  Test if prior non zero; i.e. test if not in the initially defined prior interval
      # print(prior.non.zero(par = c(beta_star, alpha_star, patchToBoarRate_1_star, patchToBoarRate_2_star), upp = p.upp, low = p.low))
      if(prior.non.zero(par = c(beta_star, alpha_star, patchToBoarRate_1_star, patchToBoarRate_2_star), upp = p.upp, low = p.low)) {
        # Set number of accepted simulations to zero
        m<-0
        distance <-matrix(ncol=3,nrow=n) # n = number of simulations with parameter set; m = number of times those simulations get accepted, #column 1 for case_distance, column 2 for area distance 
        status.matrices.temp <- list()  
        counts.temp <- list()
        accepted.indices <- c()          # vector to save indices of accepted simulations. 
        for(j in 1:n){
          D_star<-model_phase1(beta = beta_star, alpha = alpha_star, patchToBoarRate_1 = patchToBoarRate_1_star, patchToBoarRate_2 = patchToBoarRate_2_star, timings.max = timings.max.val,verbose = verbose.val)     
          # Calculate distances 
          calc.dist <-calc_distance(D_star)
          print(paste("D: ", calc.dist))
          distance[j,] <- calc.dist    # save the distances
          status.matrices.temp[[j]]<- D_star$status.matrices                      # save the infection status matrices 
          counts.temp[[j]] <- D_star$summarized.res
          output <- calc.dist[1] <= tol$epsilon_cases[g] & calc.dist[2] <= tol$epsilon_area[g] & calc.dist[3] <= tol$epsilon_cumulative[g]
          print(output)
          if(output){ # If distance is less than their tolerances, accept!
            m<-m+1
            accepted.indices <- c(accepted.indices, j)
          }              
        }   
        if (m>0){ 
          # Store results
          res.new[i,] <- c(beta_star, alpha_star, patchToBoarRate_1_star,  patchToBoarRate_2_star)
          ## Choose which simulation to save; choose the set with the minimum distance) ##
          distances.from.zero <- apply(matrix(distance[accepted.indices, ], ncol = 3), 1, distance_from_threshold)
          min.distance.ind <- accepted.indices[which(distances.from.zero==min(distances.from.zero))] # Row Index (in distance matrix) of parameter simulation corresponding to smallest value ; [1], in case there are more than one minimum values 
          status.matrices[[i]] <- status.matrices.temp[[min.distance.ind]]       # Saves the status matrix (at day 50) corresponding to the accepted parameter set 
          counts[[i]] <- counts.temp[[min.distance.ind]]
           # Calculate weights - use uniform distribution 
          w1 <- prod(sapply(1:n.par, function(b) dunif(res.new[i,b], min=p.low[b], max=p.upp[b])))
          if(g==1){
            w2<-1
          } else {
            w2<-sum(sapply(1:N, function(a) w.old[a]* dtmvnorm(res.new[i,], mean=res.old[a,], sigma=sigma, lower=p.low, upper=p.upp))) # denominator in expression for w_g^(i) - step 8 - algorithm.  Weight of particle in previous generation * kernel (current particle given previous particle)
          }
          w.new[i] <- (m/n)*w1/w2 # m = number of accepted particles; n = number of trial particles. Weight w1/w2 by the fraction of accepted particles so far in that generation. 
          # Update counter
          i <- i+1
          print(paste0('GENERATION: ', g, ", PARTICLE ACCEPTED: ", i))
          
        }
      } 
    }
    
    Sigma <- list(NA, N)
    for(p in 1:N){
      Sigma[[p]]<- getSigmaNeighbours(M, res.new[p,], res.new, N, p.upp, p.low) 
    } 
    res.old <- res.new
    w.old <- w.new/sum(w.new) # normalize weights
    #print(paste("prob", w.old))
    results <- list(estims = res.old,
                    mat = status.matrices, 
                    counts = counts)
    saveRDS(results, file = paste0("./results/set-1/gen_" , g, ".RDS"))  # Save results for generation g
  }
  
}





# Reference:

# 1. Minter, A. & Retkute, R. (2019). Approximate Bayesian Computation for infectious disease modelling. Epidemics, 29, 100368.






#### FUNCTIONS FOR PREDICTION ####


# 1. Perform component-wise addition of matrices in a list

  ## Input:
  ## x: list with matrix components. 
  
  ## Output:
  ## Sum of matrices
add.matrices <- function(x){Reduce ("+", x)}



# 2. Given N infection indicator matrices, 
#    obtain a combined infection indicator matrix
#    (as a majority vote count of the N matrices)
#    
#    This function combines the infection status predictions from all accepted simulations, 
#    computes the probability of infection for each patch at the final day and 
#    using a threshold, computes a new indicator matrix. 


  ## Input:
  # X: list of lists. X has N components, where N = number of parameter sets (each parameter set yields a set of status matrices, one for each day). 
  #    Each of the N components is a list of T components, where T = number of days considered in the model.
  # from.day: first day considered in the model
  # to.day: last day considered in the model
  # threshold.prob: If the probability for a patch is greater than threshold.prob, 
  #                  we consider the patch to be infected. Defaults to 0.05. 
  #                  In prediction, the value of threshold.prob is chosen to minimize the difference 
  #                  between the average prevalence among patches, computed using accepted simulations, 
  #                  and the prevalence computed from the combined matrix. 
  
  ## Output:
  # List of length N with elements:
  # prob = Combined matrix of infection probabilities for each patch
  # indicator = Infection indicator matrix computed from prob and threshold.prob. 
  #             The (i,j)th entry of 'indicator' is 1 is the corresponding entry of 
  #             'prob' is less than or equal to threshold.prob; the entry is 0 otherwise.

add.matrices.day <- function(X, from.day = 1, to.day = 50, threshold.prob = 0.05){
  
  list.prob <- list()        # List to save probabilities
  list.indicator <- list()  #  List to save infection status
  
  days.seq <- from.day:to.day
  for(t in 1:length(days.seq)){ # Compute probabilities
    day_t_mat <- matrix(0, nrow = nrow(patchcentres), ncol = nrow(patchcentres))
    for(i in 1:length(X)){
      day_t_mat <- add.matrices(list(day_t_mat,dat[[i]][[t]])) # Add matrices by day
    }
    list.prob[[t]] <- day_t_mat/length(X)   # Divide sums by the number of matrices added to obtain probabilities
  }                                         # 'list.prob' is a list with length(X) components, each component containing the probability status matrix for a particular day.
  
  # Implement threshold
  list.indicator <- lapply(list.prob, function(A){ifelse(A>threshold.prob, TRUE, FALSE)})
  
  list(prob = list.prob, indicator = list.indicator)
}



# 3. Obtain coordinates of infected patches given infection indicator matrix 

  ## Inputs: 
  # X = an infection indicator matrix
  
  ## Output:
  # Data frame of XY coordinates of infected patches

get.coordinates.from.single.matrix <- function(X){
  coordIndices <- as.data.frame(which(X == TRUE, arr.ind = TRUE))                             # Matrix indices for infected patches
  data.frame(X = patchcentres$X[coordIndices$col], Y = patchcentres$Y[coordIndices$row])   # Coordinates of infected patches
}



# 4. Obtain daily counts given cumulative counts

## Inputs: 
## x: vector with cumulative counts

## Output: vector with daily counts

daily <- function(x, y= observed.positive$count){ 
 # x <- abs(x - sum(y)) # Subtract number observed up to day before x predictions
 x <- x - c(0, head(x, -1))
  x
}



# 5. For each accepted simulation, compute the number of final infected patches

## Inputs:
# dat: List of length N, where N is the number of accepted simulations. 
#      Each element of the list is a list of length equal to the number of days 
#      over which estimation was performed.

## Output:
# Vector of length N; each element of the vector is the number of final infected patches
# as predicted by an accepted simulation.

number.final.infected.patches <- function(dat){
  # Prediction length 
  prediction.length = length(dat[[1]]) # Obtain number of days over which estimation was performed
  num.final <- c() # Vector to store number of final infected patches 
  for (i in 1:length(dat)){
    num.final[i] <- sum(dat[[i]][[prediction.length]]) # Compute number of final infected patches for each accepted simulation
  }
  num.final
}




# 6.Extract cumulative and daily cases for accepted simulations from list

## Inputs:
# res.list: List of length N, where N is the number of accepted simulations. 
#      Each element of the list is a data frame and corresponds to the model output at a given simulation
# The data frame has columns: 
# day:                 Days for which simulation was performed
# new.cases.wb:        Number of detected infected boar on 'day'
# cumulative.cases.wb: Cumulative number of detected infected boar by 'day'


## Output:
# List with elements:
# df.cum.cases: matrix with each column corresponding to the cumulative number of detected cases (in boar) from a single simulation.
#               Each row corresponds to a day
# df.dly.cases: matrix with each column corresponding to the daily number of detected cases (in boar) from a single simulation.
#               Each row corresponds to a day
# 
extract.cases <- function(res.list, from.day = 1, to.day = 80){
  
  # Create empty data frame for saving case counts
  # Cumulative
  df.cum.cases <- matrix(NA, nrow = (to.day - from.day) + 1, ncol = length(res.list))
  # Counts
  df.dly.cases <- matrix(NA, nrow = (to.day - from.day) + 1, ncol = length(res.list))
  
  # Arrange into data frames
  for(i in 1:length(res.list)){
    df.cum.cases[,i] <- res.list[[i]]$cumulative.cases.wb[1:((to.day - from.day) + 1)]
    df.dly.cases[,i] <- res.list[[i]]$new.cases.wb[1:((to.day - from.day) + 1)]
  }
  
  return(list(df.cum.cases = df.cum.cases,
              df.dly.cases = df.dly.cases))
  
}



### 7. FUNCTION TO VARY PARAMETER VALUES BY A PERCENTAGE ####
# Inputs: 
#'@val Parameter value
#'@perc Percentage to vary 'val' by

vary <- function(val, perc=0.2){
  c(val - val*perc, val + val*perc)
}








