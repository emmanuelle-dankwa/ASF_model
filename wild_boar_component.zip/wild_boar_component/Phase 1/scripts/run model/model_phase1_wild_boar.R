### THIS SCRIPT CONTAINS CODE FOR 
### A SIP MODEL FOR WILD BOAR ####
### ASF CHALLENGE, PHASE 1 - UK TEAM  ###



##### MODEL FUNCTION #####

## Arguments ##

# beta:               Transmission rate
# alpha:              Spatial scale
# patchToBoarRate_1:  Proportion of infectious boar in an infectious patch when timings < 28. 
# patchToBoarRate_2:  Proportion of infectious boar in an infectious patch when timings > 37.
# detectRate:         Detection rate of positive boar in a patch; set to 0.1   
# timings.max:        Run model to day 'timings.max'
# dt:                 Time interval (in days); set to 1. 
# fence:              Has fence been implemented?
# seed:               Infection status matrix; indicator matrix showing infection status of patches -  1 if infected and 0 if not infected 
# verbose:            Print simulation progress?


## Model output ##

# A list containing the elements:

# summarized.res: Data frame of daily and cumulative counts of detected positive boar. Columns of data 
#                frame are: 
# day:                 Days for which simulation was performed
# cumulative.cases.patches: Cumulative number of infected patches by 'day'
# new.cases.wb:        Number of detected infected boar on 'day'
# cumulative.cases.wb: Cumulative number of detected infected boar by 'day'

# coord.infected: List with length equal to timings.max with each list element corresponding to a day.
#                 Each list element is a data frame of XY coordinates of infected patches by the corresponding day. 


# status.matrices: List with length equal to timings.max with each list element corresponding to a day.
#                  Each list element is an indicator matrix showing which patches are infected at the corresponding day: 1 for infected and 0 if not infected.


model_phase1 <- function(beta, 
                         alpha, 
                         patchToBoarRate_1, 
                         patchToBoarRate_2, 
                         detectRate = 0.1,   # Hunt 50%, test 10%
                         timings.max, 
                         dt=1, 
                         fence = FALSE, 
                         increased.pressure=FALSE,
                         forward.simulation = FALSE, 
                         seed = infectionStatusMatrix,
                         verbose){
  
  ##########################################################################################################
  ############################### INPUT QUALITY CHECKS & VALUE DEFINITIONS #################################
  
  ## Input Quality Checks ##
  
  if(increased.pressure & !fence){
    stop("Increased pressure can only be implemented within fence. Set fence to TRUE.")
  }
  
  
  ## Define VALUES ##:
  
  
  npatches_x <- npatches_y <-  nrow(patchcentres) # Number of patch centres
  patchcentres_x <- patchcentres$X                # X coordinates of patch centres
  patchcentres_y <- patchcentres$Y                # Y coordinates of patch centres
  timeVals <- c()                                 # Vector for storing event times (in days)
  IVals <- c()                                    # Vector for storing CUMULATIVE infection numbers
  wildBoarVals <- c()                             # Vector for storing counts of detected positive wild boar
  recNumHere <- 1                                 # Counter. Set start to 1.
  statusEachTimeStep <- list()                    # List for storing (daily) indicator matrices for infection status of patches
  infectionStatusMatrix <- seed                   # Indicator matrix for infection statuses of patches
  coordInfected <- list()                         # List to save coordinates of infected patches
  timings <- 0                                    # First day of simulation
  
  
  
  
  ##########################################################################################################
  ######################################## INCREASED HUNTING PRESSURE COMPUTATIONS   #######################
  
  
  ## REDUCTION IN WILD BOAR NUMBERS ##
  
  ## How many wild boar are there within the fence? ##
  
  if(increased.pressure){
    detectRate_within_fence <- 0.9*1 # Hunt 90%, test 100%
    # nboar.in.fence <- sum(nBoarsMatrix[which(in.fence.matrix==1)]) # 33721
    # 
    # ## Hunting 90% of these will result in 
    # 
    # nboar.in.fence.to.be.hunted <- round(0.9*nboar.in.fence)  # ...30349 = expected number of hunted wild boar 
    # 
    # ## Given that this hunting will take place over 4 weeks and at a uniform rate, how many will be killed in each day? ##
    # 
    # nboar.in.fence.to.be.hunted.each.day <- round(nboar.in.fence.to.be.hunted/19) # 1597, from day 60 to day 78.
    # 
    ## So, reduce number of boar in fenced area by  'nboar.in.fence.to.be.hunted.each.day'  at each day ##
  }
  
  # Rate of AS and PS as the mean of Poisson random variable, mainly within fence
  found_rate <- ceiling(mean(removals$in.zone.found[40:50]))
  
  ##########################################################################################################
  ##########################################################################################################
  
  while(sum(infectionStatusMatrix==1) > 0 & timings < timings.max){
    
    
    ##########################################################################################################
    ##########################################################################################################
    
    ## Set 'patchToBoarRate' parameter ##
    timings
    
    if(!forward.simulation){
      
      if(timings < 28){
        patchToBoarRate <- patchToBoarRate_1
      }else{
        if(timings>=28 & timings < 38){
          patchToBoarRate <- patchToBoarRate_1 + ((patchToBoarRate_2 - patchToBoarRate_1)/ (38-28))*(timings - 28)
        }else{
          patchToBoarRate <- patchToBoarRate_2
        }
      }
      
    }else{
      patchToBoarRate <- patchToBoarRate_2
    }
    
    
    ##########################################################################################################
    ###############################   COMPUTE PATCH-LEVEL INFECTION PRESSURE   ################################
    
    
    infectiousPressure <- double(npatches_x*npatches_y)                            # matrix for storing values for infectious pressure on WB
    
    row_I <- as.data.frame(which(infectionStatusMatrix == 1, arr.ind = TRUE))$row  # save row indices for infected patches 
    col_I <- as.data.frame(which(infectionStatusMatrix == 1, arr.ind = TRUE))$col  # save column indices for infected patches 
    
    row <- as.data.frame(which(infectionStatusMatrix == 0, arr.ind = TRUE))$row   # save row indices  for susceptible patches
    col <- as.data.frame(which(infectionStatusMatrix == 0, arr.ind = TRUE))$col   # save column indices for susceptible patches
    
    LinIdx <- (col-1)* nrow(infectionStatusMatrix) + row                          # compute matrix indices
    
    
    
    if(fence&timings>=10){ # IMPLEMENT FENCE FROM DAY 60, SET TO 10 BECAUSE RUNNING FROM DAY 51
      
      # Identify susceptible patch position in relation to fence
      suscPatchInFence <- data.frame(which(in.fence.matrix==1 & infectionStatusMatrix==0, arr.ind = TRUE))
      suscPatchNotInFence <- data.frame(which(in.fence.matrix==0 & infectionStatusMatrix==0, arr.ind = TRUE))
      
      
      for(i in 1:length(row_I)){ # for all infectious patches, 
        # If infectious patch is in fence
        if(in.fence.matrix[row_I[i], col_I[i]]==1){ # if infected patch is in fence, infection pressure only exerted on others in fence
          
          # Compute infectious pressure on within-fence patches only
          infectiousPressure[(suscPatchInFence$col-1)*npatches_x + suscPatchInFence$row] <- 
            infectiousPressure[(suscPatchInFence$col-1)*npatches_x + suscPatchInFence$row] +              # infection pressure on susceptible WB = (infection pressure on susceptible WB) + number of WB in susceptible patch * number of WB in patch [i,j] + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
            nBoarsMatrix[(suscPatchInFence$col-1)*npatches_x + suscPatchInFence$row] * nBoarsMatrix[row_I[i],col_I[i]] * patchToBoarRate *
            beta*exp(-(sqrt((patchcentres_x[suscPatchInFence$row] - patchcentres_x[row_I[i]])^2 + (patchcentres_y[suscPatchInFence$col] - patchcentres_y[col_I[i]])^2))/alpha)
        }else{                     # if patch is not in fence, infection pressure only exerted on others outside fence
          
          # Compute infectious pressure on within-fence patches
          infectiousPressure[(suscPatchNotInFence$col-1)*npatches_x + suscPatchNotInFence$row] <- 
            infectiousPressure[(suscPatchNotInFence$col-1)*npatches_x + suscPatchNotInFence$row] +              # infection pressure on susceptible WB = (infection pressure on susceptible WB) + number of WB in susceptible patch * number of WB in patch [i,j] + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
            nBoarsMatrix[(suscPatchNotInFence$col-1)*npatches_x + suscPatchNotInFence$row] * nBoarsMatrix[row_I[i],col_I[i]] * patchToBoarRate *
            beta*exp(-(sqrt((patchcentres_x[suscPatchNotInFence$row] - patchcentres_x[row_I[i]])^2 + (patchcentres_y[suscPatchNotInFence$col] - patchcentres_y[col_I[i]])^2))/alpha)
        }
        
      }
      
    }else{         # IF LESS THAN DAY 60 OR FENCE = FALSE, COMPUTE PRESSURES 'AS USUAL'
      
      
      for(i in 1:length(row_I)){
        infectiousPressure[LinIdx] <- infectiousPressure[LinIdx] +              # infection pressure on susceptible WB = (infection pressure on susceptible WB) + number of WB in susceptible patch * number of WB in patch [i,j] + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
          nBoarsMatrix[LinIdx] * nBoarsMatrix[row_I[i],col_I[i]] * patchToBoarRate *
          beta*exp(-(sqrt((patchcentres_x[row] - patchcentres_x[row_I[i]])^2 + (patchcentres_y[col] - patchcentres_y[col_I[i]])^2))/alpha)
        
      }
      
    }
    
    
    
    ##########################################################################################################
    ###################################    COMPUTE BOAR NUMBERS BY INFECTION STATUS   ########################
    
    # Calculate total rate
    I <- length(which(infectionStatusMatrix==1))        # number of current infected patches 
    S <- length(which(infectionStatusMatrix==0))        # number of current susceptible patches
    
    
    ########################################################################################################
    ##########################################     UPDATE TIME       #######################################
    
    # Work out time of next event 
    proposedTime <- timings + dt 
    timings <- proposedTime
    
    
    # Update time counter  
    
    timeVals[recNumHere] <- timings
    
    ######################################################################################################
    #######################################       DO EVENTS       ########################################
    
    
    ## INFECTION ##
    
    numInfect <- rpois(1, sum(infectiousPressure)*dt)  # Compute number of patches to be infected at this time step
    if(numInfect > S){
      numInfect <- S
    }
    #print(paste("numInfect=", numInfect))
    
    ## UPDATE NUMBER OF INFECTIONS ##
    
    IVals[recNumHere] <- I + numInfect                 # Update number of infected patches
    
    
    ## DETERMINE, BASED ON THE INFECTIOUS PRESSURE, WHICH PATCHES ARE TO BE INFECTED  ##
    
    infectiousPressureProportions <- infectiousPressure/sum(infectiousPressure) # Calculate the infectious pressure proportions =
    
    toBeSampled <- which(infectiousPressureProportions!=0)                    ## Prior to sampling, omit zero proportions. 
    indexInfect <- sample(x = toBeSampled, size = numInfect, prob = infectiousPressureProportions[toBeSampled], replace = F) # sampled based on probability
    infectionStatusMatrix[indexInfect] <- 1 
    

    ## UPDATE WILD BOAR NUMBERS ##
     # Increased hunting pressure begins at day 60
    
  #  print(patchToBoarRate)
     if(timings > 59 & increased.pressure){
       within_fence <- ceiling(sum(nBoarsMatrix[which(in.fence.matrix==1 & infectionStatusMatrix==1)])*patchToBoarRate*detectRate_within_fence)  # Number of infected wild boar based on positions of current infections
       outside_fence <-  ceiling(sum(nBoarsMatrix[which(in.fence.matrix==0 & infectionStatusMatrix==1)]*patchToBoarRate*detectRate))
       wildBoarVals[recNumHere] <- within_fence + outside_fence + rpois(1, found_rate) # Found: both AS and PS, primarily within fence
       }else{
        wildBoarVals[recNumHere] <- ceiling(sum(nBoarsMatrix[which(infectionStatusMatrix==1)]*patchToBoarRate*detectRate))  +  rpois(1, found_rate) # Number of infected wild boar based on positions of current infections; rpois represents both AS and PS, primarily within fence
     }
    
    ## Inserted after simulations no not reflected in output ###
    if(timings>1){ # If fewer detected boar (cumulatively) at t+1 than at t, set cumulative number at t+1 to that at t. So 0 detected boar on that day.
      if(wildBoarVals[recNumHere] <  wildBoarVals[recNumHere-1]){
        wildBoarVals[recNumHere] <- wildBoarVals[recNumHere-1]
      }
    }
    ###
    
    
    # This patchToBoarRate is for a full patch. Once you begin to remove boar, the observed numbers change
    # The definition of the model is such that wildBoarVals is cumulative so you cannot remove boar or else it breaks down the structure
    #print(sum(nBoarsMatrix[which(dat.seed[[i]]==1)])*0.12*0.1)
    # nBoarsMatrix <- update.boar.numbers(nBoarsMatrix,
    #                            total = min(removals$total[timings], sum(nBoarsMatrix)))
    # 
    ## TRACK LOCATIONS OF INFECTED PATCHES ##
    
    coordIndices <- as.data.frame(which(infectionStatusMatrix == 1, arr.ind = TRUE))  # Matrix indices for infected patches
    coordInfected[[recNumHere]] <- data.frame(X = patchcentres$X[coordIndices$row], Y = patchcentres$Y[coordIndices$col]) # Coordinates of infected patches
    
    ## RECORD INFECTION STATUS MATRIX ##
    
    statusEachTimeStep[[recNumHere]] <- infectionStatusMatrix      # Store infection status matrix at each time step
    
    
    ## UPDATE COUNTER ##
    
    recNumHere <- recNumHere + 1  
    
   
    
    
    ## SHOW SIMULATION PROGRESS ##
    if(verbose){ cat('t =', timings, ';', 'W =', wildBoarVals[length(wildBoarVals)], "\n")}
  }
  
  
  
  ##########################################################################################################
  ################################################  ORGANIZE OUTPUT ########################################
  
  
  #df <- as_tibble(data.frame('day' = timeVals, 'cumulative.cases.patches' = IVals, 'new.cases.wb' = wildBoarVals, 'cumulative.cases.wb' = cumsum(wildBoarVals)))
  a <- dplyr::as_tibble(data.frame('day' = timeVals, 'cumulative.cases.patches' = IVals,  'cumulative.cases.wb' = wildBoarVals))
  
  df <- a %>% dplyr::mutate(new.cases.wb = cumulative.cases.wb - c(0, head(cumulative.cases.wb, -1)))# compute daily cases from cumulative. 
  
  
  return(list(summarized.res = df, coord.infected = coordInfected, status.matrices = statusEachTimeStep))
}



