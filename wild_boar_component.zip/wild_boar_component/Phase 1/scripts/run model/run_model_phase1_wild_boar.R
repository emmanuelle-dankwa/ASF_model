### PREAMBLE ####
        ### THIS SCRIPT CONTAINS CODE FOR 
        ## IMPLEMENTING A TRANSMISSION MODEL FOR WILD BOAR ####
        ## ASF CHALLENGE, PHASE 1 - UK TEAM ###


# See main model script, model_phase_1_wild_boar.R, for details on function arguments.

sample_model_output_phase1 <- model_phase1(beta = 0.002,                     # mean of estimated distribution
                                    alpha = 822.5,                    # mean of estimated distribution (in m)
                                    patchToBoarRate_1 = 0.1454,       # mean of estimated distribution
                                    patchToBoarRate_2 = 0.2995,       # mean of estimated distribution
                                    timings.max = 50,                  # last day observed
                                    verbose = T)                       # print simulation progress




# Save output
# sample_model_output.RDS already exists in the output-data folder
# Uncomment code below if you would like to save new version.

saveRDS(sample_model_output_phase1, file = glue::glue(wd.output.data, "model output/sample_model_output_phase1.RDS")) 


