###########################################
# AFRICAN SWINE FEVER MODEL FOR WILD BOAR #
#      ASF CHALLENGE - UK TEAM            #
#                                         #
# Perform parameter estimation at Phase 1
#  (run in parallel mode )  # 
###########################################


# Load packages # 
library(parallel)
library(glue)
library(dplyr)
library(tmvtnorm)


# Specify directories #
setwd("~/Phase 1")
wd.output.data <- "./output-data/"    # Directory for output data 


# Load input data #
source("./scripts/run model/preamble_data_model_phase1.R")                


# Load model #

source("./scripts/run model/model_phase1_wild_boar.R")                   


# Load functions #

source("./scripts/functions/all_functions_phase1.R")  


#### SPECIFY PRIORS  AND TOLERANCE ####


# PRIORS
dat <- list(data.frame(
  p.upp = c(0.0030, 900, 0.20, 0.30),  # Upper
  p.low = c(0.0009, 800, 0.10, 0.20)   # Lower
))


# TOLERANCE 
# Summary statistic 1: Daily number of cases 
# Summary statistic 2: Area (in km^2) of minimum convex polygon 
# Summary statistic 3: Cumulative number of cases 

tolerance <- data.frame(
  epsilon_cases = c(150,  120, 100, 85, 70),            # Temperature schedule for summary statistic 1
  epsilon_area = c(7300, 7100, 6500, 5000, 4000),         # Temperature schedule for summary statistic 2
  epsilon_cumulative = c(80, 60, 50, 40, 30)           # Temperature schedule for summary statistic 3
)




### SET UP TO RUN ON MULTIPLE CORES ####
print(paste("Number of cores:", detectCores()))


param_estims_phase1<- parallel::mclapply(X = dat,                    # mclapply for Mac or Linux  
                                          FUN = run_ABC_SMC_phase1,  # see line 287 of all_functions_phase1.R
                                          mc.cores = detectCores(),
                                          verbose.val = F, 
                                          timings.max.val = 50,
                                          N = 500,
                                          M= 50,
                                          n=2)
