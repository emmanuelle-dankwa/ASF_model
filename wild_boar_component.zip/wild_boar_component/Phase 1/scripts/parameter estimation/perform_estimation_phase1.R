#### PREAMBLE ####

    ## THIS SCRIPT CONTAINS CODE FOR:
    ## PERFORMING PARAMETER ESTIMATION FOR A 
    ## TRANSMISSION MODEL FOR AFRICAN SWINE FEVER (ASF) IN WILD BOAR
    ## ESTIMATION METHOD USED IS APPROXIMATE BAYESIAN COMPUTATION (ABC) SMC MNN ADAPTED FROM MINTER & RETKUTE (2019)
    ### ASF CHALLENGE, PHASE 1- UK TEAM ###
#* See end of script  for code if running on cluster #



## RUN ON LOCAL ##



#### SET UP; SPECIFY PRIORS, TOLERANCES ####


# PRIORS
p.upp <- c(0.004, 1000, 0.20, 0.50)  # Upper
p.low <- c(0.001, 800, 0.09, 0.20)   # Lower



# TOLERANCE 
# Summary statistic 1: Daily number of cases 
# Summary statistic 2: Area (in km^2) of minimum convex polygon 
# Summary statistic 3: Cumulative number of cases 


epsilon_cases <- c(150,  120, 100, 85)            # Temperature schedule for summary statistic 1
epsilon_area <- c(7300, 7100, 6500, 5000)         # Temperature schedule for summary statistic 2
epsilon_cumulative <- c(80, 60, 50, 40)           # Temperature schedule for summary statistic 3

    
# OTHER

# Number of parameters being estimated

n.par <- length(p.low)

# Number of particles
N <- 500

# Number of simulations for each parameter set
n <- 5

# Maximum number of days

timings.max <- 50


# Number of generations; 
# Preferred particles are those from the last generation as those have the strictest tolerances
G <- length(epsilon_cases)

# Number of neighbours for covariance matrix calculations
M <- 50    # should always be less than or equal to N (if equal to N, then ABC-SMC)


# Empty matrices to store results (5 model parameters)
res.old<-matrix(ncol=n.par,nrow=N)
res.new<-matrix(ncol=n.par,nrow=N)

# Empty vectors to store weights
w.old<-matrix(ncol=1,nrow=N)
w.new<-matrix(ncol=1,nrow=N)


# Save infection status matrix for accepted simulations
status.matrices <- list()                  




for(g in 1:G){  
    
    #Initiate counter
    i<-1    
    while(i <= N){ # While the number of accepted particles is less than N_particles
        if(g==1){
            # Sample from prior distributions 
            beta_star<- runif(1,min=p.low[1], max=p.upp[1])
            alpha_star<-runif(1, min=p.low[2], max=p.upp[2])
            patchToBoarRate_1_star <- runif(1, min=p.low[3], max=p.upp[3])
            patchToBoarRate_2_star <- runif(1, min=p.low[4], max=p.upp[4])
            # mu_star<-runif(1, min=p.low[3], max=p.upp[3])
        }else{
            #  Select particle from previous generation
            p<-sample(seq(1,N),1,prob=w.old)
            sigma <- Sigma[[p]]
            par<- kern(res.old[p,],sigma)
            beta_star<-par[1]
            alpha_star<-par[2]
            patchToBoarRate_1_star <- par[3]
            patchToBoarRate_2_star <- par[4]
            #mu_star<-par[3]
        }
        #  Test if prior non zero; i.e. test if not in the initially defined prior interval
        if(prior.non.zero(c(beta_star, alpha_star, patchToBoarRate_1_star, patchToBoarRate_2_star))) {
            # Set number of accepted simulations to zero
            m<-0
            distance <-matrix(ncol=3,nrow=n) # n = number of simulations with parameter set; m = number of times those simulations get accepted, #column 1 for case_distance, column 2 for area distance 
            status.matrices.temp <- list()  
            accepted.indices <- c()          # vector to save indices of accepted simulations. 
            for(j in 1:n){
                D_star<-model_phase1(beta = beta_star, alpha = alpha_star, patchToBoarRate_1 = patchToBoarRate_1_star, patchToBoarRate_2 = patchToBoarRate_2_star, timings.max = 50,verbose = T)     
                # Calculate distances 
                calc.dist <-calc_distance(D_star)
                distance[j,] <- calc.dist    # save the distances
                status.matrices.temp[[j]]<- D_star$status.matrices                      # save the infection status matrices 
                if(calc.dist[1] <= epsilon_cases[g] & calc.dist[2] <= epsilon_area[g] & calc.dist[3] <= epsilon_cumulative[g]){ # If distance is less than their tolerances, accept!
                    m<-m+1
                    accepted.indices <- c(accepted.indices, j)
                }              
            }   
            if (m>0){ 
                # Store results
                res.new[i,] <- c(beta_star, alpha_star, patchToBoarRate_1_star,  patchToBoarRate_2_star)
                ## Choose which simulation to save; choose the set with the minimum distance) ##
                distances.from.zero <- apply(matrix(distance[accepted.indices, ], ncol = 3), 1, distance_from_threshold)
                min.distance.ind <- accepted.indices[which(distances.from.zero==min(distances.from.zero))] # Row Index (in distance matrix) of parameter simulation corresponding to smallest value ; [1], in case there are more than one minimum values 
                status.matrices[[i]] <- status.matrices.temp[[min.distance.ind]]       # Saves the status matrix (at day 50) corresponding to the accepted parameter set 
                # Calculate weights - use uniform distribution 
                w1 <- prod(sapply(1:n.par, function(b) dunif(res.new[i,b], min=p.low[b], max=p.upp[b])))
                if(g==1){
                    w2<-1
                } else {
                    w2<-sum(sapply(1:N, function(a) w.old[a]* dtmvnorm(res.new[i,], mean=res.old[a,], sigma=sigma, lower=p.low, upper=p.upp))) # denominator in expression for w_g^(i) - step 8 - algorithm.  Weight of particle in previous generation * kernel (current particle given previous particle)
                }
                w.new[i] <- (m/n)*w1/w2 # m = number of accepted particles; n = number of trial particles. Weight w1/w2 by the fraction of accepted particles so far in that generation. 
                # Update counter
                i <- i+1
                print(paste0('Generation: ', g, ", particle: ", i))
            
            }
        } 
    }
    
    Sigma <- list(NA, N)
    for(p in 1:N){
        Sigma[[p]]<- getSigmaNeighbours(M, res.new[p,], res.new) 
    } 
    res.old <- res.new
    w.old <- w.new/sum(w.new) # normalize weights
    
    results <- list(estims = res.old,
                    mat = status.matrices)
    saveRDS(results, file = glue(wd.output.data, "parameter estimates/results_gen_" , g, ".RDS") )  # Save results for generation g
    
    if(g==4){
    # Also, save to relevant pig herd model location
    saveRDS(results, file = here::here("ASF_model", "pig_herd_component", "Phase1", "Model_Predict", "input", "results_gen_4.RDS")) 
    }
}


# Reference:

# 1. Minter, A. & Retkute, R. (2019). Approximate Bayesian Computation for infectious disease modelling. Epidemics, 29, 100368.






## ALTERNATIVELY, RUN IN PARALLEL MODE ##

source("~/Phase 1/scripts/parameter estimation/perform_estimation_phase1_parallel.R")


