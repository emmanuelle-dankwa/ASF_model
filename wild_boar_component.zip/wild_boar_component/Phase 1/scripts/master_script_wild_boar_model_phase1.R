### PREAMBLE ####

  ## THIS MASTER SCRIPT CALLS ALL THE SCRIPTS FOR 
  ## THE AFRICAN SWINE FEVER (ASF) TRANSMISSION 
  ## MODEL FOR WILD BOAR ###
  ## ASF CHALLENGE, PHASE 1 - UK TEAM ###

  ## RUN THE SCRIPTS IN THE FOLLOWING ORDER: ###
  
    # * SET UP
    # * DATA PREPARATION 
    # * RUN MODEL
    # * PARAMETER ESTIMATION (please note: computationally intensive; see script for details)
    # * PREDICTION (this section can be run without having run the previous section)
  

#### SET UP ####


  ## DEFINE DIRECTORIES  ##
  
  setwd("./wild_boar_component/Phase 1")
  
  
  wd.raw.data <- "./raw-data/"          # Directory for official data on island characteristics from Merry Island
  wd.output.data <- "./output-data/"    # Directory for output data 
  wd.figs <- "./plots/"                 # Directory for saving plots 
  
  
  ## LOAD REQUIRED LIBRARIES 
  
  #install.packages("pacman")
  pacman::p_load(glue, tidyr, sf, sp, 
                 rgdal, rgeos, raster, dplyr,
                 pracma, spatstat, spdep, pracma,
                 Rcpp, knitr, parallel, splancs, grDevices) 
  
  
  ## LOAD REQUIRED FUNCTIONS  ##
  
  source("./scripts/functions/all_functions_phase1.R")    # Loads all required functions
  



  


#### DATA PREPARATION ####

source_rmd("./scripts/data preparation/data_prep_1_phase1.Rmd")
source("./scripts/data preparation/data_prep_2_phase1.R")



#### RUN MODEL ####

source("./scripts/run model/preamble_data_model_phase1.R")                # Loads input data for model and estimation
source("./scripts/run model/model_phase1_wild_boar.R")                    # Loads model function
source("./scripts/run model/run_model_phase1_wild_boar.R")                # Performs a single run of the model and saves the outputs 




#### PARAMETER ESTIMATION ####


source("./scripts/parameter estimation/perform_estimation_phase1.R")      # Performs estimation

  


#### PREDICTION ####

source("./scripts/run model/prediction_model_phase1.R")                          # Load prediction model
source_rmd("./scripts/prediction/compute_forward_predictions_phase1.R")          # Generates predictions
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  





