###########################################
# AFRICAN SWINE FEVER MODEL FOR WILD BOAR #
#      ASF CHALLENGE - UK TEAM            #
#                                         #
# Compute projections for day 51-78 under 
#            various scenarios            #
###########################################


# Load packages # 
library(parallel)
library(glue)
library(dplyr)
library(tmvtnorm)

# IMPORT ESTIMATES # 
res <- readRDS(file = "./output-data/parameter estimates/results_gen_4.RDS") # N= 500


# Specify directories #
wd.output.data <- "./Phase 1/output-data/"    # Directory for output data 


# Load input data #
source("./scripts/run_model/preamble_data_model_phase1.R")                # Loads input data for model and estimation


# Load model #

source("./scripts/prediction/prediction_model_phase1_wild_boar.R")                    # Loads model function


# Load functions #


source("./scripts/functions/all_functions_phase1.R")  



# Get seed (status at day 50) for supply to models for prediction

dat.seed <- list()                 # Get day 50 matrix from each of these simulations to seed the forward runs
for(i in 1:length(res$mat)){
  dat.seed[[i]] <- res$mat[[i]][[50]]  # Obtain 500 matrices containing status information at day 50.
}



# ### No fence, no increased hunting pressure ####
#
# # Create list to save outputs
 forward.run <- list()
#

#
 for(i in 1:length(dat.seed)){
  print(i)
  res_i <- prediction_model_phase1(beta = res$estims[,1][i],
                        alpha = res$estims[,2][i],
                        patchToBoarRate_1 = res$estims[,3][i],
                        patchToBoarRate_2 = res$estims[,4][i],
                        timings.max = 28,                     # Running model for 28 days, first day corresponds to day 51 and last day corresponds to day 78
                        fence = FALSE,                        # No fence
                        forward.simulation = TRUE,
                        seed = dat.seed[[i]],
                        verbose = F)                 # Infection status of patches by the end of day 50

  forward.run$status[[i]] <- res_i$status.matrices
  forward.run$coord[[i]] <- res_i$coord.infected
  forward.run$counts[[i]] <- res_i$summarized.res

}

# # Save
#
# # Save predictions
saveRDS(forward.run, file =  glue(wd.output.data, "predictions/forward.run.RDS"))









#
# ### Fence and normal hunting pressure  ####
#
#
# # Create list to save outputs
forward.run.fence <- list()

for(i in 1:length(dat.seed)){

  res_i <- prediction_model_phase1(beta = res$estims[,1][i],
                        alpha = res$estims[,2][i],
                        patchToBoarRate_1 = res$estims[,3][i],
                        patchToBoarRate_2 = res$estims[,4][i],
                        timings.max = 28,
                        fence = TRUE,                               # Fence
                        forward.simulation = TRUE,
                        seed = dat.seed[[i]],
                        verbose = T)

  forward.run.fence$status[[i]] <- res_i$status.matrices
  forward.run.fence$coord[[i]] <- res_i$coord.infected
  forward.run.fence$counts[[i]] <- res_i$summarized.res

}

# Save

saveRDS(forward.run.fence, file = glue(wd.output.data, "predictions/forward.run.fence.RDS"))






### Fence and increased hunting pressure ####

forward.run.fence.increased.pressure <- list()

for(i in 1:length(dat.seed)){
  print(i)
res_i <- prediction_model_phase1(beta = res$estims[,1][i], 
                             alpha = res$estims[,2][i],
                             patchToBoarRate_1 = res$estims[,3][i],
                             patchToBoarRate_2 = res$estims[,4][i], 
                             timings.max = 28, 
                             fence = TRUE,
                             increased.pressure = TRUE, 
                             forward.simulation = TRUE, 
                             seed = dat.seed[[i]],
                             verbose = T,
                             detectRate_within_fence  = 0.90/78) # 90% expected to be hunted by day 78; (day 1 to day 78; a 78-day period)
  
  forward.run.fence.increased.pressure$status[[i]] <- res_i$status.matrices
  forward.run.fence.increased.pressure$coord[[i]] <- res_i$coord.infected
  forward.run.fence.increased.pressure$counts[[i]] <- res_i$summarized.res
  
}

# Clear working directory 

rm(list=setdiff(ls(), "forward.run.fence.increased.pressure"))

# Save 
saveRDS(forward.run.fence.increased.pressure, file = glue(wd.output.data, "predictions/forward.run.fence.increased.pressure.RDS"))





