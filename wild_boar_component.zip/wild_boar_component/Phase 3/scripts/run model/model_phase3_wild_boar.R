### THIS SCRIPT CONTAINS CODE FOR A TRANSMISSION MODEL FOR WILD BOAR #### 
### ASF CHALLENGE, PHASE 3 - UK TEAM ###


##### MODEL FUNCTION #####


## Arguments (input) ##

# beta:               Transmission rate
# alpha:              Spatial scale
# hunt.test.prop:     Proportion of hunted boar that are tested in a "normal hunting pressure" scenario. 
# max.infection.range: Maximum distance (in km) beyond which a patch cannot transmit infection 
# timings:            First day for simulation
# timings.max:        Last day for simulation (maximum allowable value is 80 = number of days observed by phase 2)
# dt:                 Time interval (in days); set to 1. 
# fence:              Has fence been implemented?
# increased pressure: Increased hunting pressure?
# verbose:            Print simulation progress?   



## Model output ##

# A list containing the elements:

# summarized.res: Data frame of daily and cumulative counts of detected positive boar. 
#                 Columns of the data frame are: 
#       
          # day:                 Days for which simulation was performed
          # new.cases.wb:        Number of detected infected boar on 'day'
          # cumulative.cases.wb: Cumulative number of detected infected boar by 'day'


# status.matrices: List with length equal to timings.max with each list element corresponding to a day.
#                  Each list element is an indicator matrix showing which patches are infected at the corresponding day: 1 for infected and 0 if not infected.


# locations      : Data frame with information on all boar expected to be located within a given area, over which model simulations are performed. 
#                  Columns of the data frame relevant to the model simulation are: 
           # X:                   X-coordinate of boar location
           # Y:                   Y-coordinate of boar location
           # date.removed:        Observed removal date
           # date.removed2:       Removal date in model simulation
           # date.infected:       For positive boar, infection date. 0 for negative boar
           # date.death.recovery: For positive boar, expected date of death. 0 for negative boar
           # date.end.infectious: For positive boar, expected date for end of infectiousness. 0 for negative boar
           # patch:               Patch to which boar belong
           # infectionStatus:     Infection status of boar. 1 if infected and 0 if not infected
           # index:               Unique ID of boar
           # carcass:             Is boar a carcass? 1 if carcass and 0 if not a carcass
           

model_phase3<- function(beta, 
                         alpha,
                         hunt.test.prop = 0.2,
                         max.infection.range = 8,
                         timings = 1,
                         timings.max, 
                         dt=1, 
                         fence = TRUE, 
                         increased.pressure=TRUE,
                         verbose = F){ 
  ##########################################################################################################
  ############################### INPUT QUALITY CHECKS & VALUE DEFINITIONS #################################
  
  ## Input Quality Checks ##
  
  if(increased.pressure & !fence){
    stop("Increased pressure can only be implemented within fence. Set fence to TRUE.")
  }
  
  if(timings.max > 110){
    stop("Maximum allowable value for 'timings.max' for phase 3 is 110. \n Set 'timings.max' less than or equal to 110.")
  }
  
  
  ## Define values ##
  
  npatches_x <- npatches_y <-  nrow(patchcentres) # Number of patch centres
  patchcentres_x <- patchcentres$X                # X coordinates of patch centres
  patchcentres_y <- patchcentres$Y                # Y coordinates of patch centres
  patch.ids <- c(1:2500)                          # unique IDs of patches
  timeVals <- c()                                 # Vector for storing event times (in days)
  wildBoarVals <- c()                             # Vector for storing counts of detected positive wild boar
  recNumHere <- 1                                 # Counter. Set start to 1.
  statusEachTimeStep <- list()                    # List for storing (daily) indicator matrices for infection status of patches
  patches.in.fence <- which(in.fence.matrix==1)         # IDs of patches within fence 
  patches.in.zone <- which(in.fence.buffer.matrix==1)   # IDs of patches within fence-buffer (zone)
  
  
  ##########################################################################################################
  ##########################################################################################################
  
  updated.boar <- locations     # Initialize data frame to be updated at each day. Updates are implemented by dropping the removed boar on that day. 
  
  while(sum(infectionStatusMatrix==1) > 0 & timings <= timings.max ){ # Keep running model if there is at least one infection in the population and the max. day is not yet reached. 
    
    
    ##########################################################################################################
    ###############################   COMPUTE PATCH-LEVEL INFECTION PRESSURE   ################################
    
    
    infectiousPressure <- double(npatches_x*npatches_y)                            # matrix for storing values for infectious pressure on WB
    
    row_I <- as.data.frame(which(infectionStatusMatrix == 1, arr.ind = TRUE))$row  # save row indices for infected patches 
    col_I <- as.data.frame(which(infectionStatusMatrix == 1, arr.ind = TRUE))$col  # save column indices for infected patches 
    
    row <- as.data.frame(which(infectionStatusMatrix == 0, arr.ind = TRUE))$row   # save row indices  for susceptible patches
    col <- as.data.frame(which(infectionStatusMatrix == 0, arr.ind = TRUE))$col   # save column indices for susceptible patches
    
    LinIdx <- (col-1)* nrow(infectionStatusMatrix) + row                         # matrix indices of susceptible patches
    LinIdx_I <- (col_I-1)* nrow(infectionStatusMatrix) + row_I                   # matrix indices of infected patches (a patch is infectious if it has at least one infectious boar)
    
    # Identify susceptible patch position in relation to fence
    suscPatchInFence <- data.frame(which(in.fence.matrix==1 & infectionStatusMatrix==0, arr.ind = TRUE)) 
    suscPatchNotInFence <- data.frame(which(in.fence.matrix==0 & infectionStatusMatrix==0, arr.ind = TRUE)) 
    sPInFence_Idx <- (suscPatchInFence$col-1)*npatches_x + suscPatchInFence$row            # matrix indices of susceptible patches within fence 
    sPNotInFence_Idx <- (suscPatchNotInFence$col-1)*npatches_x + suscPatchNotInFence$row   # matrix indices of susceptible patches outside fence 
    
  
    
    numb.inf.boar.in.inf.patches <- numbboarstateC(LinIdx_I = LinIdx_I, updatedboar = updated.boar, id = id, marker = 1) # numbboarstateC: written in C++; to speed up code.
    numb.susc.boar.in.inf.patches <- numbboarstateC(LinIdx_I = LinIdx_I, updatedboar = updated.boar, id = id, marker = 0)
    

    
    if(fence&timings>=60){     # IMPLEMENT FENCE FROM DAY 60
      
      for(i in 1:length(row_I)){ # for all infectious patches,
        
        # If infectious patch is in fence,
        if(in.fence.matrix[row_I[i], col_I[i]]==1){ # if infected patch is in fence,
          
          ## Compute infectious pressure on susceptible within-fence patches ##
          
          # Identify patches which fall within the infection range
          
          in.infect.range <- which(usedist::dist_get(dist.patches, LinIdx_I[i],sPInFence_Idx) <= max.infection.range)  # Indices of susceptible patches which fall within the possible infection range. 
  
          infectiousPressure[sPInFence_Idx[in.infect.range]] <- 
            infectiousPressure[sPInFence_Idx[in.infect.range]] +              # infection pressure on susceptible wild boar (WB) = (infection pressure on susceptible WB) + number of WB in susceptible patch * number of infectious WB in infectious patch [i,j] + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
            nBoarsMatrix[sPInFence_Idx[in.infect.range]] *  numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[suscPatchInFence$col[in.infect.range]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[suscPatchInFence$row[in.infect.range]] - patchcentres_y[row_I[i]])^2))/alpha))
       
          
             
          # Introducing the possibility of an infected patch within the fence to infect susceptible patches outside the fence within max.infection.range/2
          
              # Identify patches outside the fence which fall within max.infection.range/2
          in.infect.range.outside.fence <-  which(usedist::dist_get(dist.patches, LinIdx_I[i],sPNotInFence_Idx) <= max.infection.range/2)
          
          infectiousPressure[sPNotInFence_Idx[in.infect.range.outside.fence]] <- 
            infectiousPressure[sPNotInFence_Idx[in.infect.range.outside.fence]] +              # infection pressure on susceptible WB = (infection pressure on susceptible WB) + number of WB in susceptible patch * number of infectious WB in infectious patch [i,j] + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
            nBoarsMatrix[sPNotInFence_Idx[in.infect.range.outside.fence]] *  numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[suscPatchNotInFence$col[in.infect.range.outside.fence]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[suscPatchNotInFence$row[in.infect.range.outside.fence]] - patchcentres_y[row_I[i]])^2))/alpha))
          
          
          
          
          
        
          ## Compute infectious pressure on infected within-fence patches ##
          
          
          # # Identify indices of infected patches within fence 
          index.inf.patches.in.fence <- which(LinIdx_I %in% patches.in.fence)
          
          # Identify patches which fall within the infection range
          
          in.infect.range <- which(usedist::dist_get(dist.patches, LinIdx_I[i], LinIdx_I[index.inf.patches.in.fence]) <= max.infection.range)
          
          infectiousPressure[LinIdx_I[index.inf.patches.in.fence][in.infect.range]] <-  infectiousPressure[LinIdx_I[index.inf.patches.in.fence][in.infect.range]] +
            numb.susc.boar.in.inf.patches[index.inf.patches.in.fence][in.infect.range] *                                  
            numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[col_I[index.inf.patches.in.fence][in.infect.range]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[row_I[index.inf.patches.in.fence][in.infect.range]] - patchcentres_y[row_I[i]])^2))/alpha))
          
          
          
          # Introducing the possibility of an infected patch within the fence to exert infectious pressure on an infected patch outside the fence within max.infection.range/2
          
              # Identify indices of infected patches outside the fence 
          index.inf.patches.outside.fence <- which(!(LinIdx_I %in% patches.in.fence))
          
          
          
          in.infect.range.outside.fence <-  which(usedist::dist_get(dist.patches, LinIdx_I[i],LinIdx_I[index.inf.patches.outside.fence]) <= max.infection.range/2)
         
          
           infectiousPressure[LinIdx_I[index.inf.patches.outside.fence][in.infect.range.outside.fence]] <-  infectiousPressure[LinIdx_I[index.inf.patches.outside.fence][in.infect.range.outside.fence]] +
            numb.susc.boar.in.inf.patches[index.inf.patches.outside.fence][in.infect.range.outside.fence] *                                     
            numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[col_I[index.inf.patches.outside.fence][in.infect.range.outside.fence]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[row_I[index.inf.patches.outside.fence][in.infect.range.outside.fence]] - patchcentres_y[row_I[i]])^2))/alpha))
          
          
          
        }else{   # if infected patch is outside fence                           
          
          ## Compute infectious pressure on susceptible out-of-fence patches ##
          
          # Identify patches which fall within the infection range
          
          in.infect.range <- which(usedist::dist_get(dist.patches, LinIdx_I[i],sPNotInFence_Idx) <= max.infection.range)  # Indices of susceptible patches which fall within the possible infection range. 
          
          infectiousPressure[sPNotInFence_Idx[in.infect.range]] <- 
            infectiousPressure[sPNotInFence_Idx[in.infect.range]] +              # infection pressure on susceptible WB = (infection pressure on susceptible WB) + number of WB in susceptible patch * number of WB in patch [i,j] + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
            nBoarsMatrix[sPNotInFence_Idx[in.infect.range]] *  numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[suscPatchNotInFence$col[in.infect.range]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[suscPatchNotInFence$row[in.infect.range]] - patchcentres_y[row_I[i]])^2))/alpha))
          
          

          # Introducing the possibility of an infected patch outside the fence infecting susceptible patches within the fence within max.infection.range/2

          # Identify susceptible patches within the fence which fall within max.infection.range/2 of patch
          in.infect.range.within.fence <-  which(usedist::dist_get(dist.patches, LinIdx_I[i],sPInFence_Idx) <= max.infection.range/2)

          infectiousPressure[sPInFence_Idx[in.infect.range.within.fence]] <-
            infectiousPressure[sPInFence_Idx[in.infect.range.within.fence]] +              # infection pressure on susceptible WB = (infection pressure on susceptible WB) + number of WB in susceptible patch * number of infectious WB in infectious patch [i,j] + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively.
            nBoarsMatrix[sPInFence_Idx[in.infect.range.within.fence]] *  numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[suscPatchInFence$col[in.infect.range.within.fence]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[suscPatchInFence$row[in.infect.range.within.fence]] - patchcentres_y[row_I[i]])^2))/alpha))


          
          
          
          ## Compute infectious pressure on infected out-of-fence patches ##
          
          # Identify indices of infected patches outside fence 
          index.inf.patches.out.fence <- which(!(LinIdx_I %in% patches.in.fence))
          
          # Identify patches which fall within the infection range
          
          in.infect.range <- which(usedist::dist_get(dist.patches, LinIdx_I[i], LinIdx_I[index.inf.patches.out.fence]) <= max.infection.range)
          
          
          infectiousPressure[LinIdx_I[index.inf.patches.out.fence][in.infect.range]] <-  infectiousPressure[LinIdx_I[index.inf.patches.out.fence][in.infect.range]] +
            numb.susc.boar.in.inf.patches[index.inf.patches.out.fence][in.infect.range]* # this gives the number of susceptible boar in these patches
            numb.inf.boar.in.inf.patches[i]*
            (beta*exp(-(sqrt((patchcentres_x[col_I[index.inf.patches.out.fence][in.infect.range]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[row_I[index.inf.patches.out.fence][in.infect.range]] - patchcentres_y[row_I[i]])^2))/alpha))
          
       
          
          # Introducing the possibility of an infected patch outside the fence exerting infectious pressure on infected patches within the fence within max.infection.range/2

          # Identify indices of infected patches inside the fence
          index.inf.patches.within.fence <- which(LinIdx_I %in% patches.in.fence)


          # Identify infected patches within the fence which fall within max.infection.range/2 of patch
          in.infect.range.within.fence <-  which(usedist::dist_get(dist.patches, LinIdx_I[i], LinIdx_I[index.inf.patches.within.fence]) <= max.infection.range/2)


          infectiousPressure[LinIdx_I[index.inf.patches.within.fence][in.infect.range.within.fence]] <-  infectiousPressure[LinIdx_I[index.inf.patches.within.fence][in.infect.range.within.fence]] +
            numb.susc.boar.in.inf.patches[index.inf.patches.within.fence][in.infect.range.within.fence] *                                      # this gives the number of susceptible boar in these patches
            numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[col_I[index.inf.patches.within.fence][in.infect.range.within.fence]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[row_I[index.inf.patches.within.fence][in.infect.range.within.fence]] - patchcentres_y[row_I[i]])^2))/alpha))


          
           }
        
      }
      
      
    }else{         # IF LESS THAN DAY 60 OR FENCE = FALSE, COMPUTE PRESSURES 'AS USUAL'
      
      for(i in 1:length(row_I)){
        
        
        # Compute infectious pressure on susceptible patches
        
        # Identify patches which fall within the infection range
        
        in.infect.range <- which(usedist::dist_get(dist.patches, LinIdx_I[i], LinIdx) <= max.infection.range)  # Indices of susceptible patches which fall within the possible infection range. 
        
        
        infectiousPressure[LinIdx[in.infect.range]] <- infectiousPressure[LinIdx[in.infect.range]] +              # infection pressure on susceptible patch = (infection pressure on susceptible patch) + number of susceptible WB in susceptible patch * number of infectious WB in infected patch ([i,j]) + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
          nBoarsMatrix[LinIdx[in.infect.range]] * numb.inf.boar.in.inf.patches[i] * 
          beta*exp(-(sqrt((patchcentres_x[col[in.infect.range]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[row[in.infect.range]] - patchcentres_y[row_I[i]])^2))/alpha)
        
        
        # Compute infectious pressure on infectious patches
        
        # Identify patches which fall within the infection range
        
        in.infect.range <- which(usedist::dist_get(dist.patches, LinIdx_I[i], LinIdx_I) <= max.infection.range)  # Indices of susceptible patches which fall within the possible infection range. 
        
        infectiousPressure[LinIdx_I[in.infect.range]] <- infectiousPressure[LinIdx_I[in.infect.range]] +
          numb.susc.boar.in.inf.patches[in.infect.range] * numb.inf.boar.in.inf.patches[i] *
          (beta*exp(-(sqrt((patchcentres_x[col_I[in.infect.range]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[row_I[in.infect.range]] - patchcentres_y[row_I[i]])^2))/alpha))
        
        
      }
    }    
    
    ##########################################################################################################
    ##################  DETERMINE NUMBER AND LOCATIONS OF NEW INFECTIONS WITHIN PATCHES #####################
    
    
    ## DETERMINE THE NUMBER OF NEW INFECTIONS IN EACH PATCH ##
    
    newInfect <- simulC(lambda = infectiousPressure)      # for all patches, determine how many boar will become infected using the infectious pressure as a Poisson rate.
                                                          # simulC: Poisson simulation function written in C++ to speed up code 
    
    ## GIVEN NUMBER OF EXPECTED INFECTIONS IN BOAR, CHOOSE THE LOCATION OF BOAR TO INFECT  ##
  
    patches.with.new.inf <- which(newInfect>0)                      # Pick up indices of patches with new infections

   
    if(length(patches.with.new.inf) != 0){                          # Only compute if there are no new infections 
      for(j in 1:length(patches.with.new.inf)){
        susc.boar.within.patch.j <- which(updated.boar$patch==patches.with.new.inf[j] & updated.boar$infectionStatus==0)
        
        if(length(susc.boar.within.patch.j) == 1){
          indexInfect.in.patch.j <- susc.boar.within.patch.j
        } else {
          indexInfect.in.patch.j <- sample(x =  susc.boar.within.patch.j, 
                                           size = min(newInfect[patches.with.new.inf][j], length(susc.boar.within.patch.j)),  # Cannot infect more boar than are susceptible in patch.
                                           replace = F)          
        }

        # Update infection status, infection date, date of death and date of expected start/end of infectiousness.
        locations[locations$index %in% updated.boar[indexInfect.in.patch.j, "index"], c("date.infected")] <-  rep(timings, length(indexInfect.in.patch.j))  # c(rep(0, length(indexInfect.in.patch.j)), rep(timings, length(indexInfect.in.patch.j)))
        updated.boar[indexInfect.in.patch.j,  "infectionStatus"] <- rep(1, length(indexInfect.in.patch.j))
        updated.boar[indexInfect.in.patch.j,  c("date.infected", "date.death.recovery", "date.end.infectious", "date.start.infectious")] <- c(rep(timings, length(indexInfect.in.patch.j)), rep(timings+14, length(indexInfect.in.patch.j)), rep(timings+104, length(indexInfect.in.patch.j)), rep(timings+5, length(indexInfect.in.patch.j)))  
       
      }                                                                                                                                

    }
    
  
    
    
    ###################################################################################################
    #################################  DECREASE BOAR POPULATION  ######################################
    
    
    #################
    ### IN ZONE ###
    ################
  
   # CARCASS #
   
    set1.in.zone <- which(updated.boar$carcass==1 & updated.boar$patch %in% patches.in.zone)
   
    if(length(set1.in.zone) == 1){
      
      set1.in.zone <- set1.in.zone
      
    }else{
      
    set1.in.zone <- sample(x = set1.in.zone,
                          size = min(removals$in.zone.found[timings], length(set1.in.zone)))
    
    }
    
    # HUNTED #
    
    if(length(set1.in.zone) < removals$in.zone.removed[timings]){
      
        
        toBeSampled.in.zone <- which(updated.boar$carcass == 0  &  updated.boar$patch %in% patches.in.zone)   
        
        
        if(length(toBeSampled.in.zone) == 1){
          
          set2.in.zone <- toBeSampled.in.zone
        } else { # Here, we assume that positive boar were more likely to be hunted than negative boar
                # as they were less likely to escape a hunt due to reduced activity as a result of ASF symptoms
          
         statustoBeSampled <- updated.boar[toBeSampled.in.zone, ]$infectionStatus   # Obtain infection status 
         probs <- ifelse(statustoBeSampled == 1,
                          0.55,
                         0.45) 

          set2.in.zone <- sample(x = toBeSampled.in.zone,
                                 size = min(length(toBeSampled.in.zone), removals$in.zone.removed[timings] - length(set1.in.zone)),
                                prob = probs,                                      # Sample with probability weights based on infection status
                                 replace = F)
        }
        
      
      ##  Save indices of boar selected to be removed
      boar.in.zone.removed <- c(set1.in.zone, set2.in.zone)         
      
    }else{
      
      boar.in.zone.removed <- set1.in.zone
      
    }  
    
    
    ######################
    ### OUTSIDE  ZONE ###
    #####################
 
    set1.out.zone <- which(updated.boar$carcass==1 & !(updated.boar$patch %in% patches.in.zone))
   
   if( length(set1.out.zone) ==1){
     
     set1.out.zone <- set1.out.zone
     
     
   }else{
    set1.out.zone <- sample(x = set1.out.zone,
                            size = min(removals$out.zone.found[timings], length(set1.out.zone)))
   }
    

    
    if(length(set1.out.zone) < removals$out.zone.removed[timings]){ # If sum of found boar is less than total number of observed removals, 
     

      toBeSampled.out.zone <- which( updated.boar$carcass == 0 & !(updated.boar$patch %in% patches.in.zone))  
      
      
      if(length(toBeSampled.out.zone) == 1){
        set2.out.zone <- toBeSampled.out.zone
      }else{
        
       set2.out.zone <- sample(x = toBeSampled.out.zone,
                            size = min(length(toBeSampled.out.zone), removals$out.zone.removed[timings] - length(set1.out.zone)),
                              replace = F)
      }
      
          # Save indices of removed boar
      boar.out.zone.removed<- c(set1.out.zone, set2.out.zone)         
      
    }else{
      
      boar.out.zone.removed <- set1.out.zone
      
    }  
    
    
    
    
    
    ### STORE INDICES AND REMOVAL DATES OF REMOVED BOAR ###
    
    boar.removed <- c(boar.in.zone.removed,
                      boar.out.zone.removed)
    
    # Record removal dates
    locations[locations$index %in% updated.boar[boar.removed, "index"],  "date.removed2"] <- timings
    
    
    
    
    
    # Update counts within zone #
    nBoarsMatrix[which(in.fence.buffer.matrix==1)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==1)], removals$in.zone.removed[timings])
    
    # Update counts outside zone #
    nBoarsMatrix[which(in.fence.buffer.matrix==0)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==0)], removals$out.zone.removed[timings])
    
    
    



    ######################################################################################################
    ##############################  COMPUTE NUMBER OF POSITIVE DETECTED BOAR   ###########################
    
    if(timings <= 59){
      
      found <- length(c(set1.in.zone, set1.out.zone))  # Model set up assumes all carcasses are infected. In the data, carcasses are always infected with only a few exceptions on some days (these do not exceed 2 per day) 
      wildBoarVals[recNumHere] <-   found + round((sum(updated.boar$infectionStatus[boar.removed] == 1) - found)*hunt.test.prop)  # expression in bracket is number of hunted positive boar at day 'timings'
      
    }else{
      found.out.zone <- length(set1.out.zone)   # Number found (not hunted) outside zone by active search (AS) or passive surveillance (PS)
      # After week 59, all boar found or hunted within the zone were tested. 
      wildBoarVals[recNumHere] <-  sum(updated.boar$infectionStatus[boar.in.zone.removed] == 1) + (found.out.zone + round((sum(updated.boar$infectionStatus[boar.out.zone.removed] == 1) - found.out.zone)*hunt.test.prop)) # First term: all positive boar removed in zone (100% of hunted tested, all found boar reported); Second term: positive boar removed outside zone (20% of hunted tested)
      
    }
    
    
    
    ### UPDATE BOAR NUMBERS ### 
    
    updated.boar <- updated.boar[-boar.removed, ]   # Drop removed boar
    
    
    
    
    
    #####################################################################
    #########################  RECORD CURRENT DAY  ######################
    
    ## Record time 
    
    timeVals[recNumHere] <- timings
    if(verbose){cat('t =', timings, ';' , "W=", sum(wildBoarVals), "\n")}  # Show current time if verbose == TRUE
    
    
    
    
    #######################################################################
    ### SAVE INDICATOR MATRIX FOR PATCH INFECTION STATUS AT CURRENT DAY #### 
    
    
    ## Record infection status matrix ##
    patches.with.inf <- unique(updated.boar$patch[updated.boar$infectionStatus==1])
    infectionStatusMatrix[patches.with.inf] <- 1                # Update infection status of patch in infection Status Matrix.
    
    statusEachTimeStep[[recNumHere]] <- infectionStatusMatrix
    
    
    
    
    #####################################################################
    #########################  UPDATE TIME  #############################
    
    
    ##  Update time 
    timings <-  timings + dt 
    
    ## Update counter
    recNumHere <- recNumHere + 1  
    
    
    
    
    
    #####################################################################
    ######################### IMPLEMENT TRANSITIONS  ###################
    
    
    # Update boar statuses at the beginning of day 'timings'.  
    updated.boar$carcass[updated.boar$date.death.recovery==timings] <- 1           # Assuming all infected die
    updated.boar$infectionStatus[updated.boar$date.end.infectious==timings] <- 2   # If last day of infection, assign 2 to infection status ('2' = indicator for 'recovered' and no more infectious)
    updated.boar$infectionStatus[updated.boar$date.start.infectious==timings] <- 1
    
    # Record in locations
    
    locations[locations$index %in% updated.boar[updated.boar$date.death.recovery==timings, "index"], "carcass"] <- 1
    locations[locations$index %in% updated.boar[updated.boar$date.start.infectious==timings, "index"], "infectionStatus"] <- 1
    locations[locations$index %in% updated.boar[updated.boar$date.end.infectious==timings, "index"], "infectionStatus"] <- 2
    
    
    #####################################################################
    ######################### UPDATE IINDICATOR MATRIX ###################
    
    
    # Update infection status matrix for next day
    infectionStatusMatrix[!(patch.ids %in% unique(updated.boar$patch[updated.boar$infectionStatus==1]))] <- 0 
    
  }
  
  
  
  ####################################################################
  ##########################  MODEL OUTPUT  ##########################
  
  df <- as_tibble(data.frame("day" = timeVals, "new.cases.wb" = wildBoarVals,  "cumulative.cases.wb" = cumsum(wildBoarVals)))
  
  return(list(summarized.res = df, status.matrices = statusEachTimeStep, locations = locations))  
}















