### PREAMBLE ####
        ### THIS SCRIPT CONTAINS CODE FOR 
        ## IMPLEMENTING A TRANSMISSION MODEL FOR WILD BOAR ####
        ## ASF CHALLENGE, PHASE 3 - UK TEAM ###
  

# See model script, model_phase_3_wild_boar.R, for details on function arguments.

sample_model_output <- model_phase3(beta = 0.003725, # chosen as mean of prior estimation interval
                                    alpha = 1000,                      # fixed alpha 
                                    timings = 60,                      # first day  
                                    timings.max = 110,                 # last day of observation
                                    verbose = T)                       # print simulation progress




# Save output
# sample_model_output_phase3.RDS already exists in the output-data folder
# Uncomment code below if you would like to save new version.

# saveRDS(sample_model_output, file = glue::glue(wd.output.data, "sample_model_output_phase3.RDS") ) 



