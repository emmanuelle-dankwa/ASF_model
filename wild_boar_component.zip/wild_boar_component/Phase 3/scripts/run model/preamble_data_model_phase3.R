## THIS SCRIPT CONTAINS CODE FOR 
## LOADING DATA REQUIRED FOR IMPLEMETING 
## A TRANSMISSION MODEL OF ASF IN WILD BOAR ##

### ASF CHALLENGE PHASE 3 - UK TEAM ###



# Load input data #

patchcentres <- readRDS(glue(wd.output.data, "model input/patchcentres.RDS"))                                     # Patch coordinates in the X and Y directions
infectionStatusMatrix <- readRDS(glue(wd.output.data, "model input/infectionStatusMatrix60.RDS"))          # Indicator matrix of infection status of patches 
nBoarsMatrix <- readRDS(glue(wd.output.data, "model input/nBoarsMatrix.RDS"))                                     # Matrix containing counts for the number of boar in each patch
all.patch.centres <- readRDS(glue(wd.output.data, "model input/all.patch.centres.RDS"))                           # Coordinates of all patch centres
locations <- readRDS(glue(wd.output.data, "model input/locations60.RDS"))                                         # Coordinates, removal dates, mode of detection, patch, region and infection date of all boar (both observed and simulated)  
in.fence.buffer.matrix <- readRDS(glue(wd.output.data, "model input/in.fence.buffer.matrix.RDS"))                 # Indicator matrix for presence of patch in the zone, i.e. within fence or buffer (1 = in the zone, 0 = outside the zone). 
in.fence.matrix <- readRDS(glue(wd.output.data, "model input/in.fence.matrix.RDS"))                               # Indicator matrix for presence of patch in the fence (1 = in the fence, 0 = outside the zone). 
removals <-  readRDS(glue(wd.output.data, "model input/removals.RDS"))                                            # Daily number of daily removals
dist.patches <- readRDS(glue(wd.output.data, "model input/dist.patches.RDS"))                                     # Dist object containing the distance (in km) between all patch centers. 


# Load observed data (used in estimation)
observed.positive.locations <- readRDS(glue(wd.output.data, "model input/observed.positive.locations60.RDS"))     # Coordinates of locations of detected positive boar from day 60 to day 110
observed.positive <-  readRDS(glue(wd.output.data, "model input/observed.positive.RDS"))                          # Daily case counts of detected positive boar from day 0 to day 110

















