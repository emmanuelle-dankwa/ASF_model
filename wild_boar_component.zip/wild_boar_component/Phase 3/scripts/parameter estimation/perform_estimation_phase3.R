#### PREAMBLE ####

    ## THIS SCRIPT CONTAINS CODE FOR:
    ## PERFORMING PARAMETER ESTIMATION FOR A 
    ## TRANSMISSION MODEL FOR AFRICAN SWINE FEVER (ASF) IN WILD BOAR
    ## ESTIMATION METHOD USED IS APPROXIMATE BAYESIAN COMPUTATION (ABC) REJECTION

    ### ASF CHALLENGE, PHASE 3 - UK TEAM  ###




#### SPECIFY PRIORS  AND TOLERANCE ####


# PRIORS
dat <- list(data.frame(p.low =  c(0.00335),
                       p.upp = c(0.00342)))



# TOLERANCE 
# Summary statistic 1: Daily number of cases 
# Summary statistic 2: Area (in km^2) of minimum convex polygon 
# Summary statistic 3: Cumulative number of cases 
    
tolerance <- data.frame(epsilon_cases = c(100),     # Threshold for summary statistic 1
                        epsilon_area = c(3500),     # Threshold for summary statistic 2
                        epsilon_cumulative = c(85)) # Threshold for summary statistic 3




### SET UP TO RUN ON MULTIPLE CORES ####



### Note: Script was run on a Windows system ###

start.time <- Sys.time()    # Record start time 
no_cores <- parallel::detectCores()    # This assumes 8 logical CPUs in total
cl <- makeCluster(no_cores)
dat <- replicate(no_cores, dat)  # Replicate, one for each core
clusterExport(cl = cl, varlist = ls())
clusterEvalQ(cl = cl,
             {
                 library(Rcpp)
             })
clusterCall(cl, worker.init)
param_estims_phase3 <- parLapply(cl = cl,
                    X= dat,
                    fun = run_ABC_rejection_phase3, 
                    N = 4)            # 4 accepted particles each on 8 cores, thus 32 particles in total
stopCluster(cl)
end.time <- Sys.time()
time.taken <- end.time - start.time  # Estimated time on Intel Core i5-8350 CPU @ 1.70 GHz with 8 GB RAM is 2 hours, 12 mins.
time.taken                           # Display total estimation time

saveRDS(param_estims_phase3, file = glue::glue(wd.output.data, "param_estims_phase3.RDS"))

# Also, save to relevant pig herd model location (as pig herd and wild boar components are run on separate systems, for efficiency)
# saveRDS(param_estims_phase3, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_Predict", "input", "param_estims_phase3.RDS")) 
# saveRDS(param_estims_phase3, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_Predict_230", "input", "param_estims_phase3.RDS")) 
# saveRDS(param_estims_phase3, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_SA", "input", "param_estims_phase3.RDS")) 
