### THIS SCRIPT CONTAINS CODE FOR ###
### MISC FUNCTIONS REQUIRED FOR COMPUTING PREDICTIONS FROM A SIR MODEL FOR WILD BOAR###
### ASF CHALLENGE PHASE 3 - UK TEAM ###



# SECTIONS IN THIS SCRIPT: #

  # 1. FUNCTIONS FOR INPUT DATA PREPARATION 
  # 2. FUNCTIONS FOR MODEL SIMULATION
  # 3. FUNCTIONS FOR PARAMETER ESTIMATION
  # 4. FUNCTIONS FOR PREDICTION
  




#### FUNCTIONS FOR INPUT DATA PREPARATION ####

# 1. Source the code in an Rmd file 

## Input:
# x: location of Rmd file 

## Output:  
# Results of running code in x

source_rmd <- function(x, ...) {
  source(knitr::purl(x, output = tempfile()), ...)
}




# 2. Simulate the appropriate number of random points 
#     for wild boar locations in each administrative region

## Inputs: 

# shp.file = shape file of island
# hunt.bag = full hunting bag data frame (from previous chunk)

## Output:

# A list with 25 elements, with each element corresponding to one of the 25 regions
# Each element contains 'x' spatial points, i.e. XY coordinates, where 'x' is the number of
# simulated boar locations.



simulate.boar.locations <- function(shp.file = merry_shp, hunt.bag = hunting_bag){
  
  rand_coords <- list()    # Create list to store output
  
  for(i in 1:nrow(hunt.bag)){
    # 
    if(i==8 | i==20 ){ # define separately: duplicate polygons for 10th and 24th ADm region
      j <- which(as.integer(shp.file@data$ID) == hunt.bag$ADM[i])
      a <- shp.file@polygons[[j]]
      a@Polygons <- a@Polygons[1]
      rand_coords_tmp <- sp::spsample(a,  n = hunt.bag$number.to.simulate[i], "random") # Sample points randomly
      rand_coords[[i]] <- rand_coords_tmp
    }else{
      j <- which(as.integer(shp.file@data$ID) == hunt.bag$ADM[i]) # Obtain index of ADM region as in shape file
      rand_coords_tmp <- sp::spsample(shp.file@polygons[[j]],  n = hunt.bag$number.to.simulate[i], "random") # Sample points randomly
      rand_coords[[i]] <- rand_coords_tmp
      
    }
    
  } 
  return(rand_coords)
  
}













#### FUNCTIONS FOR MODEL SIMULATION ####

# 1. (If running model on multiple cores) Source Cpp functions for all cores 

worker.init <- function(){
  Rcpp::sourceCpp("./scripts/functions/rpoisC.cpp") # See rpoisC.cpp for details
}
worker.init()



# 2. Function to select which sounder populations will be decreased (through hunting). Used in function #3. 

## Inputs: 

## m: vector containing number of wild boar in each patch located within fence
## size: number of wild boar to be hunted each day within fence 

sampler = function(m, size){
  d = unlist(lapply(1:length(m), function(x) rep(x, m[x])))
  s = sample(d, size = size, replace = FALSE)
  return(s)
}


# 3. Function to simulate hunting (to decrease boar numbers within fence)

## Inputs: 

## x: number of wild boar in each patch located in fence
## total: number of wild boar hunted each day within fence 

update.boar.numbers <- function(x, total){
  s <- sampler(m = x, size = total)
  x[as.numeric(levels(factor(s)))] <- x[as.numeric(levels(factor(s)))] - table(factor(s))
  return(x)
}








#### FUNCTIONS FOR PARAMETER ESTIMATION #### 


# 1.  Function for computing the minimum convex polygon (MCP) of a set of points

 ## Inputs:
  # x: coord: coordinates of points within the MCP

## Output: 
# Area of MCP

mcp.area <- function(coord){
  x <- coord$X
  y <- coord$Y
  grDevices::chull(x,y)->i  # Identify MCP vertices 
  return(splancs::areapl(cbind(x[i],y[i]))/1000000)
}


# 2. Calculate distance between observations and model simulations.
# 
# Calculate distance based on:
# Daily number of detected cases in wild boar
# Area of minimum convex polygon (MCP) enclosing infected patches
# Maximum number of detected cases

## Inputs: 
# res: model output
# start: Model simulations begin at day 'start'. 
# end:  Model simulations are until day 'end'. 

## Output: 
# Vector of distances between model output, 'res', and observations

calc_distance <- function(res, start = 60, end = 110){
  
  # Compute distance based on daily number of cases in wild boar #
  
  times.model <- res$summarized.res$day              # event times in model
  detected.cases.model <- res$summarized.res[res$summarized.res$day %in% times.model, "new.cases.wb"]$new.cases.wb # daily number of detected cases in model
  times.observed <- observed.positive$day[start:end]           # observed event times
  detected.cases.observed <- observed.positive$count[start:end] # daily number of detected cases (observed)
  
  # Compute Euclidean distance between the daily number of detected cases in the model vs the corresponding quantity in the observed. Times may not have regular intervals in simulations hence the specification of time values.
  dist1 <- sqrt(sum((detected.cases.model -detected.cases.observed[which(!is.na(match(times.observed, times.model)))])^2)) 
  
  # Compute distance based on area of MCP #
  
  # MCP from model simulations
  mcp.model <- sapply(coordinates.from.status.matrices(res$status.matrices), mcp.area)
  # MCP from data
  mcp.data <- sapply(observed.positive.locations, function(x){if (nrow(x)<3){x <- 0}else{x <- mcp.area(x)}})
  # Distance 
  dist2 <- sqrt(sum((mcp.model - mcp.data[which(!is.na(match(times.observed, times.model)))])^2)) # Calculate Euclidean distance between model and observed. 
  
  # Compute distance based on total number of cases #
  
  dist3 <- abs(sum(detected.cases.observed)- sum(detected.cases.model))
  
  c(dist1, dist2, dist3)
}



# 3. Run ABC rejection algorithm. 
  # NOTE: this function has been set up such that the estimation runs on multiple cores

## Inputs: 
# vals: list of priors
# N: Number of accepted particles per core. 
# tolerance: vector of threshold values for each summary statistic
# verbose: logical; verbose? If TRUE, output of model simulations are printed.

## Output: 
# List with the following elements: 
  # estims: Data frame of N accepted particles (parameter values).
  # status.matrices: List of length N. Each list element is a list with the daily infection indicator matrices 
  #                  corresponding to the accepted simulation. 
  # series: List of length N. Each list element is a data frame containing the daily and cumulative counts of detected boar 
  #         as predicted by the corresponding accepted simulation. 
  # locations: List of length N. Each list element is a data frame containing infection information for all boar in the landscape,
  #            as predicted by the corresponding accepted simulation.
#             


run_ABC_rejection_phase3 <- function(vals, N = 2, tol = tolerance, G = 1, verbose.resp = T){
  
  status.matrices <- list()      # List for storing daily infection status matrices for accepted simulations
  time.series <- list()          # List for storing infection status matrix for accepted simulations
  locations.res<- list()         # List for storing information infection on all boar, as predicted by accepted simulations
  estims <- matrix(ncol=1, nrow = N) # List for storing accepted particles
  results <- list()              # Save all results
  
  
  p.low <- vals[, "p.low"]
  p.upp <-  vals[, "p.upp"]
  
  
  for(g in 1:G){
    #Initiate counter
    i<-1
    while(i <= N){ # While the number of accepted particles is less than N_particles
      beta_star <- runif(1,min=p.low[1], max=p.upp[1]) # Randomly select a value in the prior interval
      m <- 0
      # Run the model using the sampled parameter value
      D_star<-model_phase3(beta = beta_star, alpha = 1000, timings = 60, timings.max = 110, verbose = T, max.infection.range = 8) 
      calc.dist <-calc_distance(D_star) # Compute distance 
      if(calc.dist[1] <= tol$epsilon_cases[g] & calc.dist[2] <= tol$epsilon_area[g] & calc.dist[3] <= tol$epsilon_cumulative[g])
      { # If distance is less than their tolerances, accept!
        m<-m+1
      }
      if (m>0){ # If particle is accepted, save model output
        # Store results
        estims[i,] <- beta_star
        status.matrices[[i]]<- D_star$status.matrices                      # save the infection status matrices
        time.series[[i]] <- D_star$summarized.res
        locations.res[[i]] <-  D_star$locations
        # Update counter
        i <- i+1
        print(paste0("Particle: ", i)) # Show estimation progress
      }
    }
    results[[g]] <- list(estims = estims, mat = status.matrices, series = time.series, locations = locations.res)
  }
  return(results)
}








#### FUNCTIONS FOR PREDICTION ####


# 1. Perform component-wise addition of matrices in a list

  ## Input:
  ## x: list with matrix components. 
  
  ## Output:
  ## Sum of matrices
add.matrices <- function(x){Reduce ("+", x)}



# 2. Given N infection indicator matrices, 
#    obtain a combined infection indicator matrix
#    (as a majority vote count of the N matrices)
#    
#    This function combines the infection status predictions from all accepted simulations, 
#    computes the probability of infection for each patch at the final day and 
#    using a threshold, computes a new indicator matrix. 


  ## Input:
  # X: list of lists. X has N components, where N = number of parameter sets (each parameter set yields a set of status matrices, one for each day). 
  #    Each of the N components is a list of T components, where T = number of days considered in the model.
  # from.day: first day considered in the model
  # to.day: last day considered in the model
  # threshold.prob: If the probability for a patch is greater than threshold.prob, 
  #                  we consider the patch to be infected. Defaults to 0.05. 
  #                  In prediction, the value of threshold.prob is chosen to minimize the difference 
  #                  between the average prevalence among patches, computed using accepted simulations, 
  #                  and the prevalence computed from the combined matrix. 
  
  ## Output:
  # List of length N with elements:
  # prob = Combined matrix of infection probabilities for each patch
  # indicator = Infection indicator matrix computed from prob and threshold.prob. 
  #             The (i,j)th entry of 'indicator' is 1 is the corresponding entry of 
  #             'prob' is less than or equal to threshold.prob; the entry is 0 otherwise.

add.matrices.day <- function(X, from.day = 1, to.day = 50, threshold.prob = 0.05){
  
  list.prob <- list()        # List to save probabilities
  list.indicator <- list()  #  List to save infection status
  
  days.seq <- from.day:to.day
  for(t in 1:length(days.seq)){ # Compute probabilities
    day_t_mat <- matrix(0, nrow = nrow(patchcentres), ncol = nrow(patchcentres))
    for(i in 1:length(X)){
      day_t_mat <- add.matrices(list(day_t_mat,X[[i]][[t]])) # Add matrices by day
    }
    list.prob[[t]] <- day_t_mat/length(X)   # Divide sums by the number of matrices added to obtain probabilities
  }                                         # 'list.prob' is a list with length(X) components, each component containing the probability status matrix for a particular day.
  
  # Implement threshold
  list.indicator <- lapply(list.prob, function(A){ifelse(A>threshold.prob, TRUE, FALSE)})
  
  list(prob = list.prob, indicator = list.indicator)
}



# 3. Obtain coordinates of infected patches given infection indicator matrix 

  ## Inputs: 
  # X = an infection indicator matrix
  
  ## Output:
  # Data frame of XY coordinates of infected patches

get.coordinates.from.single.matrix <- function(X){
  coordIndices <- as.data.frame(which(X == TRUE, arr.ind = TRUE))                             # Matrix indices for infected patches
  data.frame(X = patchcentres$X[coordIndices$col], Y = patchcentres$Y[coordIndices$row])   # Coordinates of infected patches
}



# 4. For each accepted simulation, compute the number of final infected patches

  ## Inputs:
  # dat: List of length N, where N is the number of accepted simulations. 
  #      Each element of the list is a list of length equal to the number of days 
  #      over which estimation was performed.
  
  ## Output:
  # Vector of length N; each element of the vector is the number of final infected patches
  # as predicted by an accepted simulation.

number.final.infected.patches <- function(dat){
  # Prediction length 
  prediction.length = length(dat[[1]]) # Obtain number of days over which estimation was performed
  num.final <- c() # Vector to store number of final infected patches 
  for (i in 1:length(dat)){
    num.final[i] <- sum(dat[[i]][[prediction.length]]) # Compute number of final infected patches for each accepted simulation
  }
  num.final
}



# 5.Extract cumulative and daily cases for accepted simulations from list

## Inputs:
# res.list: List of length N, where N is the number of accepted simulations. 
#      Each element of the list is a data frame and corresponds to the model output at a given simulation
# The data frame has columns: 
# day:                 Days for which simulation was performed
# new.cases.wb:        Number of detected infected boar on 'day'
# cumulative.cases.wb: Cumulative number of detected infected boar by 'day'


## Output:
# List with elements:
# df.cum.cases: matrix with each column corresponding to the cumulative number of detected cases (in boar) from a single simulation.
#               Each row corresponds to a day
# df.dly.cases: matrix with each column corresponding to the daily number of detected cases (in boar) from a single simulation.
#               Each row corresponds to a day
# 
extract.cases <- function(res.list, from.day = 1, to.day = 80){
  
  # Create empty data frame for saving case counts
  # Cumulative
  df.cum.cases <- matrix(NA, nrow = (to.day - from.day) + 1, ncol = length(res.list))
  # Counts
  df.dly.cases <- matrix(NA, nrow = (to.day - from.day) + 1, ncol = length(res.list))
  
  # Arrange into data frames
  for(i in 1:length(res.list)){
    df.cum.cases[,i] <- res.list[[i]]$cumulative.cases.wb[1:((to.day - from.day) + 1)]
    df.dly.cases[,i] <- res.list[[i]]$new.cases.wb[1:((to.day - from.day) + 1)]
  }
  
  return(list(df.cum.cases = df.cum.cases,
              df.dly.cases = df.dly.cases))
  
}








