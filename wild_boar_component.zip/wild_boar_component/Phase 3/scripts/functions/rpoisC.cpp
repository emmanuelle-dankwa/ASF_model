#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
// Function for Poisson simulation in model 


NumericVector simulC(NumericVector lambda){
  int n = lambda.size();
  NumericVector out(n);
  for(int i = 0; i < n; ++i) {
    out[i] = R::rpois(lambda[i]);
  }
  return out;
}

//
/*** R
# Function to identify boar given a set of conditions
id = function(inf.patch, dfboar, marker){
  which(dfboar$patch==inf.patch & dfboar$infectionStatus==marker)
}
*/


// [[Rcpp::export]]
// Function for computing number of boar in each state: susceptible or infected
NumericVector numbboarstateC(NumericVector LinIdx_I, DataFrame updatedboar, Function fn, int marker) {
  int n = LinIdx_I.size();
  NumericVector numbboar(n);
  NumericVector status(n);
  for(int i = 0; i < n; ++i) {
    status = fn(Named("inf.patch") = LinIdx_I[i], Named("dfboar") = updatedboar, Named("marker") = marker);
    numbboar[i] = status.size();
  }
  return numbboar;
}

