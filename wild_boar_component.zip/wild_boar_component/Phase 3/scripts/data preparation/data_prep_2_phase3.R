### THIS SCRIPT CONTAINS CODE FOR 
## DATA PREPARATION FOR A TRANSMISSION MODEL FOR WILD BOAR ####

### ASF CHALLENGE PHASE 3 - UK TEAM ###


## SCRIPT SECTIONS:

# 1. SET UP
# 2. SELECT INITIAL AREA OF FOCUS
# 3. SPECIFY NUMBER OF PATCHES & PATCH BOUNDARIES 
# 4. COMPUTE DIMENSIONS OF AREA OF FOCUS    
# 5. INTERVENTIONS - FENCE 
# 6. DETERMINE COORDINATES OF ALL PATCHES AND ADMINISTRATIVE REGION TO WHICH THEY BELONG 
# 7. DETERMINE THE POPULATION SIZE OF EACH PATCH & THE PATCH TO WHICH EACH BOAR BELONGS
# 8. SEED INFECTIONS AT DAY 60 
# 9. DETERMINE THE INFECTION STATUS OF PATCHES  BASED ON THE INFECTION STATUS OF BOAR  
# 10. COMPUTE  OBSERVED INFECTIONS AND DETERMINE LOCATIONS 
# 11. REMOVALS OF WILD BOAR BY HUNTING OR SEARCH 
# 12. SAVE OUTPUT DATA



##################################################################
##                            SET UP                            ##
##################################################################

## Load additional required library ##

devtools::install_github("kylebittinger/usedist")
library(usedist)     


## Import data ##

dataFile <- read.csv(file = glue(wd.output.data, "other/merged_expected_wild_boar_phase3.csv"), header = T, sep = ",")  # Load observed and simulated boar locations
sizeData <- dim(dataFile)                                     # 482248 (by day 0 = day 36 of hunting season; see "data-prep-1-phase3.Rmd"); must be equal to sum(hunting_bag$expected.remaining)
dataFile$status[which(is.na(dataFile$status))] <- "Unknown"   # Replace all NA statuses to unknown


## Setting up required variables.... ##

nBoar <- sizeData[1]
locations <- dataFile[, -7]                                             # matrix for storing WB locations, date of suspicion, mode of detection and whether the data point is observed or simulated.
locations$infectionStatus <- numeric(nBoar)                             # Vector for storing infection status of boar, as determined by the model. First few infections are based on observed data. 
locations$infectionStatus[dataFile$status=="Positive"] <- 1             # At infected WB locations, assign '1' 
names(locations)[which(names(locations) == "date")] <- "date.removed"   # Rename "date" column to "date.removed". Hunted or detected wild boar (by passive surveillance or active search) are immediately removed once hunted or detected. 











##################################################################
##                  SELECT INITIAL AREA OF FOCUS               ##
##################################################################

# First, restrict attention to only central part of map (the part near infected wild boar),
# to make infection pressure calculations quicker (because fewer susceptible boar)


 minx = 7.25*(10^5)
 maxx = 8.5*(10^5)
 miny = 6.3*(10^6)
 maxy = 6.45*(10^6)


 
 ### DROP BOARS OUTSIDE DEFINED BOUNDARIES ###
 
 whichToDelete <- which(locations$X < minx 
                        | locations$X > maxx 
                        | locations$Y < miny 
                        | locations$Y > maxy)          # identify WB locations 'far' from initial (detected) infected area
 locations <- locations[-whichToDelete, ]              # Exclude these from WB location and infection matrices
 
 
 nBoar <- nrow(locations)                              # Update wild boar locations 
 
 
 
 
 ##################################################################
 ##        SPECIFY NUMBER OF PATCHES & PATCH BOUNDARIES         ##
 ##################################################################
 
 # Specify number of patches and patch boundaries
 
 npatches_x <- 50                                               # this is number of patches in x-direction
 npatches_y <- 50                                               # this is number of patches in y-direction
 patchboundaries_x <- seq(minx, maxx, by=(maxx - minx)/npatches_x)
 patchboundaries_y <- seq(miny,  maxy, by= (maxy - miny)/npatches_y)
 
 
 # Compute patch centers in x and y directions. 
 
 patchcentres_x <- numeric(length(patchboundaries_x) - 1)             # vector to store x coordinates of patch centers
 patchcentres_y <- numeric(length(patchboundaries_y) - 1)             # vector to store y coordinates of patch centers
 
 for(i in 1:(length(patchboundaries_y) - 1)){
   patchcentres_y[i] = (patchboundaries_y[i] + patchboundaries_y[i + 1])/2
   patchcentres_x[i] <- (patchboundaries_x[i] + patchboundaries_x[i + 1])/2
 }
 
 patchcentres <- data.frame(X = patchcentres_x, Y= patchcentres_y)
 nrow(patchcentres)
 
 
 # Determine coordinates of ALL patches (npatches_x * n_patches_y in number)
 
 all.patch.centres <- tidyr::crossing(X = patchcentres$X, Y = patchcentres$Y) 
 
 # dist(all.patch.centres[1:2,]) # 3km          # This gives the length in the Y direction only as the X dimension is constant
 # dist(all.patch.centres[c(1,51),]) # 2.5 km  # This gives the length in the X direction only as the Y dimension is constant
 # 
 
 
 
 
 ##################################################################
 ##               COMPUTE DIMENSIONS OF AREA OF FOCUS            ##
 ##################################################################
 
 # UNCOMMENT CODE BELOW TO COMPUTE DIMENSIONS OF MARKED OUT AREA #
 
# ### TOTAL AREA & PERIMETER ###
#  
#  ## Total area ##
#  # Method 1  (Use formula for area of a rectangle)
#  section.area <- ((maxx- minx)*(maxy-miny))/1000000  # divide by 1000000 for km2
#  
#  # Method 2 (Use pracma package)
#  area.of.section <-  pracma::polyarea(x = c(minx, maxx, maxx, minx), y = c(miny, miny, maxy, maxy))/1000000 # in km^2
#  
#  ## Check that 
#  section.area == area.of.section
#  
#  
#  ## Total perimeter ##
#  # Method 1 (Use formula)
#  section.perimeter <- 2*((maxx-minx)+ (maxy-miny))/1000
#  
#  
#  # Method 2 (Use package)
#  perimeter.of.section <- spatstat::perimeter(as.owin(W = c(xmin = minx , xmax = maxx, ymin = miny,  ymax = maxy)))/1000 # in km
#  
#  ## Check that 
#  section.perimeter == perimeter.of.section
#  
#  
# # View
# section.area;section.perimeter
#  
#  
#  
#  ### PATCH AREA & PERIMETER ###
#  
#  
#  ## Patch area ##
#  #  Method 1 (Use formula)
#  dist.in.x.direction <- (patchcentres$X[2] - patchcentres$X[1])
#  dist.in.y.direction <- (patchcentres$Y[2] - patchcentres$Y[1])
#  patch.area <- (dist.in.x.direction*dist.in.y.direction)/1000000   # in km^2
#  
#  # Method 2 (Divide total area by number of patches)
#  area.of.patch = area.of.section/(npatches_x*npatches_y)
#  
#  ## Check that
#  patch.area == area.of.patch
#  
#  
#  ## Patch perimeter ## 
#  # Method 1 (Use formula)
#  patch.perimeter <- 2*((patchcentres$X[2]-patchcentres$X[1]) + (patchcentres$Y[2] - patchcentres$Y[1])) /1000 # in km
#  
#  # Method 2 (Use package)
#  perimeter.of.patch <- spatstat::perimeter(as.owin(W = c(xmin =patchcentres$X[1]  , xmax =patchcentres$X[2] , ymin = patchcentres$Y[1] ,  ymax = patchcentres$Y[2] )))/1000 # in km 
#  
#  ## Check that 
#  patch.perimeter == perimeter.of.patch
#  
#  
#  # View
#  
#  patch.area; patch.perimeter
#  
#  # Print results
#  cat("Section area:", section.area, "km2",  "\n", 
#      "Section perimeter:", section.perimeter, "km", "\n",
#      "\n",
#      "Number of patches:", npatches_x*npatches_y, "\n",
#      "\n",
#      "Area per patch:", patch.area, "km2", "\n",
#      "Perimeter per patch:", patch.perimeter, "km", "\n",
#      "\n",
#      "Length in x-direction (section):",(maxx - minx)/1000, "km", "\n",
#      "Length in y-direction (section):",(maxy - miny)/1000, "km", "\n", 
#      "\n",
#      "Length in x-direction (patch):",(patchcentres$X[2]-patchcentres$X[1])/1000, "km", "\n",
#      "Length in y-direction (patch):",(patchcentres$Y[2]-patchcentres$Y[1])/1000, "km", "\n"
#       )
#  
#  






 
 
 
 
 
 
 
 ##################################################################
 ##                  INTERVENTIONS - FENCE                      ##
 ##################################################################
 
 # Determine patches that fall within fence (for reference for coordinates, see Phase 1 update document from Island officials)
 
 A <- c(773676.4, 6347189)
 B <- c(833676.4, 6347189)
 C <- c(833676.4, 6437189)
 D <- c(773676.4, 6437189)
 
 fence.coordinates <- data.frame(id = LETTERS[1:4], 
                                 X = c(A[1], B[1], C[1], D[1]),
                                 Y = c(A[2], B[2], C[2], D[2]))
 
 
 # Update fenced area to include 15 km buffer
 
 buffer.width <- 15000    # in meters
 
 A1 <- c(773676.4-buffer.width, 6347189-buffer.width)
 B1 <- c(833676.4+buffer.width, 6347189-buffer.width)
 C1 <- c(833676.4+buffer.width, 6437189+buffer.width)
 D1 <- c(773676.4-buffer.width, 6437189+buffer.width)
 
 
 zone.coordinates <- data.frame(id = LETTERS[1:4], 
                                X = c(A1[1], B1[1], C1[1], D1[1]),
                                Y = c(A1[2], B1[2], C1[2], D1[2]))
 
 
 
 ## CHECKS ##
 
 # plot(zone.coordinates$X, zone.coordinates$Y)
 # points(fence.coordinates$X, fence.coordinates$Y, col = "red")

 # fence.area <- pracma::polyarea(fence.coordinates$X, fence.coordinates$Y) # 5400km^2
 # buffer.fence.area <- pracma::polyarea(zone.coordinates$X, zone.coordinates$Y) # 10800 km^2
 #
 # # Perimeters
 #
 # ## fence.area
 # spatstat::perimeter(as.owin(W = c(xmin = A[1] , xmax = B[1], ymin = A[2],  ymax = C[2]))) # 3e+05 m = 300 km
 #
 # ## buffer.fence.area
 # spatstat::perimeter(as.owin(W = c(xmin = A1[1] , xmax = B1[1], ymin = A1[2],  ymax = C1[2]))) # 420km

 ###
 
 
 
 # Determine responses to "Is patch i in fence or buffer"?
 
 in.fence.buffer <- sp::point.in.polygon(point.x = all.patch.centres$X, point.y= all.patch.centres$Y,
                                         pol.x = zone.coordinates$X, pol.y = zone.coordinates$Y)
 
 in.fence.buffer.matrix <- matrix(in.fence.buffer, nrow = npatches_x, ncol = npatches_y)
 
 
 in.fence <- sp::point.in.polygon(point.x = all.patch.centres$X, point.y= all.patch.centres$Y,
                                  pol.x = fence.coordinates$X, pol.y = fence.coordinates$Y)
 
 in.fence.matrix <- matrix(in.fence, nrow = npatches_x, ncol = npatches_y)
 
 
 
 
 
 
 
#############################################################################################
##  DETERMINE COORDINATES OF ALL PATCHES AND ADMINISTRATIVE REGION TO WHICH THEY BELONG  ##
#############################################################################################

# Determine the administrative regions to which patches belong. (Patches are characterized only by the coordinates of their centers.)

merry_shp2 <- st_read(glue(wd.raw.data, "Island_ADMIN.shp"))           # Read shape file 
bps2 <- st_as_sf(all.patch.centres, coords = c("X", "Y"), 
                 crs = "+proj=lcc +lat_0=46.5 +lon_0=3 +lat_1=44 +lat_2=49 +x_0=700000 +y_0=6600000 +ellps=GRS80 +units=m +no_defs")

bps2_trans <- st_transform(bps2, crs = "+proj=lcc +lat_0=46.5 +lon_0=3 +lat_1=44 +lat_2=49 +x_0=700000 +y_0=6600000 +ellps=GRS80 +units=m +no_defs")
MS2_trans <- st_as_sf(merry_shp2)
MS2_trans <- st_transform(MS2_trans,  crs = "+proj=lcc +lat_0=46.5 +lon_0=3 +lat_1=44 +lat_2=49 +x_0=700000 +y_0=6600000 +ellps=GRS80 +units=m +no_defs")


# Join
boar_per_area <- st_join(bps2_trans, MS2_trans, join = st_intersects)

table(boar_per_area$ID)

all.patch.centres[,"region"] <- boar_per_area$ID

table(all.patch.centres$region)


### Sort out NA regions ###

## There are some patches that are not assigned a region because these fall outside the island borders
no_region <- all.patch.centres[which(is.na(all.patch.centres$region)),] # There are 91 == nrow(no_region) of those.

## Make a coordinate object from these data
coord_no_region_df <- no_region[,c("X","Y")]

## Make into a spatialpointsdataframe with crs matching the above

no_region_spdf <- SpatialPointsDataFrame(coords = coord_no_region_df, data = no_region,
                                         proj4string = CRS("+proj=lcc +lat_0=46.5 +lon_0=3 +lat_1=44 +lat_2=49 +x_0=700000 +y_0=6600000 +ellps=GRS80 +units=m +no_defs"))

no_region <- data.frame(X = no_region_spdf$X, Y = no_region_spdf$Y)


###CHECKS ###
## Determine number of wild boar in unassigned regions ##

# nboar <- c()
# for(i in 1:nrow(no_region)){
# 
#   x_ind <-  which(patchcentres$X==no_region$X[i])
#   y_ind <- which(patchcentres$Y==no_region$Y[i])
# 
#   nboar[i] <- nBoarsMatrix[x_ind, y_ind]
# 
# }

####

## Assign the boar to the nearest polygon 

n <- length(no_region_spdf)
nearestpolygon <- character(n)
distToNearestpolygon <- numeric(n)


for (i in seq_along(nearestpolygon)) {
  gDists <- gDistance(no_region_spdf[i,], merry_shp, byid=TRUE)
  nearestpolygon[i] <- merry_shp$ID[which.min(gDists)]
  distToNearestpolygon[i] <- min(gDists)
}


## Assign these to the table

no_region$region <- nearestpolygon


## Now add to the original data; patch centres with administrative regions

all.patch.centres <- left_join(all.patch.centres, no_region, by = c( "X", "Y"))%>% 
      mutate(region=coalesce(region.x, region.y)) %>%
      dplyr::select(-region.x, -region.y)


# Check that there are no NA values
sum(is.na(all.patch.centres$region))==0 # should be TRUE
table(all.patch.centres$region)         # all patches

all.patch.centres$number.of.boar <- numeric(nrow(all.patch.centres))
all.patch.centres$patch.id <- 1:2500




########################################################################################
## DETERMINE THE POPULATION SIZE OF EACH PATCH & THE PATCH TO WHICH EACH BOAR BELONGS ##
#######################################################################################


# Compute number of wild boar in each patch 
# Determine the patch of each wild boar in locations matrix

nBoarsMatrix <- matrix(0, nrow=npatches_x, ncol=npatches_y)          # Allocate matrix for number of boars in each patch
infectionStatusMatrix <- matrix(0, nrow=npatches_x, ncol=npatches_y) # Allocate matrix for infection status

locations$patch <- rep(0, nBoar)                                     # Column for storing the patch number for each boar
locations$region_patch <- rep(0, nBoar)                              # Column for storing the region ID for each boar
locations$index <- 1:nrow(locations)                                 # Assign indices to boar
locations$date.infected <- rep(0, nrow(locations))                   # Column for storing date of infection
locations$date.start.infectious <- rep(0, nrow(locations))           # Column for storing infection start date
locations$carcass <- rep(0, nrow(locations))                         # Column for storing carcass status 
locations$date.death.recovery <- rep(0, nrow(locations))             # Column for storing death dates
locations$date.end.infectious <- rep(0, nrow(locations))             #  Column for storing date of end of infectiousness
locations$date.removed2 <- 0                                         # Column to record removal date by model 




for (i in 1:(length(patchboundaries_x) - 1)){
  for(j in 1:(length(patchboundaries_y) -1)){
    whichOnes <- which((locations$X >= patchboundaries_x[i]) & (locations$X < patchboundaries_x[i+1]) &  # capture indices of wild boar locations in each patch
                         (locations$Y >= patchboundaries_y[j]) & (locations$Y < patchboundaries_y[j+1]))
    # Identify patch to which each boar belongs
    
    patch.number <- which(all.patch.centres$X==patchcentres_x[i] & all.patch.centres$Y==patchcentres_y[j])
    
    # Assign patch.number and region to rows corresponding to wild boar locations which fall within the patch
    
    locations[whichOnes, "patch"] <- patch.number                                              # Assign patch number 
    locations[whichOnes, "region_patch"] <- all.patch.centres[patch.number, "region"]$region   # Region based on patch number
    all.patch.centres[which(all.patch.centres$X==patchcentres$X[i] & all.patch.centres$Y ==patchcentres$Y[j]), "number.of.boar"] <- length(whichOnes) # Determine the number of boar in each patch
    
    # Count the number of boars in patch
    nBoarsMatrix[patch.number] <- length(whichOnes)                                            # Save number of wild boars in patch
    
  }
}




#############################################################################
##                       SEED INFECTIONS AT DAY 60                       ##
#############################################################################



####
## ASSIGN INFECTION STATUS TO UNOBSERVED REMOVALS ##
####



#### POSITIVE ###

# Assign positive status to x simulated boar locations, where x is the number of unobserved positive boar removed by day 59, computed as x = 4 * (number of observed positive boar hunted from day 1 to 59), as only 20% of i
a <- locations[(locations$date.removed<=59 & locations$status=="Positive" & locations$det == "PT"),  ]  
set.to.positive <- sample(x = which(is.na(locations$det) & locations$patch %in% unique(a$patch)), size = 4*nrow(a), replace = F) # Unobserved infected boar should be in the same or neighbouring patches 
locations[set.to.positive, "infectionStatus"] <- 1                                                                              # Set infection status to 1 
locations[set.to.positive, "date.removed"] <- sample(x = rep(a$date.removed,4), size = length(set.to.positive), replace = F)    # Assign date as observed 


# Check
# nrow(locations[which(locations$date.removed <= 59 & locations$infectionStatus==1), ]) == sum(nrow(a)*5, nrow(locations[(locations$date.removed<=59 & locations$status=="Positive" & locations$det %in% c("AS", "PS")),  ] ))




#### NEGATIVE ###

## Select remaining 80% of negative hunted boar that were not reported ##

b <- locations[which(locations$date.removed<=59 & locations$status=="Negative" & locations$det == "NT"),  ]
set.to.negative <- sample(x = which(is.na(locations$det) & locations$patch %in% unique(b$patch) & locations$infectionStatus !=1), size = 4*nrow(b), replace = F) # Unobserved infected boar should be in the same or neighbouring patches 
locations[set.to.negative, "date.removed"] <- sample(x = rep(b$date.removed,4), size = length(set.to.negative), replace = F)  # Assign date as observed 

# Check that 
# nrow(locations[which(locations$date.removed <= 59 & locations$infectionStatus==0), ]) == sum(nrow(b)*5, nrow(locations[(locations$date.removed<=59 & locations$status=="Negative" & locations$det == "NAS"),  ]))





####
##  ESTIMATE THE PREVALENCE RATE BY DAY 59      
##  TO DETERMINE THE NUMBER OF INFECTIONS 
##  IN LANDSCAPE BY DAY 60. 
####


## Set the infection status of all boar to be caught in the future (i.e. day 60 and beyond) to 0 ##

locations[which(locations$date.removed > 59), "infectionStatus"] <- 0   

# Number of boar caught by day 59
caught.by.day.59 <- nrow(locations[which(locations$date.removed<=59), ]) # Check that this equals cumsum(removals$total.removed[1:59])[59]

# Check 
# cumsum(removals$total.removed[1:59])[59] == caught.by.day.59 

# Number of positive boar caught by day 59
positive.caught.by.day.59 <- sum(locations$infectionStatus==1)

# Positivity rate by day 59
positive.rate.by.day.59 <- positive.caught.by.day.59/caught.by.day.59
# [1] 0.095     # We conclude that approx. 10% of all boar out there and in the same patches (geographical region) as those caught are positive. Not key assumption: hunting is done randomly hence sample is a good reflection of the entire population


### Checks ##
# Number of boar that are alive by day 60
# 
# alive.by.start.day.60 <- sum(nBoarsMatrix) - caught.by.day.59
# alive.by.start.day.60 == removals$total.remaining[59] # must be TRUE






###
## USING THE ESTIMATED PREVALENCE RATE, COMPUTED THE EXPECTED NUMBER OF POSITIVE BOAR 
## REMAINING IN THE LANDSCAPE BY DAY 60 TO ESTIMATE NUMBER OF BY DAY 59   
####


# 1. First, compute the number of live boar in the same patches as caught boar

patches.to.which.caught.boar.belong <- unique(locations[which(locations$date.removed<=59), "patch"])
patches.to.which.positive.caught.boar.belong <- unique(locations[which(locations$date.removed<=59 & locations$status == "Positive"), "patch"])

# Check 

# sum(!(patches.to.which.positive.caught.boar.belong %in% patches.to.which.caught.boar.belong )) == 0  # Check that no patch is in both sets

boar.alive.in.target.patches <- locations[which((locations$date.removed > 59 | is.na(locations$date.removed)) & locations$patch %in% patches.to.which.caught.boar.belong),  ]
# nrow(boar.alive.in.target.patches)



# 2. Then, compute the number of expected positive boar remaining in the landscape 

expected.positive.boar.not.removed.by.day.60 <- round(nrow(boar.alive.in.target.patches)*positive.rate.by.day.59)






####
## DETERMINE WHICH BOAR ARE POSITIVE AT DAY 60 ##
###


# We assign positive status to N boar, where N = ='expected.positive.boar.by.day.60', computed in the previous section. 
# We prioritise boar that were found positive in data; in particular, those observed to be positive between days 60 and 73, (a 13-day interval),
# As it takes 14 days from infection to death/recovery, we expect that boar found positive within 14 days from day 60 were positive by day 60 
# (we cam assume this without factoring the 3-day delay from testing, since we use the removal date and not the confirmation date.)

observed.positive.boar.in.target.patches <- which(locations$date.removed > 59 & locations$date.removed < 74 & locations$status == "Positive" & locations$patch %in% c(unique(patches.to.which.positive.caught.boar.belong)))  # We assume that a boar testing positive between days 60 and 73 was infectious by day 60. 
unknown.status.boar.in.target.patches <-  which(is.na(locations$date.removed) & locations$patch %in% c(unique(patches.to.which.positive.caught.boar.belong)))

# Choose which simulated boar will be assigned positive status 

assign.positive.unknown.status <- sample(x = unknown.status.boar.in.target.patches,
                                         size = expected.positive.boar.not.removed.by.day.60 - length(observed.positive.boar.in.target.patches))

# Assign positive to observed positives and unknown positives 
locations[observed.positive.boar.in.target.patches, "infectionStatus"] <- 1
locations[assign.positive.unknown.status, "infectionStatus"]<- 1

# Check 
# sum(locations[which(locations$date.removed > 59 | is.na(locations$date.removed)), ]$infectionStatus) == expected.positive.boar.not.removed.by.day.60






###
##   EXCLUDE BOAR REMOVED ON OR BEFORE DAY 59  ##
####


# Now that positivity has been assigned, remove all boar with removal date of of day 59 or less 

# Before that, save!
locations.full <- locations                                          # All boar 
locations.day.59 <- locations[which(locations$date.removed <= 59), ] # Boar removed on or before day 59 


# Remove all boar removed by day 59

locations <- locations[-which(locations$date.removed <= 59), ]


# Check:  that we still have the number of positive infections we expect

# sum(locations$infectionStatus) == expected.positive.boar.not.removed.by.day.60




####
##   DETERMINE WHICH BOAR ARE CARCASSES BY DAY 60  ##
####

# Seed some carcasses 

locations$carcass[locations$date.removed > 59 & locations$date.removed < 73 & locations$det %in% c("AS", "PS") & locations$infectionStatus==1] <- 1 # Our assumption is that if a boar was found (by AS or PS) as a positive carcass between days 60 and days 65, 
                                                                                                                                                    # then it was a positive carcass by day 60.







####
##  ASSIGN TRANTION DATES TO ALL BOAR ##
####


# Assign dates to carcasses #

# Carcass infection date 

locations$date.infected[locations$carcass==1] <- sample(x = c(1:(60-14)), size = length(which(locations$carcass==1)), replace = T) # In keeping with the epidemiology of ASF,  
                                                                                                                                  # we assume that boar that are carcasses by day 60 were infected at least 14 days before day 60. 
                                                                                                                                  # Our model assumes that all found carcasses are infected; in the data, only 20 carcasses were negative. 
                                                                                                                                                                                                                                                                      
# Carcass date.death

locations$date.death.recovery[locations$carcass==1] <- locations$date.infected[locations$carcass==1] + 14 # Death date set to match ASF epidemiology

# End of infectiousness date

locations$date.end.infectious[locations$carcass==1] <- locations$date.infected[locations$carcass==1] + 104 # End of infectiousness set to match ASF epidemiology




# Assign dates to live boar #

# Infection date
locations$date.infected[locations$infectionStatus==1 & locations$carcass == 0] <- sample(x = c((60-13): (60-5)), size = length(which(locations$infectionStatus==1 & locations$carcass == 0)), replace = T) # Day 13, the day before death or recovery; day 5 the day when infectiousness starts



# Death date

locations$date.death.recovery[locations$infectionStatus==1 & locations$carcass == 0] <- locations$date.infected[locations$infectionStatus==1 & locations$carcass == 0] + 14   # Death date set to match ASF epidemiology



# End of infectiousness date

locations$date.end.infectious[locations$infectionStatus==1 & locations$carcass == 0] <- locations$date.infected[locations$infectionStatus==1 & locations$carcass == 0] + 104  # Date of end of infectiousness set to match ASF epidemiology





# ## Assign dates to caught boar before day 59: ***OPTIONAL, NOT USED DIRECTLY IN MODEL*** ##
# 
# # Determine which ones are carcasses
# 
# locations.day.59$carcass[locations.day.59$infectionStatus==1 & locations.day.59$det %in% c("AS", "PS")] <- 1 
# 
# 
# # Not carcasses
# 
# # Infection date
# 
# locations.day.59$date.infected[locations.day.59$infectionStatus==1 & locations.day.59$carcass == 0] <- locations.day.59$date.removed[locations.day.59$infectionStatus==1 & locations.day.59$carcass == 0] - 13
# 
# 
# # Death date 
# 
# 
# locations.day.59$date.death.recovery[locations.day.59$infectionStatus==1 & locations.day.59$carcass == 0] <- locations.day.59$date.removed[locations.day.59$infectionStatus==1 & locations.day.59$carcass == 0]
# 
# 
# # End of infectiousness date (should they have been alive)
# 
# locations.day.59$date.end.infectious[locations.day.59$infectionStatus==1 & locations.day.59$carcass == 0] <- locations.day.59$date.infected[locations.day.59$infectionStatus==1 & locations.day.59$carcass == 0] + 104
# 
# 
# 
# # Carcasses
# 
# # Infection date
# 
# locations.day.59$date.infected[locations.day.59$infectionStatus==1 & locations.day.59$carcass == 1] <- locations.day.59$date.removed[locations.day.59$infectionStatus==1 & locations.day.59$carcass == 1] - (14 + 3) # Assuming that carcasses are found 3 days after death
# 
# 
# # Death date 
# 
# 
# locations.day.59$date.death.recovery[locations.day.59$infectionStatus==1 & locations.day.59$carcass == 1] <- locations.day.59$date.removed[locations.day.59$infectionStatus==1 & locations.day.59$carcass == 1] - 3 # Assuming that carcasses are found 3 days after death
# 
# 
# # End of infectiousness date (should they have been alive)
# 
# locations.day.59$date.end.infectious[locations.day.59$infectionStatus==1 & locations.day.59$carcass == 1] <- locations.day.59$date.infected[locations.day.59$infectionStatus==1 & locations.day.59$carcass == 1] + 104
# 
 







######################################################################################################
##          DETERMINE THE INFECTION STATUS OF PATCHES  BASED ON THE INFECTION STATUS OF BOAR        ##
######################################################################################################


##  Determine infection status of patch (by day 59) ##
infectionStatusMatrix <- matrix(0, nrow=npatches_x, ncol=npatches_y) # Allocate matrix for infectious status

for (i in 1:(length(patchboundaries_x) - 1)){
  for(j in 1:(length(patchboundaries_y) -1)){
    whichOnes <- which((locations$X >= patchboundaries_x[i]) & (locations$X < patchboundaries_x[i+1]) &  # capture indices of wild boar locations in each patch
                         (locations$Y >= patchboundaries_y[j]) & (locations$Y < patchboundaries_y[j+1]))
    
    patch.number <- which(all.patch.centres$X==patchcentres_x[i] & all.patch.centres$Y==patchcentres_y[j])     # Identify patch to which each boar belongs
    
    if(length(which(locations$infectionStatus[whichOnes] == 1)) > 0){                 # Change to infectious status     # Determine state of infection of WB in the patch
      infectionStatusMatrix[patch.number] <- 1                                        # Entire patch is infectious if at least one wild boar in the patch is
    }
    
  }}









##################################################################
##     COMPUTE  OBSERVED INFECTIONS AND DETERMINE LOCATIONS     ##
##################################################################

# Organize daily counts of observed positive/negative wild boar:


daily.counts <- table(dataFile$date, dataFile$status) # No counts for 'Unknown' category because no dates provided 
observed.negative <- data.frame("day" = c(1:nrow(daily.counts)), "count" = daily.counts[,1])  # negative counts
observed.positive <- data.frame("day" = c(1:nrow(daily.counts)), "count" = daily.counts[,2])  # positive counts

# Check that 

sum(observed.positive$count) == sum(397, 1610, 977) # must be TRUE. 397 from days 1-50; 
                                                    # 1610 new wild boar from days 51-80; 
                                                    # 977 from days 81 to 110. 
                                                    # Total 2984 by day 110; see Update files from organizers
                                                    # (number of positive detected wild boar by day 110)



## Track locations of infected boar from day 60
## Compile locations into a list for each day

observed.positive.locations60 <- list()

for(i in c(60:max(dataFile$date, na.rm = TRUE))){
  j <- which(c(60:max(dataFile$date, na.rm = TRUE)) == i)
  observed.positive.locations60[[j]] <- dataFile[which(dataFile$status=="Positive" & dataFile$date==i) , c("X", "Y")]
  if(j>=2){
    observed.positive.locations60[[j]] <- rbind(observed.positive.locations60[[j-1]], observed.positive.locations60[[j]])
  }
}




## Track locations of infected boar from day 1 to day 110
## Compile locations into a list for each day

observed.positive.locations <- list()

for(i in c(1:max(dataFile$date, na.rm = TRUE))){
  j <- which(c(1:max(dataFile$date, na.rm = TRUE)) == i)
  observed.positive.locations[[j]] <- dataFile[which(dataFile$status=="Positive" & dataFile$date==i) , c("X", "Y")]
  if(j>=2){
    observed.positive.locations[[j]] <- rbind(observed.positive.locations[[j-1]], observed.positive.locations[[j]])
  }
}


##################################################################
  ##    REMOVALS OF WILD BOAR BY HUNTING OR SEARCH             ##
##################################################################



## WITHIN ZONE ##


## In this section, we compute the number of boar hunted each day within the fence-buffer (zone) 
## To do this, we use observed search and hunting data. 
## For hunting data, multiply by 5 if timings <= 59 else treat as observed (before day 60, only 20% of hunted boar are tested; 
##                                                                          thereafter, all boar found/removed in the zone were tested)



## Hunted ##

timings.max <- 110   # or max(locations$date.removed, na.rm = T)
nboar.in.zone.hunted.each.day.vec <- c()
for (i in 1:timings.max){                   # 61 corresponds to day after fence was implemented
  nboar.in.zone.hunted.each.day.vec[i] <- (nrow(locations[which((locations$patch %in% c(which(in.fence.buffer.matrix==1))) & (locations$date.removed == i) & (locations$det %in% c("PT", "NT"))),  ])) 
  
}

nboar.in.zone.hunted.each.day.vec <- nboar.in.zone.hunted.each.day.vec * c(rep(5, 59), rep(1, timings.max - 59))


   # Positive - hunted #
nboar.in.zone.hunted.positive.vec <- c()
for (i in 1:timings.max){                   # 61 corresponds to day after fence was implemented
  nboar.in.zone.hunted.positive.vec[i] <- nrow(locations[which((locations$patch %in% c(which(in.fence.buffer.matrix==1))) & (locations$date.removed == i) & (locations$det %in% c("PT"))),  ])
}

nboar.in.zone.hunted.positive.vec <- nboar.in.zone.hunted.positive.vec * c(rep(5, 59), rep(1, timings.max - 59))


## Found (AS or PS) ##

nboar.in.zone.found.each.day.vec <- c()
for (i in 1:timings.max){                   # 61 corresponds to day after fence was implemented
  nboar.in.zone.found.each.day.vec[i] <- nrow(locations[which((locations$patch %in% c(which(in.fence.buffer.matrix==1))) & (locations$date.removed == i) & (locations$det %in% c("PS", "AS", "NAS"))),  ])
  
}



# Positive - found #

nboar.in.zone.found.positive.vec <- c()
for (i in 1:timings.max){                   # 61 corresponds to day after fence was implemented
  nboar.in.zone.found.positive.vec[i] <- nrow(locations[which((locations$patch %in% c(which(in.fence.buffer.matrix==1))) & (locations$date.removed == i) & (locations$det %in% c("PS", "AS"))),  ])
}

# nboar.in.zone.found.each.day.vec - nboar.in.zone.found.positive.vec # The results show that the majority of carcasses found within the zone each day was positive.






##  OUTSIDE ZONE   ##


## In this section, we compute the number of boar hunted each day outside the fence-buffer
## To do this, we use observed search and hunting data. 
## For hunting data, multiply by 5 (outside the zone, only 20% of hunted boar are tested)
## Use active search figures as observed


## Hunted ##

nboar.out.zone.hunted.each.day.vec <- c()
for (i in 1:timings.max){
  nboar.out.zone.hunted.each.day.vec[i] <- 5*(nrow(locations[which((locations$patch %in% c(which(in.fence.buffer.matrix==0))) & (locations$date.removed == i) & (locations$det %in% c("PT", "NT"))),  ])) 
  
}


## Found (AS or PS) ##

nboar.out.zone.found.each.day.vec <- c()
for (i in 1:timings.max){                   # 61 corresponds to day after fence was implemented
  nboar.out.zone.found.each.day.vec[i] <- nrow(locations[which((locations$patch %in% c(which(in.fence.buffer.matrix==0))) & (locations$date.removed == i) & (locations$det %in% c("AS", "NAS", "PS"))),  ])
  
}





## ORGANIZE INTO DATA FRAME ##


##  Number removed in zone **at** day t
in.zone.removed <- nboar.in.zone.hunted.each.day.vec + nboar.in.zone.found.each.day.vec

## Number removed outside zone **at** day t
out.zone.removed <- nboar.out.zone.hunted.each.day.vec + nboar.out.zone.found.each.day.vec

## Total removed **at** day t

total.removed <- in.zone.removed + out.zone.removed

## Compute number remaining **by** day t

in.zone.total <- length(which(locations$patch %in% c(which(in.fence.buffer.matrix==1)))) # Count by day 0, 68235; computed from expected and observed counts. Refer to data-prep-1-phase3.Rmd for details. 
out.zone.total <- length(which(locations$patch %in% c(which(in.fence.buffer.matrix==0)))) # Count by day 0, 27734
# Checks
in.zone.total+out.zone.total == sum(nBoarsMatrix) # should be true. That is, the number of boars within and outside the zone should be equal to the number in the boar matrix. 


in.zone.remaining <- in.zone.total - cumsum(in.zone.removed)      # by day 110, 42076
out.zone.remaining <- out.zone.total - cumsum(out.zone.removed)   # by day 110, 19619


## Compute daily fraction of remaining boar removed 

fraction.removed.in.zone <- in.zone.removed/in.zone.remaining
fraction.removed.out.zone <- out.zone.removed/out.zone.remaining


## Compute daily fraction of remaining boar hunted

fraction.hunted.in.zone <- nboar.in.zone.hunted.each.day.vec/in.zone.remaining
fraction.hunted.out.zone <- nboar.out.zone.hunted.each.day.vec/out.zone.remaining


## Compute daily fraction of remaining boar found 

fraction.found.in.zone <- nboar.in.zone.found.each.day.vec/in.zone.remaining
fraction.found.out.zone <- nboar.out.zone.found.each.day.vec/out.zone.remaining



# Combine removals into one object

removals <- data.frame(in.zone.removed = in.zone.removed, 
                        in.zone.found =  nboar.in.zone.found.each.day.vec,
                        in.zone.hunted = nboar.in.zone.hunted.each.day.vec,
                        out.zone.removed = out.zone.removed,
                        out.zone.found = nboar.out.zone.found.each.day.vec,
                        out.zone.hunted =  nboar.out.zone.hunted.each.day.vec,
                        total.removed = total.removed,
                        in.zone.remaining =  in.zone.remaining,                                                                            
                        out.zone.remaining = out.zone.remaining,
                        total.remaining =  in.zone.remaining + out.zone.remaining,
                        total.hunted = nboar.in.zone.hunted.each.day.vec +  nboar.out.zone.hunted.each.day.vec,
                        fraction.removed.in.zone = fraction.removed.in.zone,
                        fraction.removed.out.zone = fraction.removed.out.zone)


removals$in.zone.hunted.positive <- nboar.in.zone.hunted.positive.vec
removals$in.zone.hunted.negative <- removals$in.zone.hunted - removals$in.zone.hunted.positive
removals$out.zone.hunted.positive <- 0                           # See Day 110 update; no positive boar found outside zone by day 110
removals$out.zone.hunted.negative <- removals$out.zone.hunted



# Total removed by day 110: 
sum(removals$total.removed)
# [1] 34274 # 8702 more removals between day 81 and day 110. 

# Total removed in zone
sum(removals$in.zone.removed)
# [1] 26159 # 6592 additional removals within zone between day 81 and day 110. 

# Total removed out zone
sum(removals$out.zone.removed)
# [1] 8115  # 2110 additional removals outside zone between day 81 and day 110. 






##################################################################
##                  SAVE OUTPUT DATA                           ##
##################################################################


## USED DIRECTLY IN THE ANALYSIS ##

# saveRDS(patchcentres, file = glue(wd.output.data, "model input/patchcentres.RDS"))                     # Patch centres in X and Y directions
# saveRDS(infectionStatusMatrix, file = glue(wd.output.data, "model input/infectionStatusMatrix60.RDS")) # Infection status of patches 
# saveRDS(nBoarsMatrix, file = glue(wd.output.data, "model input/nBoarsMatrix.RDS"))                   # Number of wild boar per patch
# saveRDS(locations, file = glue(wd.output.data, "model input/locations60.RDS"))                       # Data on wild boar remaining in landscape by day 60
# saveRDS(all.patch.centres, file = glue(wd.output.data, "model input/all.patch.centres.RDS"))         # Coordinates of all patch centres 
# saveRDS(dist.patches, file = glue(wd.output.data, "model input/dist.patches.RDS"))                   # Distance (in km) between patches 
# saveRDS(observed.positive,  file = glue(wd.output.data, "model input/observed.positive.RDS") )       # Daily observed count of positive wild boar
# saveRDS(observed.positive.locations60,  file = glue(wd.output.data, "model input/observed.positive.locations60.RDS") )       # Daily observed count of positive wild boar
# saveRDS(in.fence.buffer.matrix, file = glue(wd.output.data, "model input/in.fence.buffer.matrix.RDS")) # Indicator matrix showing whether patch is in fence-buffer zone
# saveRDS(in.fence.matrix, file = glue(wd.output.data, "model input/in.fence.matrix.RDS"))             # Indicator matrix showing whether patch is in fence
# saveRDS(removals, file = glue(wd.output.data, "model input/removals.RDS"))                           # Daily observed removals 


## OTHER (NOT USED DIRECTLY IN MODEL) ##

# saveRDS(locations.full, file = glue(wd.output.data, "other\locations.full.RDS"))       # Data on all wild boar in landscape, by day 0
# saveRDS(locations.day.59, file = glue(wd.data.day.60, "other\locations.day.59.RDS"))           # Data on wild boar removed from landscape, from day 0 to day 59
# saveRDS(observed.positive.locations,  file = glue(wd.output.data, "other\observed.positive.locations.RDS") )       # List of locations of positive wild boar by each day, from day 1 to day 110
# saveRDS(fence.coordinates, file = glue(wd.output.data, "other\fence.coordinates.RDS"))         # Fence coordinates
# saveRDS(zone.coordinates, file = glue(wd.output.data, "other\zone.coordinates.RDS"))           # Coordinates of fence buffer zone 
# saveRDS(observed.negative, file = glue(wd.output.data, "other\observed.negative.RDS"))         # Daily observed count of negative wild boar 

# SAVE RELEVANT DATA TO PIG HERD MODEL LOCATION
# saveRDS(patchcentres, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_Predict", "input", "patchcentres.RDS")) 
# saveRDS(locations, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_Predict", "input", "locations60.RDS")) 
# saveRDS(locations.day.59, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_Predict", "input", "locations.day.59.RDS")) 
# 
# 
# 
# saveRDS(patchcentres, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_Predict_230", "input", "patchcentres.RDS")) 
# saveRDS(locations, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_Predict_230", "input", "locations60.RDS")) 
# saveRDS(locations.day.59, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_Predict_230", "input", "locations.day.59.RDS")) 
# 
# 
# saveRDS(patchcentres, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_SA", "input", "patchcentres.RDS")) 
# saveRDS(locations, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_SA", "input", "locations60.RDS")) 
# saveRDS(locations.day.59, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_SA", "input", "locations.day.59.RDS")) 
