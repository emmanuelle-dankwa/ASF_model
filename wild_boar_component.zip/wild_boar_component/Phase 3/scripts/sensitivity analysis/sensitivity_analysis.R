###############  SENSITIVITY ANALYSIS FOR WILD BOAR MODEL (PHASE 3)   ################
# IN THIS SCRIPT, 
# 1. SENSITIVITY ANALYSIS FOR PARAMETERS STUDIED:
  # * MAXIMUM INFECTION RANGE (MIR) (values = 2 8, 14 and 20; units in km)
  # * ALPHA (values = 600, 800, 1000 and 1200; units in m)
  # * INFC: DURATION OF INFECTIOUSNESS IN CARCASSES (values = 10, 50, 90, 130; units in days)
  # * INFD: DURATION OF INFECTIOUSNESS IN LIVE BOAR (values = 5, 7, 10; units in days)
  # ANALYSIS OUTPUT: 
  # * PART A. DAILY NUMBER OF DETECTED INFECTIONS
  # * PART B. DAILY NUMBER OF INFECTIONS
# 2. ADDITIONAL INSIGHTS ON SENSITIVITY RESULTS 
######################################################################################

# # Load packages # 
library(parallel)
library(glue)
library(devtools)
library(Rcpp)


# Specify directories #
 wd.output.data <- "./output-data/"    # Directory for output data 
 
 # # Load input data #
 source("./scripts/run model/preamble_data_model_phase3.R")                # Loads input data for model and estimation
 
 # # Load model #
 
 source("./scripts/sensitivity_analysis/model_phase3_wild_boar_sensitivity_analysis.R")                    # Loads model function


# Load functions #
source("./scripts/functions/all_functions_phase3.R")  


#### PART A #####
 
 
###################
#                 #
#       MIR       #
#                 #
####################

 
# 1. Run sensitivity analysis simulations
#    output is saved to ./output-data/sensitivity analysis
 
 mclapply(X = list(2,8,14,20),
          FUN = wrapper_function_sa_new,
          mc.cores = detectCores(),
          mir_b = TRUE,   # TRUE = MIR
          alpha_b = FALSE,
          infc_b = FALSE,
          num_iterations =100)

 
 
# 2. Collect results 
 
 # MIR = 2km
 setwd("./output-data/sensitivity analysis/res_mir_2")
 files_mir_2 <- list.files(pattern = "simul_.*")
 mir_simulations_list_2 <- lapply(files_mir_2, readRDS)
 # Save list 
 saveRDS(mir_simulations_list_2, file = "mir_simulations_list_2.RDS")
 
 # MIR = 8km
 
 setwd("../res_mir_8")
 files_mir_8 <- list.files(pattern = "simul_.*")
 mir_simulations_list_8 <- lapply(files_mir_8, readRDS)
 # Delete files except list
 rm(list = ls()[ls()!= "mir_simulations_list_8"])
 # Save list 
 saveRDS(mir_simulations_list_8, file = "mir_simulations_list_8.RDS")

 
 
# MIR = 14
 setwd("../res_mir_14")
 files_mir_14 <- list.files(pattern = "simul_.*")
 mir_simulations_list_14 <- lapply(files_mir_14, readRDS)
 # Delete files except list
 rm(list = ls()[ls()!= "mir_simulations_list_14"])
 # Save list 
 saveRDS(mir_simulations_list_14, file = "mir_simulations_list_14.RDS")


 
 # MIR = 20
 
 setwd("../res_mir_20")
 files_mir_20 <- list.files(pattern = "simul_.*")
 mir_simulations_list_20 <- lapply(files_mir_20, readRDS)
 # Save list 
 saveRDS(mir_simulations_list_20, file = "mir_simulations_list_20.RDS")
 
 

# 3. Save results into a single file

save(mir_simulations_list_2,
     mir_simulations_list_8,
     mir_simulations_list_14,
     mir_simulations_list_20,
     file = "../mir_simulations_list_latest.rda") # Save in main results directory

# Also, save to relevant pig herd model location (as pig herd and wild boar components are run on separate systems, for efficiency)
saveRDS(mir_simulations_list_latest, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_SA", "input", "mir_simulations_list_latest.RDS")) 



# 4. Load these files

load("../mir_simulations_list_latest.RDS") 
# outputs: 
# mir_simulations_list_2
# mir_simulations_list_8
# mir_simulations_list_14
# mir_simulations_list_20


# 5. View model trajectories given various values 
plot(x = 60:110, y = mir_simulations_list_2[[100]]$summarized.res$new.cases.wb, type = "l", ylim = c(1, 200)) # 0.2
lines(x = 60:110, y = mir_simulations_list_8[[100]]$summarized.res$new.cases.wb, col = "red", type = "l") # 8
lines(x = 60:110, y =mir_simulations_list_14[[100]]$summarized.res$new.cases.wb, col = "blue", type = "l") # 14
lines(x = 60:110, y = mir_simulations_list_20[[90]]$summarized.res$new.cases.wb, col = "green", type = "l") # 20



# 6. Extract counts for each value of MIR


ls_2 <- lapply(mir_simulations_list_2, function(x){x$summarized.res})
ls_8 <- lapply(mir_simulations_list_8, function(x){x$summarized.res})
ls_14 <- lapply(mir_simulations_list_14, function(x){x$summarized.res})
ls_20 <- lapply(mir_simulations_list_20, function(x){x$summarized.res})


# 7. Apply extract.cases function to organize list

ls_2_counts <- extract.cases(res.list = ls_2, from.day = 60, to.day = 110)
ls_8_counts <- extract.cases(res.list = ls_8, from.day = 60, to.day = 110)
ls_14_counts <- extract.cases(res.list = ls_14, from.day = 60, to.day = 110)
ls_20_counts <- extract.cases(res.list = ls_20, from.day = 60, to.day = 110)



# 8. Compute daily summaries

median.dly_2 <- apply(ls_2_counts$df.dly.cases, 1, median)
lower.dly_2 <-  apply(ls_2_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_2 <- apply(ls_2_counts$df.dly.cases, 1, quantile, probs = c(0.975))

median.dly_8 <- apply(ls_8_counts$df.dly.cases, 1, median)
lower.dly_8 <-  apply(ls_8_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_8 <- apply(ls_8_counts$df.dly.cases, 1, quantile, probs = c(0.975))

median.dly_14 <- apply(ls_14_counts$df.dly.cases, 1, median)
lower.dly_14 <-  apply(ls_14_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_14 <- apply(ls_14_counts$df.dly.cases, 1, quantile, probs = c(0.975))

median.dly_20 <- apply(ls_20_counts$df.dly.cases, 1, median)
lower.dly_20 <-  apply(ls_20_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_20 <- apply(ls_20_counts$df.dly.cases, 1, quantile, probs = c(0.975))




# 9.. Compute summaries for the number of detected cases for each MIR value
# # Determine the total number of cases in each simulation and take the summary of that distribution


mir_sa_count_summaries <- data.frame(values = c(2, 8, 14, 20),
                                     median =  c(
                                       quantile(ls_2_counts$df.cum.cases[51, ], probs = 0.50),
                                       quantile(ls_8_counts$df.cum.cases[51, ], probs = 0.50),
                                       quantile(ls_14_counts$df.cum.cases[51, ], probs = 0.50),
                                       quantile(ls_20_counts$df.cum.cases[51, ], probs = 0.50)),
                                     lower_ci = c(
                                       quantile(ls_2_counts$df.cum.cases[51, ], probs = 0.025),
                                       quantile(ls_8_counts$df.cum.cases[51, ], probs = 0.025),
                                       quantile(ls_14_counts$df.cum.cases[51, ], probs = 0.025),
                                       quantile(ls_20_counts$df.cum.cases[51, ], probs = 0.025)),
                                     upper_ci = c(
                                       quantile(ls_2_counts$df.cum.cases[51, ], probs = 0.975),
                                       quantile(ls_8_counts$df.cum.cases[51, ], probs = 0.975),
                                       quantile(ls_14_counts$df.cum.cases[51, ], probs = 0.975),
                                       quantile(ls_20_counts$df.cum.cases[51, ], probs = 0.975)))
mir_sa_count_summaries
write.csv(mir_sa_count_summaries, file ="../mir_sa_count_summaries_latest.csv")


# Including the number of boar from day 1 to day 59; report the below in paper

mir_sa_count_summaries[, c("median", "lower_ci", "upper_ci")] + sum(observed.positive$count[1:59])


# 10. Combine into single data frame for plotting

mir_sa_trajectories <- data.frame(day = 60:110,
                                  median.dly_2,
                                  lower.dly_2,
                                  upper.dly_2,
                                  median.dly_8,
                                  lower.dly_8,
                                  upper.dly_8,
                                  median.dly_14,
                                  lower.dly_14,
                                  upper.dly_14,
                                  median.dly_20,
                                  lower.dly_20,
                                  upper.dly_20)

mir_sa_trajectories
saveRDS(mir_sa_trajectories, file ="../mir_sa_trajectories.RDS")  # Save in main results directory



# Comparing sensitivity analysis results 
# Percentage increase from 2km to 8km 
# = ((count_8 - count_2) / count_2)*100
with(mir_sa_count_summaries_latest, (median[values == 8] - median[values==2])/median[values==2])

# Percentage increase from 8km to 14km 
with(mir_sa_count_summaries_latest, (median[values == 14] - median[values==8])/median[values==8])

# Compute the differences between the cumulative number of detected herds for 2km and 8km 

perc.increase.2.to.8 <- (ls_8_counts$df.cum.cases[51, ] - ls_2_counts$df.cum.cases[51, ]) / ls_2_counts$df.cum.cases[51, ]
quantile(perc.increase.2.to.8, probs = c(0.50, 0.025,0.975))


# Compute the differences between the cumulative number of detected herds for 8km and 14km 

perc.increase.8.to.14 <- (ls_14_counts$df.cum.cases[51, ] - ls_8_counts$df.cum.cases[51, ]) / ls_8_counts$df.cum.cases[51, ]
quantile(perc.increase.8.to.14, probs = c(0.50, 0.025,0.975))








###################
#                 #
#     ALPHA       #
#                 #
###################


# 1. Run SA

mclapply(X = list(600,800,1000,1200),  # parameter values under study
         FUN = wrapper_function_sa_new,
         mc.cores = detectCores(),
         mir_b = FALSE,   
         alpha_b = TRUE,  # TRUE = alpha
         infc_b = FALSE,
         num_iterations = 100)



# 2. Collect results


# alpha = 600m
setwd("./output-data/sensitivity analysis/res_alpha_600")
files_alpha_600 <- list.files(pattern = "alpha_600_simul_.*")
files_alpha_600 <- files_alpha_600[1:100]
length(files_alpha_600) == 100
alpha_simulations_list_600 <- lapply(files_alpha_600, readRDS)
# Delete files_alpha
rm(files_alpha_600)
# Save list 
saveRDS(alpha_simulations_list_600, file = "alpha_simulations_list_600.RDS")



# alpha = 800m

setwd("../res_alpha_800")
files_alpha_800 <- list.files(pattern = "alpha_800_simul_.*")
#files_alpha_800
files_alpha_800 <- files_alpha_800[1:100]
length(files_alpha_800) == 100
alpha_simulations_list_800 <- lapply(files_alpha_800, readRDS)
# Delete files_alpha
rm(files_alpha_800)
# Save list 
saveRDS(alpha_simulations_list_800, file = "alpha_simulations_list_800.RDS")




# alpha = 1000m

setwd("../res_alpha_1000")
files_alpha_1000 <- list.files(pattern = "alpha_1000_simul_.*")
files_alpha_1000
length(files_alpha_1000) == 100
alpha_simulations_list_1000 <- lapply(files_alpha_1000, readRDS)
# Delete files_alpha
rm(files_alpha_1000)
# Save list 
saveRDS(alpha_simulations_list_1000, file = "alpha_simulations_list_1000.RDS")



# alpha = 1200m

setwd("../res_alpha_1200")
files_alpha_1200 <- list.files(pattern = "alpha_1200_simul_.*")
files_alpha_1200
files_alpha_1200 <- files_alpha_1200[1:100]
length(files_alpha_1200) == 100
alpha_simulations_list_1200 <- lapply(files_alpha_1200, readRDS)
# Delete files_alpha
rm(files_alpha_1200)
# Save list 
saveRDS(alpha_simulations_list_1200, file = "alpha_simulations_list_1200.RDS")



# 3. Save results into a single file

save(alpha_simulations_list_600,
     alpha_simulations_list_800,
     alpha_simulations_list_1000, # if not found, load from directories
     alpha_simulations_list_1200,
     file = "../alpha_simulations_list_latest.rda") # Save in main results directory

# Also, save to relevant pig herd model location 
saveRDS(alpha_simulations_list_latest, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_SA", "input", "alpha_simulations_list_latest.RDS")) 


# 4. Load these files

load("../alpha_simulations_list_latest.RDS") 

# outputs: 
# mir_simulations_list_2
# mir_simulations_list_8
# mir_simulations_list_14
# mir_simulations_list_20


# 5. View model trajectories given various values 
plot(x = 60:110, y = alpha_simulations_list_600[[100]]$summarized.res$new.cases.wb, type = "l", ylim = c(1, 200)) # 0.2
lines(x = 60:110, y = alpha_simulations_list_800[[100]]$summarized.res$new.cases.wb, col = "red", type = "l") # 8
lines(x = 60:110, y =alpha_simulations_list_1000[[100]]$summarized.res$new.cases.wb, col = "blue", type = "l") # 14
lines(x = 60:110, y = alpha_simulations_list_1200[[100]]$summarized.res$new.cases.wb, col = "green", type = "l") # 20



# 6. Extract counts for each value of alpha

ls_600 <- lapply(alpha_simulations_list_600, function(x){x$summarized.res})
ls_800 <- lapply(alpha_simulations_list_800, function(x){x$summarized.res})
ls_1000 <- lapply(alpha_simulations_list_1000, function(x){x$summarized.res})
ls_1200 <- lapply(alpha_simulations_list_1200, function(x){x$summarized.res})


# 7. Apply extract.cases function to organize list

ls_600_counts <- extract.cases(res.list = ls_600, from.day = 60, to.day = 110)
ls_800_counts <- extract.cases(res.list = ls_800, from.day = 60, to.day = 110)
ls_1000_counts <- extract.cases(res.list = ls_1000, from.day = 60, to.day = 110)
ls_1200_counts <- extract.cases(res.list = ls_1200, from.day = 60, to.day = 110)



# 8. Compute daily summaries

median.dly_600 <- apply(ls_600_counts$df.dly.cases, 1, median)
lower.dly_600 <-  apply(ls_600_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_600 <- apply(ls_600_counts$df.dly.cases, 1, quantile, probs = c(0.975))

median.dly_800 <- apply(ls_800_counts$df.dly.cases, 1, median)
lower.dly_800 <-  apply(ls_800_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_800 <- apply(ls_800_counts$df.dly.cases, 1, quantile, probs = c(0.975))

median.dly_1000 <- apply(ls_1000_counts$df.dly.cases, 1, median)
lower.dly_1000 <-  apply(ls_1000_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_1000 <- apply(ls_1000_counts$df.dly.cases, 1, quantile, probs = c(0.975))

median.dly_1200 <- apply(ls_1200_counts$df.dly.cases, 1, median)
lower.dly_1200 <-  apply(ls_1200_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_1200 <- apply(ls_1200_counts$df.dly.cases, 1, quantile, probs = c(0.975))



# 9. Compute summaries for the number of detected cases for each alpha value


alpha_sa_count_summaries <- data.frame(values = c(600, 800, 1000, 1200),
                                     median =  c(
                                       quantile(ls_600_counts$df.cum.cases[51, ], probs = 0.50),
                                       quantile(ls_800_counts$df.cum.cases[51, ], probs = 0.50),
                                       quantile(ls_1000_counts$df.cum.cases[51, ], probs = 0.50),
                                       quantile(ls_1200_counts$df.cum.cases[51, ], probs = 0.50)),
                                     lower_ci = c(
                                       quantile(ls_600_counts$df.cum.cases[51, ], probs = 0.025),
                                       quantile(ls_800_counts$df.cum.cases[51, ], probs = 0.025),
                                       quantile(ls_1000_counts$df.cum.cases[51, ], probs = 0.025),
                                       quantile(ls_1200_counts$df.cum.cases[51, ], probs = 0.025)),
                                     upper_ci = c(
                                       quantile(ls_600_counts$df.cum.cases[51, ], probs = 0.975),
                                       quantile(ls_800_counts$df.cum.cases[51, ], probs = 0.975),
                                       quantile(ls_1000_counts$df.cum.cases[51, ], probs = 0.975),
                                       quantile(ls_1200_counts$df.cum.cases[51, ], probs = 0.975)))
alpha_sa_count_summaries

write.csv(alpha_sa_count_summaries, file ="../alpha_sa_count_summaries_latest.csv")


# Including the number of boar from day 1 to day 60; report the below in paper

alpha_sa_count_summaries_latest[, c("median", "lower_ci", "upper_ci")] + sum(observed.positive$count[1:59])

alpha_sa_count_summaries[, c("median", "lower_ci", "upper_ci")] + sum(observed.positive$count[1:59])

# Compute the percentage change in the cumulative number of detected herds when alpha = 600 and when alpha = 1200m


perc.increase.600.to.1200 <- (ls_1200_counts$df.cum.cases[51, ] - ls_600_counts$df.cum.cases[51, ]) / ls_600_counts$df.cum.cases[51, ]
quantile(perc.increase.600.to.1200, probs = c(0.50, 0.025,0.975))



# 10. Combine into single data frame for plotting

alpha_sa_trajectories <- data.frame(day = 60:110,
                                  median.dly_600,
                                  lower.dly_600,
                                  upper.dly_600,
                                  median.dly_800,
                                  lower.dly_800,
                                  upper.dly_800,
                                  median.dly_1000,
                                  lower.dly_1000,
                                  upper.dly_1000,
                                  median.dly_1200,
                                  lower.dly_1200,
                                  upper.dly_1200
                                 )

saveRDS(alpha_sa_trajectories, file ="../alpha_sa_trajectories.RDS")



















###################
#                 #
#     INFC        #
#                 #
###################


# 1. Run SA


mclapply(X = list(10,50,90,130),     # mclapply hence needs to be run on a Linux/Mac system; use parLapply (and similar) for Windows
         FUN = wrapper_function_sa_new,
         mc.cores = detectCores(),
         mir_b = FALSE,  
         alpha_b = FALSE,
         infc_b = TRUE,  # TRUE = infc
         infd_b = FALSE,
         num_iterations = 100)


# 2. Collect results


# infc = 10

setwd(".results_phase3/res_infc_10")
files_infc_10 <- list.files(pattern = "infc_10_simu.*")
files_infc_10
files_infc_10 <- files_infc_10[1:100]
length(files_infc_10) == 100
infc_simulations_list_10 <- lapply(files_infc_10, readRDS)
# Delete files_alpha
rm(files_infc_10)
# Save list 
saveRDS(infc_simulations_list_10, file = "infc_simulations_list_10.RDS")


# infc = 50

setwd("../res_infc_50")
files_infc_50 <- list.files(pattern = "infc_50_simu.*")
files_infc_50
files_infc_50 <- files_infc_50[1:100]
infc_simulations_list_50 <- lapply(files_infc_50, readRDS)
# Delete files_alpha
rm(files_infc_50)
# Save list 
saveRDS(infc_simulations_list_50, file = "infc_simulations_list_50.RDS")



# infc = 90

setwd("../res_infc_90")
files_infc_90 <- list.files(pattern = "infc_90_simu.*")
files_infc_90
files_infc_90 <- files_infc_90[1:100]
length(files_infc_90) == 100
infc_simulations_list_90 <- lapply(files_infc_90, readRDS)
# Delete files_alpha
rm(files_infc_90)
# Save list 
saveRDS(infc_simulations_list_90, file = "infc_simulations_list_90.RDS")




# infc = 130

setwd("../res_infc_130")
files_infc_130 <- list.files(pattern = "infc_130_simu.*")
files_infc_130 <- files_infc_130[1:100]
files_infc_130
length(files_infc_130) == 100
infc_simulations_list_130<- lapply(files_infc_130, readRDS)
# Delete files_alpha
rm(files_infc_130)
# Save list 
saveRDS(infc_simulations_list_130, file = "infc_simulations_list_130.RDS")



# 3. Save results into a single file


save(infc_simulations_list_10,  # if not found, load from directories
     infc_simulations_list_50,
     infc_simulations_list_90,
     infc_simulations_list_130,
     file = "../infc_simulations_list_latest.rda") # Save in main results directory


# Also, save to relevant pig herd model location 
saveRDS(infc_simulations_list_latest, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_SA", "input", "infc_simulations_list_latest.RDS")) 



# 4. Load these files

# load("../infc_simulations_list.RDS") 

# outputs: 
# infc_simulations_list_10,  # if not found, load from directories
# infc_simulations_list_50,
# infc_simulations_list_90,
# infc_simulations_list_130


# 5. View model trajectories given various values 
plot(x = 60:110, y = infc_simulations_list_10[[1]]$summarized.res$new.cases.wb, type = "l", ylim = c(1, 200)) # 10
lines(x = 60:110, y = infc_simulations_list_50[[1]]$summarized.res$new.cases.wb, col = "red", type = "l") # 50
lines(x = 60:110, y = infc_simulations_list_90[[1]]$summarized.res$new.cases.wb, col = "blue", type = "l") # 90
lines(x = 60:110, y = infc_simulations_list_130[[1]]$summarized.res$new.cases.wb, col = "green", type = "l") # 130


# 6. Extract counts for each value of infc

ls_10 <- lapply(infc_simulations_list_10, function(x){x$summarized.res})
ls_50 <- lapply(infc_simulations_list_50, function(x){x$summarized.res})
ls_90 <- lapply(infc_simulations_list_90, function(x){x$summarized.res})
ls_130 <- lapply(infc_simulations_list_130, function(x){x$summarized.res})


# 7. Apply extract.cases function to organize list

ls_10_counts <- extract.cases(res.list = ls_10, from.day = 60, to.day = 110)
ls_50_counts <- extract.cases(res.list = ls_50, from.day = 60, to.day = 110)
ls_90_counts <- extract.cases(res.list = ls_90, from.day = 60, to.day = 110)
ls_130_counts <- extract.cases(res.list = ls_130, from.day = 60, to.day = 110)


# 8. Compute daily summaries
median.dly_10 <- apply(ls_10_counts$df.dly.cases, 1, median)
lower.dly_10 <-  apply(ls_10_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_10 <- apply(ls_10_counts$df.dly.cases, 1, quantile, probs = c(0.975))

median.dly_50 <- apply(ls_50_counts$df.dly.cases, 1, median)
lower.dly_50 <-  apply(ls_50_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_50 <- apply(ls_50_counts$df.dly.cases, 1, quantile, probs = c(0.975))

median.dly_90 <- apply(ls_90_counts$df.dly.cases, 1, median)
lower.dly_90 <-  apply(ls_90_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_90 <- apply(ls_90_counts$df.dly.cases, 1, quantile, probs = c(0.975))

median.dly_130 <- apply(ls_130_counts$df.dly.cases, 1, median)
lower.dly_130 <-  apply(ls_130_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_130 <- apply(ls_130_counts$df.dly.cases, 1, quantile, probs = c(0.975))


# 9. Compute summaries for the number of detected cases for each infc value

infc_sa_count_summaries <- data.frame(values = c(10, 50, 90, 130),
                                          median =  c(
                                            median(ls_10_counts$df.cum.cases[51, ]),
                                            median(ls_50_counts$df.cum.cases[51, ]),
                                            median(ls_90_counts$df.cum.cases[51, ]),
                                            median(ls_130_counts$df.cum.cases[51, ])),
                                          lower_ci = c(
                                            quantile(ls_10_counts$df.cum.cases[51, ], probs = 0.025),
                                            quantile(ls_50_counts$df.cum.cases[51, ], probs = 0.025),
                                            quantile(ls_90_counts$df.cum.cases[51, ], probs = 0.025),
                                            quantile(ls_130_counts$df.cum.cases[51, ], probs = 0.025)),
                                          upper_ci = c(
                                            quantile(ls_10_counts$df.cum.cases[51, ], probs =0.975),
                                            quantile(ls_50_counts$df.cum.cases[51, ], probs =0.975),
                                            quantile(ls_90_counts$df.cum.cases[51, ], probs =0.975),
                                            quantile(ls_130_counts$df.cum.cases[51, ], probs =0.975)))



infc_sa_count_summaries
write.csv(infc_sa_count_summaries, file ="../infc_sa_count_summaries_latest.csv")


# Including the number of boar from day 1 to day 60; report the below in paper

infc_sa_count_summaries_latest[, c("median", "lower_ci", "upper_ci")] + sum(observed.positive$count[1:59])


# 10. Combine into single data frame for plotting

infc_sa_trajectories <- data.frame(day = 60:110,
                                   median.dly_10,
                                   lower.dly_10,
                                   upper.dly_10,
                                   median.dly_50,
                                   lower.dly_50,
                                   upper.dly_50,
                                   median.dly_90,
                                   lower.dly_90,
                                   upper.dly_90,
                                   median.dly_130,
                                   lower.dly_130,
                                   upper.dly_130)

infc_sa_trajectories
saveRDS(infc_sa_trajectories, file ="../infc_sa_trajectories.RDS")







###################
#                 #
#     INFD        #
#                 #
###################



# 1. Run SA


mclapply(X = list(5,7,10),     # mclapply hence needs to be run on a Linux/Mac system; use parLapply (and similar) for Windows
         FUN = wrapper_function_sa_new,
         mc.cores = detectCores(),
         mir_b = FALSE,   
         alpha_b = FALSE,
         infc_b = FALSE,
         infd_b = TRUE, # TRUE = infd
         num_iterations = 100)



# 2. Collect results


# infd = 5

setwd(".results_phase3/res_infd_5")
files_infd_5 <- list.files(pattern = "infd_5_simu.*")
files_infd_5
files_infd_5 <- files_infd_5[1:100]
length(files_infd_5) == 100
infd_simulations_list_5 <- lapply(files_infd_5, readRDS)
# Delete files_alpha
rm(files_infd_5)
# Save list 
saveRDS(infd_simulations_list_5, file = "infd_simulations_list_5.RDS")



# infd = 7

setwd("../res_infd_7")
files_infd_7 <- list.files(pattern = "infd_7_simu.*")
files_infd_7
files_infd_7 <- files_infd_7[1:100]
#length(files_infd_7) == 100
infd_simulations_list_7 <- lapply(files_infd_7, readRDS)
# Delete files_alpha
rm(files_infd_7)
# Save list 
saveRDS(infd_simulations_list_7, file = "infd_simulations_list_7.RDS")



# infd = 10

setwd("../res_infd_10")
files_infd_10 <- list.files(pattern = "infd_10_simu.*")
files_infd_10
files_infd_10 <- files_infd_10[1:100]
length(files_infd_10) == 100
infd_simulations_list_10 <- lapply(files_infd_10, readRDS)
# Delete files_alpha
rm(files_infd_10)
# Save list 
saveRDS(infd_simulations_list_10, file = "infd_simulations_list_10.RDS")



# 3. Save results into a single file

save(infd_simulations_list_5,  # if not found, load from directories
     infd_simulations_list_7,
     infd_simulations_list_10,
     file = "../infd_simulations_list_latest.rda") # Save in main results directory

# Also, save to relevant pig herd model location 
saveRDS(infd_simulations_list_latest, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_SA", "input", "infd_simulations_list_latest.RDS")) 



# 4. Load these files

# load("../infd_simulations_list.RDS") 

# outputs: 
# infd_simulations_list_5,  # if not found, load from directories
# infd_simulations_list_7,
# infd_simulations_list_10,


# 5. View model trajectories given various values 
plot(x = 60:110, y = infd_simulations_list_5[[52]]$summarized.res$new.cases.wb, type = "l", ylim = c(1, 200)) # 10
lines(x = 60:110, y = infd_simulations_list_7[[52]]$summarized.res$new.cases.wb, col = "red", type = "l") # 50
lines(x = 60:110, y = infd_simulations_list_10[[52]]$summarized.res$new.cases.wb, col = "blue", type = "l") # 90


# 6. Extract counts for each value of infd

ls_5 <- lapply(infd_simulations_list_5, function(x){x$summarized.res})
ls_7 <- lapply(infd_simulations_list_7, function(x){x$summarized.res})
ls_10 <- lapply(infd_simulations_list_10, function(x){x$summarized.res})


# 7. Apply extract.cases function to organize list

ls_5_counts <- extract.cases(res.list = ls_5, from.day = 60, to.day = 110)
ls_7_counts <- extract.cases(res.list = ls_7, from.day = 60, to.day = 110)
ls_10_counts <- extract.cases(res.list = ls_10, from.day = 60, to.day = 110)


# 8. Compute daily summaries
median.dly_5 <- apply(ls_5_counts$df.dly.cases, 1, median)
lower.dly_5 <-  apply(ls_5_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_5 <- apply(ls_5_counts$df.dly.cases, 1, quantile, probs = c(0.975))

median.dly_7 <- apply(ls_7_counts$df.dly.cases, 1, median)
lower.dly_7 <-  apply(ls_7_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_7 <- apply(ls_7_counts$df.dly.cases, 1, quantile, probs = c(0.975))

median.dly_10 <- apply(ls_10_counts$df.dly.cases, 1, median)
lower.dly_10 <-  apply(ls_10_counts$df.dly.cases, 1, quantile, probs = c(0.025))
upper.dly_10 <- apply(ls_10_counts$df.dly.cases, 1, quantile, probs = c(0.975))



# 9. Compute summaries for the number of detected cases for each infd value

infd_sa_count_summaries <- data.frame(values = c(5,7,10),
                                      median =  c(
                                        median(ls_5_counts$df.cum.cases[51, ]),
                                        median(ls_7_counts$df.cum.cases[51, ]),
                                        median(ls_10_counts$df.cum.cases[51, ])),
                                      lower_ci = c(
                                        quantile(ls_5_counts$df.cum.cases[51, ], probs = 0.025),
                                        quantile(ls_7_counts$df.cum.cases[51, ], probs = 0.025),
                                        quantile(ls_10_counts$df.cum.cases[51, ], probs = 0.025)),
                                      upper_ci = c(
                                        quantile(ls_5_counts$df.cum.cases[51, ], probs = 0.975),
                                        quantile(ls_7_counts$df.cum.cases[51, ], probs = 0.975),
                                        quantile(ls_10_counts$df.cum.cases[51, ], probs = 0.975)))


infd_sa_count_summaries
write.csv(infd_sa_count_summaries, file ="../infd_sa_count_summaries_latest.csv")


# Including the number of infected detected boar from day 1 to day 59; report the below in paper

infd_sa_count_summaries_latest[, c("median", "lower_ci", "upper_ci")] + sum(observed.positive$count[1:59])


# 10. Combine into single data frame for plotting

infd_sa_trajectories <- data.frame(day = 60:110,
                                   median.dly_5,
                                   lower.dly_5,
                                   upper.dly_5,
                                   median.dly_7,
                                   lower.dly_7,
                                   upper.dly_7,
                                   median.dly_10,
                                   lower.dly_10,
                                   upper.dly_10)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          infd_sa_trajectories
saveRDS(infd_sa_trajectories, file ="../infd_sa_trajectories.RDS")


## Compute the percentage change in the cumulative number of detected herds when infd=5 and when infd=14 (same as ls_14_counts from MIR simulations)

perc.change.14.to.5 <- (ls_5_counts$df.cum.cases[51, ] - ls_14_counts$df.cum.cases[51, ]) / ls_14_counts$df.cum.cases[51, ] 
quantile(perc.change.14.to.5, probs = c(0.50, 0.025,0.975)) # "-" sign acknowledging change is a decrease 


perc.change.14.to.7 <- (ls_7_counts$df.cum.cases[51, ] - ls_14_counts$df.cum.cases[51, ]) / ls_14_counts$df.cum.cases[51, ] 
quantile(perc.change.14.to.7, probs = c(0.50, 0.025,0.975)) # "-" sign acknowledging change is a decrease 


perc.change.14.to.10 <- (ls_10_counts$df.cum.cases[51, ] - ls_14_counts$df.cum.cases[51, ]) / ls_14_counts$df.cum.cases[51, ] 
quantile(perc.change.14.to.10, probs = c(0.50, 0.025,0.975)) # "-" sign acknowledging change is a decrease 













#### PART B #####



###################
#                 #
#       MIR       #
#                 #
###################

# 1. Compute number of infections per day under each scenario ##

mir_2 <- sapply(mir_simulations_list_2, no.infected)
mir_8 <- sapply(mir_simulations_list_8, no.infected)
mir_14 <- sapply(mir_simulations_list_14, no.infected) 
mir_20 <- sapply(mir_simulations_list_20, no.infected)


# 2. Compute daily summaries

median.dly_2 <- apply(mir_2, 1, median)
lower.dly_2 <-  apply(mir_2, 1, quantile, probs = c(0.025))
upper.dly_2 <- apply(mir_2, 1, quantile, probs = c(0.975))

median.dly_8 <- apply(mir_8, 1, median)
lower.dly_8 <-  apply(mir_8, 1, quantile, probs = c(0.025))
upper.dly_8 <- apply(mir_8, 1, quantile, probs = c(0.975))

median.dly_14 <- apply(mir_14, 1, median)
lower.dly_14 <-  apply(mir_14, 1, quantile, probs = c(0.025))
upper.dly_14 <- apply(mir_14, 1, quantile, probs = c(0.975))

median.dly_20 <- apply(mir_20, 1, median)
lower.dly_20 <-  apply(mir_20, 1, quantile, probs = c(0.025))
upper.dly_20 <- apply(mir_20, 1, quantile, probs = c(0.975))




# 3. Compute summaries for the total number of detected cases for each mir value

# Obtain cumulative
mir_2_totals <- apply(mir_2, 2, sum)
mir_8_totals <- apply(mir_8, 2, sum)
mir_14_totals <- apply(mir_14, 2, sum)
mir_20_totals <- apply(mir_20, 2, sum)



mir_sa_count_summaries_inf <- data.frame(values = c(2, 8,14,20),
                                         median =  c(
                                           median(mir_2_totals),
                                           median(mir_8_totals),
                                           median(mir_14_totals),
                                           median(mir_20_totals)),
                                         lower_ci = c(
                                           quantile(mir_2_totals, probs = 0.025),
                                           quantile(mir_8_totals, probs = 0.025),
                                           quantile(mir_14_totals, probs = 0.025),
                                           quantile(mir_20_totals, probs = 0.025)),
                                         upper_ci = c(
                                           quantile(mir_2_totals, probs =0.975),
                                           quantile(mir_8_totals, probs =0.975),
                                           quantile(mir_14_totals, probs =0.975),
                                           quantile(mir_20_totals, probs =0.975)))


mir_sa_count_summaries_inf
write.csv(mir_sa_count_summaries_inf, file = "./output-data/sensitivity analysis/mir_sa_count_summaries_inf.csv") # wd is "~/Phase 3"



# 4. Combine into single data frame for plotting


mir_sa_trajectories_inf <- data.frame(day = 60:110,
                                      median.dly_2,
                                      lower.dly_2,
                                      upper.dly_2,
                                      median.dly_8,
                                      lower.dly_8,
                                      upper.dly_8,
                                      median.dly_14,
                                      lower.dly_14,
                                      upper.dly_14,
                                      median.dly_20,
                                      lower.dly_20,
                                      upper.dly_20)

mir_sa_trajectories_inf
saveRDS(mir_sa_trajectories_inf, file ="./output-data/sensitivity analysis/mir_sa_trajectories_inf.RDS")







###################
#                 #
#     ALPHA       #
#                 #
###################


# 1. Compute number of infections per day under each scenario ##

alpha_600 <- sapply(alpha_simulations_list_600, no.infected)
alpha_800 <- sapply(alpha_simulations_list_800, no.infected)
alpha_1000 <- sapply(alpha_simulations_list_1000, no.infected) 
alpha_1200 <- sapply(alpha_simulations_list_1200, no.infected)


# 2. Compute daily summaries

median.dly_600 <- apply(alpha_600, 1, median)
lower.dly_600 <-  apply(alpha_600, 1, quantile, probs = c(0.025))
upper.dly_600 <- apply(alpha_600, 1, quantile, probs = c(0.975))

median.dly_800 <- apply(alpha_800, 1, median)
lower.dly_800 <-  apply(alpha_800, 1, quantile, probs = c(0.025))
upper.dly_800 <- apply(alpha_800, 1, quantile, probs = c(0.975))

median.dly_1000 <- apply(alpha_1000, 1, median)
lower.dly_1000 <-  apply(alpha_1000, 1, quantile, probs = c(0.025))
upper.dly_1000 <- apply(alpha_1000, 1, quantile, probs = c(0.975))

median.dly_1200 <- apply(alpha_1200, 1, median)
lower.dly_1200 <-  apply(alpha_1200, 1, quantile, probs = c(0.025))
upper.dly_1200 <- apply(alpha_1200, 1, quantile, probs = c(0.975))




# 3. Compute summaries for the total number of detected cases for each alpha value

# Obtain cumulative
alpha_600_totals <- apply(alpha_600, 2, sum)
alpha_800_totals <- apply(alpha_800, 2, sum)
alpha_1000_totals <- apply(alpha_1000, 2, sum)
alpha_1200_totals <- apply(alpha_1200, 2, sum)



alpha_sa_count_summaries_inf <- data.frame(values = c(600, 800,1000,1200),
                                           median =  c(
                                             median(alpha_600_totals),
                                             median(alpha_800_totals),
                                             median(alpha_1000_totals),
                                             median(alpha_1200_totals)),
                                           lower_ci = c(
                                             quantile(alpha_600_totals, probs = 0.025),
                                             quantile(alpha_800_totals, probs = 0.025),
                                             quantile(alpha_1000_totals, probs = 0.025),
                                             quantile(alpha_1200_totals, probs = 0.025)),
                                           upper_ci = c(
                                             quantile(alpha_600_totals, probs =0.975),
                                             quantile(alpha_800_totals, probs =0.975),
                                             quantile(alpha_1000_totals, probs =0.975),
                                             quantile(alpha_1200_totals, probs =0.975)))


alpha_sa_count_summaries_inf
write.csv(alpha_sa_count_summaries_inf, file ="./output-data/sensitivity analysis/alpha_sa_count_summaries_inf.csv")






# 4. Combine into single data frame for plotting


alpha_sa_trajectories_inf <- data.frame(day = 60:110,
                                        median.dly_600,
                                        lower.dly_600,
                                        upper.dly_600,
                                        median.dly_800,
                                        lower.dly_800,
                                        upper.dly_800,
                                        median.dly_1000,
                                        lower.dly_1000,
                                        upper.dly_1000,
                                        median.dly_1200,
                                        lower.dly_1200,
                                        upper.dly_1200)

alpha_sa_trajectories_inf
saveRDS(alpha_sa_trajectories_inf, file ="./output-data/sensitivity analysis/alpha_sa_trajectories_inf.RDS")




###################
#                 #
#     INFC        #
#                 #
###################

# 1. Compute number of infections per day under each scenario ##

infc_10 <- sapply(infc_simulations_list_10, no.infected)
infc_50 <- sapply(infc_simulations_list_50, no.infected)
infc_90 <- sapply(infc_simulations_list_90, no.infected)
infc_130 <- sapply(infc_simulations_list_130, no.infected)

# 2. Compute daily summaries

median.dly_10 <- apply(infc_10, 1, median)
lower.dly_10 <-  apply(infc_10, 1, quantile, probs = c(0.025))
upper.dly_10 <- apply(infc_10, 1, quantile, probs = c(0.975))

median.dly_50 <- apply(infc_50, 1, median)
lower.dly_50 <-  apply(infc_50, 1, quantile, probs = c(0.025))
upper.dly_50 <- apply(infc_50, 1, quantile, probs = c(0.975))

median.dly_90 <- apply(infc_90, 1, median)
lower.dly_90 <-  apply(infc_90, 1, quantile, probs = c(0.025))
upper.dly_90 <- apply(infc_90, 1, quantile, probs = c(0.975))

median.dly_130 <- apply(infc_130, 1, median)
lower.dly_130 <-  apply(infc_130, 1, quantile, probs = c(0.025))
upper.dly_130 <- apply(infc_130, 1, quantile, probs = c(0.975))


# 3. Compute summaries for the number of detected cases for each infc value

infc_10_totals <- apply(infc_10, 2, sum)
infc_50_totals <- apply(infc_50, 2, sum)
infc_90_totals <- apply(infc_90, 2, sum)
infc_130_totals <- apply(infc_130, 2, sum)


infc_sa_count_summaries_inf <- data.frame(values = c(10, 50, 90, 130),
                                          median =  c(
                                            median(infc_10_totals),
                                            median(infc_50_totals),
                                            median(infc_90_totals),
                                            median(infc_130_totals)),
                                          lower_ci = c(
                                            quantile(infc_10_totals, probs = 0.025),
                                            quantile(infc_50_totals, probs = 0.025),
                                            quantile(infc_90_totals, probs = 0.025),
                                            quantile(infc_130_totals, probs = 0.025)),
                                          upper_ci = c(
                                            quantile(infc_10_totals, probs =0.975),
                                            quantile(infc_50_totals, probs =0.975),
                                            quantile(infc_90_totals, probs =0.975),
                                            quantile(infc_130_totals, probs =0.975)))


infc_sa_count_summaries_inf
write.csv(infc_sa_count_summaries_inf, file ="./output-data/sensitivity analysis/infc_sa_count_summaries_inf.csv")




# 4. Combine into single data frame for plotting

infc_sa_trajectories_inf <- data.frame(day = 60:110,
                                       median.dly_10,
                                       lower.dly_10,
                                       upper.dly_10,
                                       median.dly_50,
                                       lower.dly_50,
                                       upper.dly_50,
                                       median.dly_90,
                                       lower.dly_90,
                                       upper.dly_90,
                                       median.dly_130,
                                       lower.dly_130,
                                       upper.dly_130)

infc_sa_trajectories_inf
saveRDS(infc_sa_trajectories_inf, file ="./output-data/sensitivity analysis/infc_sa_trajectories_inf.RDS")








###################
#                 #
#     INFD        #
#                 #
###################

# 1. Compute number of infections per day under each scenario ##

infd_5 <- sapply(infd_simulations_list_5, no.infected)
infd_7 <- sapply(infd_simulations_list_7, no.infected)
infd_10 <- sapply(infd_simulations_list_10, no.infected)
infd_14 <- sapply(mir_simulations_list_8, no.infected) # same parameter settings as MIR = 8km (inf.to.death = 14, alpha = 1000, inf.carc.dur = 90)

# 2. Compute daily summaries

median.dly_5 <- apply(infd_5, 1, median)
lower.dly_5 <-  apply(infd_5, 1, quantile, probs = c(0.025))
upper.dly_5 <- apply(infd_5, 1, quantile, probs = c(0.975))

median.dly_7 <- apply(infd_7, 1, median)
lower.dly_7 <-  apply(infd_7, 1, quantile, probs = c(0.025))
upper.dly_7 <- apply(infd_7, 1, quantile, probs = c(0.975))

median.dly_10 <- apply(infd_10, 1, median)
lower.dly_10 <-  apply(infd_10, 1, quantile, probs = c(0.025))
upper.dly_10 <- apply(infd_10, 1, quantile, probs = c(0.975))

median.dly_14 <- apply(infd_14, 1, median)
lower.dly_14 <-  apply(infd_14, 1, quantile, probs = c(0.025))
upper.dly_14 <- apply(infd_14, 1, quantile, probs = c(0.975))


# 3. Compute summaries for the number of detected cases for each infd value

# Obtain cumulative
infd_5_totals <- apply(infd_5, 2, sum)
infd_7_totals <- apply(infd_7, 2, sum)
infd_10_totals <- apply(infd_10, 2, sum)
infd_14_totals <- apply(infd_14, 2, sum)


infd_sa_count_summaries_inf <- data.frame(values = c(5, 7, 10, 14),
                                          median =  c(
                                            median(infd_5_totals),
                                            median(infd_7_totals),
                                            median(infd_10_totals),
                                            median(infd_14_totals)),
                                          lower_ci = c(
                                            quantile(infd_5_totals, probs = 0.025),
                                            quantile(infd_7_totals, probs = 0.025),
                                            quantile(infd_10_totals, probs = 0.025),
                                            quantile(infd_14_totals, probs = 0.025)),
                                          upper_ci = c(
                                            quantile(infd_5_totals, probs =0.975),
                                            quantile(infd_7_totals, probs =0.975),
                                            quantile(infd_10_totals, probs =0.975),
                                            quantile(infd_14_totals, probs =0.975)))


infd_sa_count_summaries_inf
write.csv(infd_sa_count_summaries_inf, file ="./output-data/sensitivity analysis/infd_sa_count_summaries_inf.csv")






# 4. Combine into single data frame for plotting

infd_sa_trajectories_inf <- data.frame(day = 60:110,
                                       median.dly_5,
                                       lower.dly_5,
                                       upper.dly_5,
                                       median.dly_7,
                                       lower.dly_7,
                                       upper.dly_7,
                                       median.dly_10,
                                       lower.dly_10,
                                       upper.dly_10,
                                       median.dly_14,
                                       lower.dly_14,
                                       upper.dly_14)

infd_sa_trajectories_inf
saveRDS(infd_sa_trajectories_inf, file ="./output-data/sensitivity analysis/infd_sa_trajectories_inf.RDS")




############################
#                          #
#   ADDITIONAL INSIGHTS    #
#  ON SENSITIVITY RESULTS  #
#                          #
############################


# How long on average did boar spend in the landscape 


# For carcasses that have been removed, pick up the removal date and their infection date 
# to compute the time they spend as being infectious carcasses, find the difference between the removal date and the infection date. For each scenario, find the max
# mum of these dates 

a <- sapply(infc_simulations_list_10, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))
b <- sapply(infc_simulations_list_50, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))
c <- sapply(infc_simulations_list_90, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))
d <- sapply(infc_simulations_list_130, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))


sapply(list(a,b,c,d), function(X) mean(unlist(X)))



e <- sapply(mir_simulations_list_2, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))
f <- sapply(mir_simulations_list_8, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))
g <- sapply(mir_simulations_list_14, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))
h <- sapply(mir_simulations_list_20, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))


sapply(list(e,f,g,h), function(X) mean(unlist(X)))




i <- sapply(infd_simulations_list_5, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))
j <- sapply(infd_simulations_list_7, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))
k <- sapply(infd_simulations_list_10, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))
l <- sapply(mir_simulations_list_14, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))


sapply(list(i,j,k,l), function(X) mean(unlist(X)))




m <- sapply(alpha_simulations_list_600, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))
n <- sapply(alpha_simulations_list_800, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))
o <- sapply(alpha_simulations_list_1000, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))
p <- sapply(alpha_simulations_list_1200, function(X) X$locations$date.removed2[X$locations$carcass==1 & X$locations$date.removed2!=0] - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2!=0] + 14))


sapply(list(m,n,o,p), function(X) mean(unlist(X)))


# Across all models, the average number of time an infectious carcass spends on tje emvironment before being removed]

sapply(list(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p),  function(X) mean(unlist(X)))








# For carcasses that ***have not been removed***, pick up the latest date and their infection date 
# to compute the time they spend as being infectious carcasses, find the difference between the removal date and the infection date. For each scenario, find the max
# of these dates 

a <- sapply(infc_simulations_list_10, function(X) 150 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))
b <- sapply(infc_simulations_list_50, function(X) 150 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))
c <- sapply(infc_simulations_list_90, function(X) 150 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))
d <- sapply(infc_simulations_list_130, function(X) 150 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))


sapply(list(a,b,c,d), function(X) mean(unlist(X)))



e <- sapply(mir_simulations_list_2, function(X) 110 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))
f <- sapply(mir_simulations_list_8, function(X) 110 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))
g <- sapply(mir_simulations_list_14, function(X) 110 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))
h <- sapply(mir_simulations_list_20, function(X) 110 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))


sapply(list(e,f,g,h), function(X) mean(unlist(X)))




i <- sapply(infd_simulations_list_5, function(X) 110 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))
j <- sapply(infd_simulations_list_7, function(X) 110 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))
k <- sapply(infd_simulations_list_10, function(X) 110 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))
l <- sapply(mir_simulations_list_14, function(X) 110 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))


sapply(list(i,j,k,l), function(X) mean(unlist(X)))




m <- sapply(alpha_simulations_list_600, function(X) 110 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))
n <- sapply(alpha_simulations_list_800, function(X) 110 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))
o <- sapply(alpha_simulations_list_1000, function(X) 110 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))
p <- sapply(alpha_simulations_list_1200, function(X) 110 - (X$locations$date.infected[X$locations$carcass==1 & X$locations$date.removed2==0] + 14))


sapply(list(m,n,o,p), function(X) mean(unlist(X)))


# Across all models, the average number of time an infectious carcass spends on tje emvironment before being removed]

sapply(list(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p),  function(X) mean(unlist(X)))



## Compute the percentage change in the cumulative number of detected herds when infd=5 and when infd=14 (same as ls_14_counts from MIR simulations)

perc.change.14.to.5.inf <- (infd_5_totals - infd_14_totals) / infd_5_totals
quantile(perc.change.14.to.5.inf, probs = c(0.50, 0.025,0.975)) 































































