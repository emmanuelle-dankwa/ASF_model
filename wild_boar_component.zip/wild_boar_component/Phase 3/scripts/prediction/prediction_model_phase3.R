### THIS SCRIPT CONTAINS CODE FOR PREDICTIONS FOR A TRANSMISSION MODEL FOR WILD BOAR #### 
### ASF CHALLENGE - UK TEAM ###



##### FUNCTION FOR RUNNING SIMULATIONS UNDER VARIOUS SCENARIOS #####

## Arguments ##

# beta:               Transmission rate
# alpha:              Spatial scale
# hunt.test.prop:     Proportion of hunted boar that are tested in a "normal hunting pressure" scenario. 
# timings:            First day for simulation
# timings.max:        Last day of simulation
# increased pressure: Increased hunting pressure?
# forward simulation: Does model simulation include unobserved days?
# verbose:            Print simulation progress?     
# fence:              Has fence been implemented?

## Other inputs: see 'preamble_data_model_phase2.R' 



# 2 scenarios:

# Fence + normal hunting pressure: forward simulation starts at day 60 ( i.e. take the infection status matrix, nBoarsMatrix and locations at day 59)
# Fence + increased hunting pressure: forward simulation starts at day 81 ( i.e. take the infection status matrix, nBoarsMatrix and locations at day 80)
## Checks in place to ensure timings match the scenario being assessed. 


prediction_model_phase3 <- function(beta, 
                                alpha = 1000,
                                hunt.test.prop = 0.2,
                                timings.max, 
                                dt=1, 
                                fence = TRUE, 
                                increased.pressure=TRUE,
                                forward.simulation = FALSE,
                                max.infection.range = 8, 
                                timings.start = 111,
                                verbose = F,
                                locations,
                                nBoarsMatrix,
                                infectionStatusMatrix,
                                three.month.ahead = F){ 
  
  ##########################################################################################################
  ##########################################################################################################
  
  ## Input Quality Checks ##
  if(increased.pressure & !fence){
    stop("Increased pressure can only be implemented within fence. Set 'fence' to TRUE.")
  }
  
  if(forward.simulation & increased.pressure & timings.start != 111 & !(three.month.ahead)){
    stop("The model is set up to begin forward simulation under increased hunting pressure at day 111. Set 'timings.start' to 111.")
  }
  
  if(forward.simulation & !increased.pressure & timings.start != 60){
    stop("The model is set up to begin forward simulation under normal hunting pressure at day 60. Set 'timings.start' to 60.")
  }
  
  if(timings.start > timings.max){
    stop("Start date ('timings.start') must be less than end date ('timings.max')")  
  }
  
  if(three.month.ahead & timings.max != 230){
    stop("Maximum date for three-month-ahead predictions must be day 230")
  }
  
  
  ## Define VALUES ##:
  
  npatches_x <- npatches_y <-  nrow(patchcentres)
  patchcentres_x <- patchcentres$X
  patchcentres_y <- patchcentres$Y
  patch.ids <- c(1:2500)
  
  timeVals <- c() # Empty vector for storing event times
  wildBoarVals <- c()  # Number of infected wild boar
  recNumHere <- 1
  statusEachTimeStep <- list()
  patches.in.fence <- which(in.fence.matrix==1)         # patches in fence 
  patches.in.zone <- which(in.fence.buffer.matrix==1)   # patches in fence-buffer (zone)
  ## Set sequence for fraction of hunted boar for forward predictions ##
  
  # Within zone #
  
  # Compute percentage decrease in fraction within last 30 days; days 81 to 110 #
  # Assumption is that the change in this estimate is negligible for future periods #
  # percentage.decrease <- (removals$fraction.hunted.in.zone[81] - removals$fraction.hunted.in.zone[110])/ removals$fraction.hunted.in.zone[81]
  # #[1] 0.6479998
  # start.num <- removals$fraction.hunted.in.zone[timings.start-1] # Take mean of last five fractions 
  # end.num <- ((1- percentage.decrease)^4)*start.num                           # Sequence to span four 30-day periods, hence (1- percentage.decrease)^4
  # seq.fraction.hunted.in.zone <- seq(start.num, end.num, length.out =  120) # Forward simulations are from day 111 to day 230 hence 'length.out' set to 120.
  

    # seq.fraction.hunted.in.zone <- seq(seq.start.val, 1e-8, length= 120)
    # seq.fraction.hunted.out.zone <- seq(seq.start.val, 1e-8, length= 120)
    
    # seq.fraction.hunted.in.zone <- sample(removals$fraction.hunted.in.zone[101:110], size = 120, replace = TRUE)
    # seq.fraction.hunted.out.zone <- sample(removals$fraction.hunted.out.zone[101:110], size = 120, replace = TRUE)
    # 
    # See
    seq.fraction.hunted.in.zone.increased.pressure <- runif(120, min = min(removals$fraction.hunted.in.zone[107:110]) - 2e-3, max = max(removals$fraction.hunted.in.zone[107:110]))
    seq.fraction.hunted.out.zone.increased.pressure <- runif(120, min = min(removals$fraction.hunted.out.zone[107:110]) - 2e-3, max = max(removals$fraction.hunted.out.zone[107:110]))
    
    seq.fraction.hunted.in.zone.increased.pressure[seq.fraction.hunted.in.zone.increased.pressure<0] <- 1e-8
    seq.fraction.hunted.out.zone.increased.pressure[seq.fraction.hunted.out.zone.increased.pressure<0] <- 1e-8
    
    # Check that the below are consistent 
    
    # removals$in.zone.hunted
    # round(seq.fraction.hunted.in.zone*removals$in.zone.remaining[110])
    # 
    # 
    # removals$out.zone.hunted
    # round(seq.fraction.hunted.out.zone*removals$out.zone.remaining[110])
    # 

    # seq.fraction.hunted.in.zone.normal.pressure <- seq(mean(removals$fraction.hunted.in.zone[50:59]), 1e-4, length = (140-60)+1 )
    # seq.fraction.hunted.out.zone.normal.pressure <- seq(mean(removals$fraction.hunted.out.zone[50:59]), 1e-4, length = (140-60)+1 )
    # 
    seq.fraction.hunted.in.zone.normal.pressure <- runif(120, min = min(removals$fraction.hunted.in.zone[56:59]) - 2e-3, max = max(removals$fraction.hunted.in.zone[56:59]))
    seq.fraction.hunted.out.zone.normal.pressure <- runif(120, min = min(removals$fraction.hunted.out.zone[56:59]) - 2e-3, max = max(removals$fraction.hunted.out.zone[56:59]))
 
    seq.fraction.hunted.in.zone.normal.pressure[seq.fraction.hunted.in.zone.normal.pressure<0] <- 1e-8
    seq.fraction.hunted.out.zone.normal.pressure[seq.fraction.hunted.out.zone.normal.pressure<0] <- 1e-8
    
     
    seq.fraction.found.in.zone.normal.pressure <- runif(120, min = min(removals$fraction.found.in.zone[40:58])- 2e-5, max = max(removals$fraction.found.in.zone[40:58])) 
    seq.fraction.found.out.zone.normal.pressure <- runif(120, min = 0, max = 0) 
    
    
    
    seq.fraction.found.in.zone.increased.pressure <- runif(120, min = min(removals$fraction.found.in.zone[61:110]) - 2e-5, max = max(removals$fraction.found.in.zone[61:110])) 
    seq.fraction.found.out.zone.increased.pressure <- runif(120, min = 0, max = 0) 
    
    
    
    # removals$in.zone.found[61:110]
    # round(seq.fraction.found.in.zone.increased.pressure*removals$in.zone.remaining[61])
    # 
    # 
    # removals$out.zone.found[40:59]
    # round(seq.fraction.found.out.zone.normal.pressure*removals$out.zone.remaining[59])
    # 
    # removals$in.zone.found[40:59]
    # round(seq.fraction.found.in.zone.normal.pressure*removals$in.zone.remaining[59])
    # 
    # 
  
  
  # Check that the below are consistent 
  # removals$in.zone.hunted[1:59]
  # round(seq.fraction.hunted.in.zone.normal.pressure*removals$in.zone.remaining[59])
  # 
  # 
  # removals$out.zone.hunted[1:59]
  # round(seq.fraction.hunted.out.zone.normal.pressure*removals$out.zone.remaining[59])
  # 
  
  # Outside zone #
  
  # percentage.decrease <- (removals$fraction.hunted.out.zone[81] - removals$fraction.hunted.out.zone[110])/ removals$fraction.hunted.out.zone[81]
  # #[1] 0.04343748
  # start.num <- removals$fraction.hunted.out.zone[timings.start-1]            # Take mean of last five fractions 
  # end.num <- (1- percentage.decrease)^4*start.num                           # Sequence to span four 30-day periods, hence (1- percentage.decrease)^4
  # seq.fraction.hunted.out.zone <- seq(start.num, end.num, length.out =  120) # Forward simulations are from day 111 to day 230 hence 'length.out' set to 120.
  
  
  # rm(percentage.decrease,start.num,end.num) # to free up space
  
  
  
  ##########################################################################################################
  ##########################################################################################################
  
  # If increased pressure, remove all boar with date.removed less than or equal to day 80
  # If increased pressure, remove all boar with date.removed less than or equal to day 80
    
    # If three.month.ahead, save patches where infectious boar have been removed on day 140
    if(three.month.ahead | !(increased.pressure)){
   patches.inf.boar.removed <- locations[which(locations$infectionStatus==1 & locations$date.removed2==140), "patch"]
    }
    
    
  if(increased.pressure){
    updated.boar <- locations[-which(locations$date.removed2 <= (timings.start-1) & locations$date.removed2 != 0), ]
  }else{
    updated.boar <- locations
    updated.boar$infectionStatus[updated.boar$date.infected>=60] <- 0 # Reset all infection statuses that have infection dates on day 60 and beyond, as we have not yet observed these under this scenario. 
    updated.boar$date.removed2[updated.boar$date.removed2>=60] <- 0 # Reset all removal dates that are day 60 and beyond, as these have not yet been observed under this scenario.  
  }
  
  timings <- timings.start
  while(sum(infectionStatusMatrix==1) > 0 & timings <= timings.max){
    
    
    ##########################################################################################################
    ##########################################################################################################
    
    ## WORK OUT INFECTIOUS PRESSURE ON EACH PATCH ##
    
    infectiousPressure <- double(npatches_x*npatches_y)                            # matrix for storing values for infectious pressure on WB
    
    row_I <- as.data.frame(which(infectionStatusMatrix == 1, arr.ind = TRUE))$row  # save row indices for infected patches 
    col_I <- as.data.frame(which(infectionStatusMatrix == 1, arr.ind = TRUE))$col  # save column indices for infected patches 
    
    row <- as.data.frame(which(infectionStatusMatrix == 0, arr.ind = TRUE))$row   # save row indices  for susceptible patches
    col <- as.data.frame(which(infectionStatusMatrix == 0, arr.ind = TRUE))$col   # save column indices for susceptible patches
    
    LinIdx <- (col-1)* nrow(infectionStatusMatrix) + row                         # matrix indices of susceptible patches
    LinIdx_I <- (col_I-1)* nrow(infectionStatusMatrix) + row_I                   # matrix indices of infected patches (a patch is infectious if it has at least one infectious boar)
    
    # Identify susceptible patch position in relation to fence
    suscPatchInFence <- data.frame(which(in.fence.matrix==1 & infectionStatusMatrix==0, arr.ind = TRUE)) # 649
    suscPatchNotInFence <- data.frame(which(in.fence.matrix==0 & infectionStatusMatrix==0, arr.ind = TRUE)) # 1840  (10 patches are infected - 2500 patches in all)
    sPInFence_Idx <- (suscPatchInFence$col-1)*npatches_x + suscPatchInFence$row            # matrix indices of susceptible patches within fence 
    sPNotInFence_Idx <- (suscPatchNotInFence$col-1)*npatches_x + suscPatchNotInFence$row   # matrix indices of susceptible patches outside fence 
    
    
    
    numb.inf.boar.in.inf.patches <- numbboarstateC(LinIdx_I = LinIdx_I, updatedboar = updated.boar, fn = fn, marker = 1)
    numb.susc.boar.in.inf.patches <- numbboarstateC(LinIdx_I = LinIdx_I, updatedboar = updated.boar, fn = fn, marker = 0)
    
    
    ##########################################################################################################
    ###############################   COMPUTE PATCH-LEVEL INFECTION PRESSURE   ################################
    
    
    if(fence&timings>=60){     # IMPLEMENT FENCE FROM DAY 60
      
      for(i in 1:length(row_I)){ # for all infectious patches,
        
        # If infectious patch is in fence,
        if(in.fence.matrix[row_I[i], col_I[i]]==1){ # if infected patch is in fence, infection pressure only exerted on others in fence and received by others in fence 
          
          ## Compute infectious pressure on susceptible within-fence patches ##
          
          # Identify patches which fall within the infection range
          
          in.infect.range <- which(usedist::dist_get(dist.patches, LinIdx_I[i],sPInFence_Idx) <= max.infection.range)  # Indices of susceptible patches which fall within the possible infection range. 
          
          infectiousPressure[sPInFence_Idx[in.infect.range]] <- 
            infectiousPressure[sPInFence_Idx[in.infect.range]] +              # infection pressure on susceptible WB = (infection pressure on susceptible WB) + number of WB in susceptible patch * number of infectious WB in infectious patch [i,j] + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
            nBoarsMatrix[sPInFence_Idx[in.infect.range]] *  numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[suscPatchInFence$col[in.infect.range]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[suscPatchInFence$row[in.infect.range]] - patchcentres_y[row_I[i]])^2))/alpha))
          
          
          
          # Introducing the possibility of an infected patch within the fence to infect susceptible patches outside the fence within max.infection.range/2
          
          # Identify patches outside the fence which fall within max.infection.range/2
          in.infect.range.outside.fence <-  which(usedist::dist_get(dist.patches, LinIdx_I[i],sPNotInFence_Idx) <= max.infection.range/2)
          
          infectiousPressure[sPNotInFence_Idx[in.infect.range.outside.fence]] <- 
            infectiousPressure[sPNotInFence_Idx[in.infect.range.outside.fence]] +              # infection pressure on susceptible WB = (infection pressure on susceptible WB) + number of WB in susceptible patch * number of infectious WB in infectious patch [i,j] + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
            nBoarsMatrix[sPNotInFence_Idx[in.infect.range.outside.fence]] *  numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[suscPatchNotInFence$col[in.infect.range.outside.fence]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[suscPatchNotInFence$row[in.infect.range.outside.fence]] - patchcentres_y[row_I[i]])^2))/alpha))
          
          
          
          
          
          
          ## Compute infectious pressure on infected within-fence patches ##
          
          
          # # Identify indices of infected patches within fence 
          index.inf.patches.in.fence <- which(LinIdx_I %in% patches.in.fence)
          
          # Identify patches which fall within the infection range
          
          in.infect.range <- which(usedist::dist_get(dist.patches, LinIdx_I[i], LinIdx_I[index.inf.patches.in.fence]) <= max.infection.range)
          
          infectiousPressure[LinIdx_I[index.inf.patches.in.fence][in.infect.range]] <-  infectiousPressure[LinIdx_I[index.inf.patches.in.fence][in.infect.range]] +
            numb.susc.boar.in.inf.patches[index.inf.patches.in.fence][in.infect.range] *                                      # this gives the number of susceptible boar in these patches
            numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[col_I[index.inf.patches.in.fence][in.infect.range]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[row_I[index.inf.patches.in.fence][in.infect.range]] - patchcentres_y[row_I[i]])^2))/alpha))
          
          
          
          # Introducing the possibility of an infected patch within the fence to exert infectious pressure on an infected patch outside the fence within max.infection.range/2
          
          # Identify indices of infected patches outside the fence 
          index.inf.patches.outside.fence <- which(!(LinIdx_I %in% patches.in.fence))
          
          
          
          in.infect.range.outside.fence <-  which(usedist::dist_get(dist.patches, LinIdx_I[i],LinIdx_I[index.inf.patches.outside.fence]) <= max.infection.range/2)
          
          
          infectiousPressure[LinIdx_I[index.inf.patches.outside.fence][in.infect.range.outside.fence]] <-  infectiousPressure[LinIdx_I[index.inf.patches.outside.fence][in.infect.range.outside.fence]] +
            numb.susc.boar.in.inf.patches[index.inf.patches.outside.fence][in.infect.range.outside.fence] *                                      # this gives the number of susceptible boar in these patches
            numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[col_I[index.inf.patches.outside.fence][in.infect.range.outside.fence]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[row_I[index.inf.patches.outside.fence][in.infect.range.outside.fence]] - patchcentres_y[row_I[i]])^2))/alpha))
          
          
          
        }else{                                     # if patch is not in fence, infection pressure only exerted on others outside fence
          
          ## Compute infectious pressure on susceptible out-of-fence patches ##
          
          # Identify patches which fall within the infection range
          
          in.infect.range <- which(usedist::dist_get(dist.patches, LinIdx_I[i],sPNotInFence_Idx) <= max.infection.range)  # Indices of susceptible patches which fall within the possible infection range. 
          
          infectiousPressure[sPNotInFence_Idx[in.infect.range]] <- 
            infectiousPressure[sPNotInFence_Idx[in.infect.range]] +              # infection pressure on susceptible WB = (infection pressure on susceptible WB) + number of WB in susceptible patch * number of WB in patch [i,j] + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
            nBoarsMatrix[sPNotInFence_Idx[in.infect.range]] *  numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[suscPatchNotInFence$col[in.infect.range]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[suscPatchNotInFence$row[in.infect.range]] - patchcentres_y[row_I[i]])^2))/alpha))
          
          
          
          # Introducing the possibility of an infected patch outside the fence infecting susceptible patches within the fence within max.infection.range/2
          
          # Identify susceptible patches within the fence which fall within max.infection.range/2 of patch
          in.infect.range.within.fence <-  which(usedist::dist_get(dist.patches, LinIdx_I[i],sPInFence_Idx) <= max.infection.range/2)
          
          infectiousPressure[sPInFence_Idx[in.infect.range.within.fence]] <-
            infectiousPressure[sPInFence_Idx[in.infect.range.within.fence]] +              # infection pressure on susceptible WB = (infection pressure on susceptible WB) + number of WB in susceptible patch * number of infectious WB in infectious patch [i,j] + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively.
            nBoarsMatrix[sPInFence_Idx[in.infect.range.within.fence]] *  numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[suscPatchInFence$col[in.infect.range.within.fence]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[suscPatchInFence$row[in.infect.range.within.fence]] - patchcentres_y[row_I[i]])^2))/alpha))
          
          
          
          
          
          ## Compute infectious pressure on infected out-of-fence patches ##
          
          # Identify indices of infected patches outside fence 
          index.inf.patches.out.fence <- which(!(LinIdx_I %in% patches.in.fence))
          
          # Identify patches which fall within the infection range
          
          in.infect.range <- which(usedist::dist_get(dist.patches, LinIdx_I[i], LinIdx_I[index.inf.patches.out.fence]) <= max.infection.range)
          
          
          infectiousPressure[LinIdx_I[index.inf.patches.out.fence][in.infect.range]] <-  infectiousPressure[LinIdx_I[index.inf.patches.out.fence][in.infect.range]] +
            numb.susc.boar.in.inf.patches[index.inf.patches.out.fence][in.infect.range]* # this gives the number of susceptible boar in these patches
            numb.inf.boar.in.inf.patches[i]*
            (beta*exp(-(sqrt((patchcentres_x[col_I[index.inf.patches.out.fence][in.infect.range]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[row_I[index.inf.patches.out.fence][in.infect.range]] - patchcentres_y[row_I[i]])^2))/alpha))
          
          
          
          # Introducing the possibility of an infected patch outside the fence exerting infectious pressure on infected patches within the fence within max.infection.range/2
          
          # Identify indices of infected patches inside the fence
          index.inf.patches.within.fence <- which(LinIdx_I %in% patches.in.fence)
          
          
          # Identify infected patches within the fence which fall within max.infection.range/2 of patch
          in.infect.range.within.fence <-  which(usedist::dist_get(dist.patches, LinIdx_I[i], LinIdx_I[index.inf.patches.within.fence]) <= max.infection.range/2)
          
          
          infectiousPressure[LinIdx_I[index.inf.patches.within.fence][in.infect.range.within.fence]] <-  infectiousPressure[LinIdx_I[index.inf.patches.within.fence][in.infect.range.within.fence]] +
            numb.susc.boar.in.inf.patches[index.inf.patches.within.fence][in.infect.range.within.fence] *                                      # this gives the number of susceptible boar in these patches
            numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[col_I[index.inf.patches.within.fence][in.infect.range.within.fence]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[row_I[index.inf.patches.within.fence][in.infect.range.within.fence]] - patchcentres_y[row_I[i]])^2))/alpha))
          
          
          
        }
        
      }
      
      
    }else{         # IF LESS THAN DAY 60 OR FENCE = FALSE, COMPUTE PRESSURES 'AS USUAL'
      
      for(i in 1:length(row_I)){
        
        
        # Compute infectious pressure on susceptible patches
        
        # Identify patches which fall within the infection range
        
        in.infect.range <- which(usedist::dist_get(dist.patches, LinIdx_I[i], LinIdx) <= max.infection.range)  # Indices of susceptible patches which fall within the possible infection range. 
        
        
        infectiousPressure[LinIdx[in.infect.range]] <- infectiousPressure[LinIdx[in.infect.range]] +              # infection pressure on susceptible patch = (infection pressure on susceptible patch) + number of susceptible WB in susceptible patch * number of infectious WB in infected patch ([i,j]) + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
          nBoarsMatrix[LinIdx[in.infect.range]] * numb.inf.boar.in.inf.patches[i] * 
          beta*exp(-(sqrt((patchcentres_x[col[in.infect.range]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[row[in.infect.range]] - patchcentres_y[row_I[i]])^2))/alpha)
        
        
        # Compute infectious pressure on infectious patches
        
        # Identify patches which fall within the infection range
        
        in.infect.range <- which(usedist::dist_get(dist.patches, LinIdx_I[i], LinIdx_I) <= max.infection.range)  # Indices of susceptible patches which fall within the possible infection range. 
        
        infectiousPressure[LinIdx_I[in.infect.range]] <- infectiousPressure[LinIdx_I[in.infect.range]] +
          numb.susc.boar.in.inf.patches[in.infect.range] * numb.inf.boar.in.inf.patches[i] *
          (beta*exp(-(sqrt((patchcentres_x[col_I[in.infect.range]] - patchcentres_x[col_I[i]])^2 + (patchcentres_y[row_I[in.infect.range]] - patchcentres_y[row_I[i]])^2))/alpha))
        
        
      }
    }    
    
    ##########################################################################################################
    ##################  DETERMINE NUMBER AND LOCATIONS OF NEW INFECTIONS WITHIN PATCHES #####################
    
    
    ## DETERMINE THE NUMBER OF NEW INFECTIONS IN EACH PATCH ##
    
    newInfect <- simulC(lambda = infectiousPressure)      # for all patches, determine how many boar will become infected using the infectious pressure as a Poisson rate.
    
    
    ## GIVEN NUMBER OF EXPECTED INFECTIONS IN BOAR, CHOOSE THE LOCATION OF BOAR TO INFECT  ##
    
    patches.with.new.inf <- which(newInfect>0)                      # Pick up indices of patches with new infections
    # infectionStatusMatrix[patches.with.new.inf] <- 1                # Update infection status of patch in infection Status Matrix.
    
    # print(timings)
    # print(patches.with.new.inf)
    
    if(length(patches.with.new.inf) != 0){                          # Only calculate if there are no new infections 
      for(j in 1:length(patches.with.new.inf)){
        susc.boar.within.patch.j <- which(updated.boar$patch==patches.with.new.inf[j] & updated.boar$infectionStatus==0)
        
        if(length(susc.boar.within.patch.j) == 1){
          indexInfect.in.patch.j <- susc.boar.within.patch.j
        } else {
          indexInfect.in.patch.j <- sample(x =  susc.boar.within.patch.j, 
                                           size = min(newInfect[patches.with.new.inf][j], length(susc.boar.within.patch.j)),  # Cannot infect more boar than are susceptible in patch.
                                           # prob = prob.susc.boar.within.patch.j,
                                           replace = F)          
        }
        
        # Update infection status and infection date
        locations[locations$index %in% updated.boar[indexInfect.in.patch.j, "index"], c("date.infected")] <-  rep(timings, length(indexInfect.in.patch.j))  # c(rep(0, length(indexInfect.in.patch.j)), rep(timings, length(indexInfect.in.patch.j)))
        # updated.boar[indexInfect.in.patch.j,  "infectionStatus"] <- rep(1, length(indexInfect.in.patch.j))
        updated.boar[indexInfect.in.patch.j,  c("infectionStatus", "date.infected", "date.death.recovery", "date.end.infectious", "date.start.infectious")] <- c(rep(1, length(indexInfect.in.patch.j)), rep(timings, length(indexInfect.in.patch.j)), rep(timings+14, length(indexInfect.in.patch.j)), rep(timings+104, length(indexInfect.in.patch.j)), rep(timings+5, length(indexInfect.in.patch.j)))    #runif(length(indexInfect.in.patch.j), min=44, max=104))) #length(indexInfect.in.patch.j)))
        
        #   if(any(!unique(updated.boar$patch[updated.boar$infectionStatus==1]) %in% which(infectionStatusMatrix==1))){cat(j)}
      }                                                                                                                                
      
    }
    
    
    
    
    ######################################################################################################
    #######################################  DECREASE BOAR POPULATION  ###################################
    
    # For details on this section, see Removals' section in the summary file.
    
    
    
    if(timings <= 204){     ############# WITHIN HUNTING SEASON ###########
      
      
      if(timings <= 120){  ############# INCREASED HUNTING PRESSURE ###########
        
        if(increased.pressure){
          ####################
          ### WITHIN ZONE ###
          ####################
          
          # Compute, as a fraction of the remaining boar, the number of boar to be removed 
          
          # CARCASSES #
          
          carcasses.in.zone <- which(updated.boar$carcass==1 & updated.boar$patch %in% patches.in.zone)
          
          if(length(carcasses.in.zone) == 1){
            found.in.zone <- carcasses.in.zone
          }else{
            found.in.zone <- sample(x = carcasses.in.zone, 
                                    size = min(length(carcasses.in.zone), round(seq.fraction.found.in.zone.increased.pressure[(timings - timings.start)+1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==1)])))) # Using rate from day 60 as AS ceased in zone area from day 60 
          }
          # HUNTED #
          
          toBeHunted <- which(updated.boar$carcass==0 & updated.boar$patch %in% patches.in.zone)
          
          if(length(toBeHunted) == 1){
            hunted.in.zone <- toBeHunted
          }else{
            
            #statustoBeSampled <- updated.boar[toBeHunted, ]$infectionStatus
            # probs <- ifelse(statustoBeSampled == 1,
            #                 0.55, # removals$in.zone.hunted.positive[timings]/removals$in.zone.remaining[timings],
            #                 0.45) 
            hunted.in.zone <- sample(x = toBeHunted,
                                     size = min(length(toBeHunted), round(seq.fraction.hunted.in.zone.increased.pressure[(timings - timings.start) + 1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==1)]))))
                                  #  prob = probs)
          }
          
          
          boar.in.zone.removed <- c(found.in.zone, hunted.in.zone)
          
          
          ## DECREASE NUMBERS WITHIN ZONE ##
          
          nBoarsMatrix[which(in.fence.buffer.matrix==1)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==1)], length(boar.in.zone.removed))
          
          
          ####################
          ### OUTSIDE ZONE ###
          ####################
          
          
          carcasses.out.zone <- which(updated.boar$carcass==1 & !(updated.boar$patch %in% patches.in.zone))
          
          if(length(carcasses.out.zone) == 1){
            found.out.zone <- carcasses.out.zone
          }else{
            found.out.zone <- sample(x = carcasses.out.zone, 
                                     size = min(length(carcasses.out.zone), round(seq.fraction.found.out.zone.increased.pressure[(timings - timings.start)+1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==0)])))) # Using rate from day 60 as AS ceased in zone area from day 60 
          }
          # HUNTED #
          
          toBeHunted <- which(updated.boar$carcass==0 & !(updated.boar$patch %in% patches.in.zone))
          
          if(length(toBeHunted) ==1 ){
            hunted.out.zone <- toBeHunted
          }else{
             hunted.out.zone <- sample(x = toBeHunted,
                                      size = min(length(toBeHunted), round(seq.fraction.hunted.out.zone.increased.pressure[(timings - timings.start) + 1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==0)]))))
          }
          
          
          boar.out.zone.removed <- c(found.out.zone, hunted.out.zone)
          
          
          
          ## DECREASE NUMBERS OUTSIDE ZONE ##
          
          nBoarsMatrix[which(in.fence.buffer.matrix==0)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==0)], length(boar.out.zone.removed))
          
          
          
        }else{ # IF NORMAL HUNTING PRESSURE FROM DAYS 60 TO 120,
          
          
          ####################
          ### WITHIN ZONE ###
          ####################
          
          # Compute, as a fraction of the remaining boar, the number of boar to be removed 
          
          # CARCASSES #
          
          carcasses.in.zone <- which(updated.boar$carcass==1 & (updated.boar$patch %in% patches.in.zone | updated.boar$patch %in% patches.inf.boar.removed))
          if(length(carcasses.in.zone) == 1){
            found.in.zone <- carcasses.in.zone
          }else{
            found.in.zone <- sample(x = carcasses.in.zone, 
                                    size = min(length(carcasses.in.zone), round(seq.fraction.found.in.zone.normal.pressure[(timings - timings.start)+1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==1)]))))# Using rate from day 60 as AS ceased in zone area from day 60 
         
             }
          # HUNTED #
          
          toBeHunted <- which(updated.boar$carcass==0 & updated.boar$patch %in% patches.in.zone)
          
          if(length(toBeHunted) == 1){
            hunted.in.zone <- toBeHunted
          }else{
            # statustoBeSampled <- updated.boar[toBeHunted, ]$infectionStatus
            # probs <- ifelse(statustoBeSampled == 1,
            #                 0.55, # removals$in.zone.hunted.positive[timings]/removals$in.zone.remaining[timings],
            #                 0.45) 
            hunted.in.zone <- sample(x = toBeHunted,
                                     size = min(length(toBeHunted), round(seq.fraction.hunted.in.zone.normal.pressure[(timings - timings.start) + 1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==0)]))))
                                    # prob = probs)
          }
          
          
          boar.in.zone.removed <- c(found.in.zone, hunted.in.zone)
          
          
          ## DECREASE NUMBERS WITHIN ZONE ##
          
          nBoarsMatrix[which(in.fence.buffer.matrix==1)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==1)], length(boar.in.zone.removed))
          
          
          
          ####################
          ### OUTSIDE ZONE ###
          ####################
          
          
          carcasses.out.zone <- which(updated.boar$carcass==1 & (!(updated.boar$patch %in% patches.in.zone) | updated.boar$patch %in% patches.inf.boar.removed))
          
          if(length(carcasses.out.zone) == 1){
            found.out.zone <- carcasses.out.zone
          }else{
            found.out.zone <- sample(x = carcasses.out.zone, 
                                     size = min(length(carcasses.out.zone), round(seq.fraction.found.out.zone.normal.pressure[(timings - timings.start)+1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==0)])))) # Using rate from day 60 as AS ceased in zone area from day 60 
          }
          # HUNTED #
          
          toBeHunted <- which(updated.boar$carcass==0 & !(updated.boar$patch %in% patches.in.zone))
          
          if(length(toBeHunted) ==1 ){
            hunted.out.zone <- toBeHunted
          }else{
 
            hunted.out.zone <- sample(x = toBeHunted,
                                      size = min(length(toBeHunted), round(seq.fraction.hunted.out.zone.normal.pressure[(timings - timings.start) + 1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==0)]))))
          }
          
          
          boar.out.zone.removed <- c(found.out.zone, hunted.out.zone)
          
          
          
          ## DECREASE NUMBERS OUTSIDE ZONE ##
          
          nBoarsMatrix[which(in.fence.buffer.matrix==0)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==0)], length(boar.out.zone.removed))
          
          
          
        }
        
      }else{ ############# NORMAL HUNTING PRESSURE AFTER DAY 120 ########### 
        
          
          ####################
          ### WITHIN ZONE ###
          ####################
          
          # Compute, as a fraction of the remaining boar, the number of boar to be removed 
          
          # CARCASSES #
        
          carcasses.in.zone <- which(updated.boar$carcass==1 & (updated.boar$patch %in% patches.in.zone | updated.boar$patch %in% patches.inf.boar.removed))
          
          if(length(carcasses.in.zone) == 1){
            found.in.zone <- carcasses.in.zone
          }else{
            found.in.zone <- sample(x = carcasses.in.zone, 
                                    size = min(length(carcasses.in.zone), round(seq.fraction.found.in.zone.normal.pressure[(timings - timings.start)+1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==1)])))) # Using rate from day 60 as AS ceased in zone area from day 60 
          }                                                                                                                                                                                             # For normal hunting pressure, maximum observed time is day timings.start-1. 
          # HUNTED #
          
          toBeHunted <- which(updated.boar$carcass==0 & updated.boar$patch %in% patches.in.zone)
          
          if(length(toBeHunted) == 1){
            hunted.in.zone <- toBeHunted
          }else{
            # statustoBeSampled <- updated.boar[toBeHunted, ]$infectionStatus
            # probs <- ifelse(statustoBeSampled == 1,
            #                 0.55, # removals$in.zone.hunted.positive[timings]/removals$in.zone.remaining[timings],
            #                 0.45) 
            hunted.in.zone <- sample(x = toBeHunted,
                                     size = min(length(toBeHunted), round(seq.fraction.hunted.in.zone.normal.pressure[(timings - timings.start)+1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==1)]))))
                                    #prob = probs)
          }
          
          
          boar.in.zone.removed <- c(found.in.zone, hunted.in.zone)
          
          
          ## DECREASE NUMBERS WITHIN ZONE ##
          
          nBoarsMatrix[which(in.fence.buffer.matrix==1)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==1)], length(boar.in.zone.removed))
          
          
          
          
          ####################
          ### OUTSIDE ZONE ###
          ####################
          
          
          carcasses.out.zone <- which(updated.boar$carcass==1 & (!(updated.boar$patch %in% patches.in.zone) | updated.boar$patch %in% patches.inf.boar.removed))
          
          if(length(carcasses.out.zone) == 1){
            found.out.zone <- carcasses.out.zone
          }else{
            found.out.zone <- sample(x = carcasses.out.zone, 
                                     size = min(length(carcasses.out.zone), round(seq.fraction.found.in.zone.normal.pressure[(timings - timings.start)+1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==0)])))) # Using rate from day 60 as AS ceased in zone area from day 60 
          }
          # HUNTED #
          
          toBeHunted <- which(updated.boar$carcass==0 & !(updated.boar$patch %in% patches.in.zone))
          
          if(length(toBeHunted) ==1 ){
            hunted.out.zone <- toBeHunted
          }else{
            hunted.out.zone <- sample(x = toBeHunted,
                                      size = min(length(toBeHunted),  round(seq.fraction.hunted.out.zone.normal.pressure[(timings - timings.start)+1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==0)]))))
            
          }
          
          
          boar.out.zone.removed <- c(found.out.zone, hunted.out.zone)
          
          
          
          ## DECREASE NUMBERS OUTSIDE ZONE ##
          
          nBoarsMatrix[which(in.fence.buffer.matrix==0)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==0)], length(boar.out.zone.removed))
          
        }
        
  
      
      
      ######## END OF HUNTING SEASON ##########  
      
      
    }else{ # At the end of the hunting season, 
      
      # When there is no hunting, we have:
      #  - Passive discoveries and 
      # -  Active search around positive found boar.
      
      
      ####################
      ### WITHIN ZONE ###
      ####################
      
      carcasses.in.zone <- which(updated.boar$carcass==1 & (updated.boar$patch %in% patches.in.zone | updated.boar$patch %in% patches.inf.boar.removed))
      
      if(length(carcasses.in.zone) == 1){
        found.in.zone <- carcasses.in.zone
      }else{
        found.in.zone <- sample(x = carcasses.in.zone, 
                                size = min(length(carcasses.in.zone), round(seq.fraction.found.in.zone.normal.pressure[(timings - 111)+1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==1)])))) # Using rate from day 60 as AS ceased in zone area from day 60 
      }
      
      
      
      boar.in.zone.removed <- c(found.in.zone)
      
      
      ## DECREASE NUMBERS WITHIN ZONE ##
      
      nBoarsMatrix[which(in.fence.buffer.matrix==1)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==1)], length(boar.in.zone.removed))
      
      
      
      
      
      ####################
      ### OUTSIDE ZONE ###
      ####################
      
      
      carcasses.out.zone <- which(updated.boar$carcass==1 & (!(updated.boar$patch %in% patches.in.zone) | updated.boar$patch %in% patches.inf.boar.removed))
      
      if(length(carcasses.out.zone) == 1){
        found.out.zone <- carcasses.out.zone
      }else{
        found.out.zone <- sample(x = carcasses.out.zone, 
                                 size = min(length(carcasses.out.zone), round(seq.fraction.found.out.zone.normal.pressure[(timings - 111)+1]*sum(nBoarsMatrix[which(in.fence.buffer.matrix==0)])))) # Using rate from day 60 as AS ceased in zone area from day 60 
      }
      
      
      
      boar.out.zone.removed <- c(found.out.zone)
      
      
      
      ## DECREASE NUMBERS OUTSIDE ZONE ##
      
      nBoarsMatrix[which(in.fence.buffer.matrix==0)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==0)], length(boar.out.zone.removed))
      
    }
    
    
    
    
    ### STORE INDICES AND PATCHES OF REMOVED BOAR ###
    
    boar.removed <- c(boar.in.zone.removed,
                      boar.out.zone.removed)
    
    # If timings is greater than 120, record the patches in which infectious boar are found, as AS will take place in these areas.  
    
    if(increased.pressure&timings >= 120){
      removed.boar <- updated.boar[boar.removed, ]
      patches.inf.boar.removed <- unique(removed.boar[removed.boar$infectionStatus==1, "patch"])
    }
    
    
    
    if(!(increased.pressure)&timings>=59){
      removed.boar <- updated.boar[boar.removed, ]
      patches.inf.boar.removed <- unique(removed.boar[removed.boar$infectionStatus==1, "patch"])
      
    }
    
    ## RECORD THE REMOVAL DATES OF BOAR ##
    
    locations[locations$index %in% updated.boar[boar.removed, "index"],  "date.removed2"] <- timings
    
    
    
    ## RECORD THE NUMBER OF DETECTED POSITIVE BOAR AMONG REMOVED BOAR ##
    
    if(timings <= 120){ 
      
      if(increased.pressure){# Increased hunting pressure before day 121
        found.out.zone <- length(found.out.zone)   # Number found (not hunted) outside zone by active search (AS) or passive surveillance (PS)
        wildBoarVals[recNumHere] <-  sum(updated.boar$infectionStatus[boar.in.zone.removed] == 1) + (found.out.zone + round((sum(updated.boar$infectionStatus[boar.out.zone.removed] == 1) - found.out.zone)*hunt.test.prop)) # First term: all positive boar removed in zone (100% of hunted tested, all found boar reported); Second term: positive boar removed outside zone (20% of hunted tested)
    
          }else{ # Normal hunting pressure before day 121
        found <- length(c(found.in.zone, found.out.zone))  # Model is set up such that all carcasses are infected. In the data, carcasses are always infected with only a few exceptions on some days (these do not exceed 2 per day) 
        wildBoarVals[recNumHere] <-   found + round((sum(updated.boar$infectionStatus[boar.removed] == 1) - found)*hunt.test.prop)  # expression in bracket is number of hunted positive boar at day 'timings'
      }
      
    }else{ # Normal hunting pressure after day 120
      if(timings<=204){
      
       found <- length(c(found.in.zone, found.out.zone))  # Model is set up such that all carcasses are infected. In the data, carcasses are always infected with only a few exceptions on some days (these do not exceed 2 per day) 
      wildBoarVals[recNumHere] <-   found + round((sum(updated.boar$infectionStatus[boar.removed] == 1) - found)*hunt.test.prop)  # expression in bracket is number of hunted positive boar at day 'timings'
      }else{
        wildBoarVals[recNumHere] <- length(boar.removed)
      }
      
    }
    
    
    ### SHould put in a line saying if boar.removed is empty, skip boar updates
    
    if(length(boar.removed)==0){
      
      updated.boar <- updated.boar
      
      
    }else{
    
    ### UPDATE BOAR NUMBERS ###
    
    
    updated.boar <- updated.boar[-boar.removed, ]
    
    }
    
    
    #####################################################################
    ###############  RECORD AND UPDATE TIME AND COUNTER    ##############
    
    ## Record time 
    
    timeVals[recNumHere] <- timings
    if(verbose){cat('t =', timings, ';' , "W=", sum(wildBoarVals), "\n")}  # Show current time if verbose == TRUE
    
    
    ## Record infection status matrix ##
    patches.with.inf <- unique(updated.boar$patch[updated.boar$infectionStatus==1])
    infectionStatusMatrix[patches.with.inf] <- 1                # Update infection status of patch in infection Status Matrix.
    
    statusEachTimeStep[[recNumHere]] <- infectionStatusMatrix
    
    ##  Update time 
    timings <-  timings + dt 
    
    ## Update counter
    recNumHere <- recNumHere + 1  
    
    
    
    # Update boar statuses at the beginning of day 'timings'.  
    updated.boar$carcass[updated.boar$date.death.recovery==timings] <- 1            # Assuming all infected die
    updated.boar$infectionStatus[updated.boar$date.end.infectious==timings] <- 2   # If last day of infection, assign 2 to infection status ('2' = indicator for 'recovered' and not infectious anymore)
    updated.boar$infectionStatus[updated.boar$date.start.infectious==timings] <- 1
    
    # Record in locations
    
    locations[locations$index %in% updated.boar[updated.boar$date.death.recovery==timings, "index"], "carcass"] <- 1
    locations[locations$index %in% updated.boar[updated.boar$date.start.infectious==timings, "index"], "infectionStatus"] <- 1
    locations[locations$index %in% updated.boar[updated.boar$date.end.infectious==timings, "index"], "infectionStatus"] <- 2
    
    
    
    # Update infection status matrix for next day
    infectionStatusMatrix[!(patch.ids %in% unique(updated.boar$patch[updated.boar$infectionStatus==1]))] <- 0 
    
    
    
  }
  
  
  ###########################                                           ###################################
  ############################# SHOW SIMULATION PROGRESS & ORGANIZE DATA ##################################
  
  
  df <- as_tibble(data.frame("day" = timeVals, "new.cases.wb" = wildBoarVals,  "cumulative.cases.wb" = cumsum(wildBoarVals)))
  # df <- df %>% mutate(new.cases.wb = cumulative.cases.wb - c(0, head(cumulative.cases.wb, -1)))# calculate daily cases from cumulative. 
  
  return(list(summarized.res = df, status.matrices = statusEachTimeStep, locations = locations)) 
  
  
  
  
}


# Implement  multiple cores for forward runs

# While doing forward runs, see SLURM





