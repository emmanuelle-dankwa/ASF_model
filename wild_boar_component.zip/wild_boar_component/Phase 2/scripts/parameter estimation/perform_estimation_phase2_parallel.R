###########################################
# AFRICAN SWINE FEVER MODEL FOR WILD BOAR #
#      ASF CHALLENGE - UK TEAM            #
#                                         #
# PERFORM PARAMETER ESTIMATION AT PHASE 2 #
#          IN PARALLEL MODE               #
###########################################



# Load packages # 
library(parallel)
library(glue)

# Specify directories #
wd.output.data <- "./output-data/"    # Directory for output data 


# Load input data #
source("./scripts/run model/preamble_data_model_phase2.R")                # Loads input data for model and estimation


# Load model #

source("./scripts/run model/model_phase2_wild_boar.R")                    # Loads model function


# Load functions #

source("./scripts/functions/all_functions_phase2.R")  





#### SPECIFY PRIORS  AND TOLERANCE ####


# PRIORS
dat <- list(data.frame(p.low =  c(0.00650),
                       p.upp = c(0.00850)))



# TOLERANCE 
# Summary statistic 1: Daily number of cases 
# Summary statistic 2: Area (in km^2) of minimum convex polygon 
# Summary statistic 3: Cumulative number of cases 
# Summary statistic 4: Cumulative number of cases from day 61 to day 80

tolerance <- data.frame(epsilon_cases = c(65),      # Threshold for summary statistic 1
                        epsilon_area = c(3000),     # Threshold for summary statistic 2
                        epsilon_cumulative = c(100)) # Threshold for summary statistic 3
                       # epsilon_late_count = c(60)) # Threshold for summary statistic 4                                 



### SET UP TO RUN ON MULTIPLE CORES ####
print(paste("Number of cores:", detectCores()))




param_estims_phase2 <- parallel::mclapply(X = dat,  # Replicate, one for each core
                                FUN = run_ABC_rejection_phase2,
                                mc.cores = detectCores(),
                                verbose.val = F,
                                timings.max.val = 80,
                                N = 500)


# Save
# param_estims_phase2 has been saved in the output-data/parameter estimates folder
saveRDS(param_estims_phase2, file = glue::glue(wd.output.data, "param_estims_phase2.RDS"))



