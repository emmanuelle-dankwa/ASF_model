###########################################
# AFRICAN SWINE FEVER MODEL FOR WILD BOAR #
#      ASF CHALLENGE - UK TEAM            #
#                                         #
# PERFORM PARAMETER ESTIMATION AT PHASE 2 #
###########################################



#### SPECIFY PRIORS  AND TOLERANCE ####


# PRIORS
dat <- list(data.frame(p.low =  c(0.0060),
                       p.upp = c(0.0065)))



# TOLERANCE 
# Summary statistic 1: Daily number of cases 
# Summary statistic 2: Area (in km^2) of minimum convex polygon 
# Summary statistic 3: Cumulative number of cases 
# Summary statistic 4: Cumulative number of cases from day 61 to day 80
    
tolerance <- data.frame(epsilon_cases = c(65),      # Threshold for summary statistic 1
                        epsilon_area = c(6000),     # Threshold for summary statistic 2
                        epsilon_cumulative = c(60), # Threshold for summary statistic 3
                        epsilon_late_count = c(60)) # Threshold for summary statistic 4                                 



### SET UP TO RUN ON MULTIPLE CORES ####


### Note: Script was run on a Windows system ###


start.time <- Sys.time()    # Record start time 
no_cores <- parallel::detectCores()    # This assumes 8 logical CPUs in total
cl <- makeCluster(no_cores)
dat <- replicate(no_cores, dat)  # Replicate, one for each core
clusterExport(cl = cl, varlist = ls())
clusterEvalQ(cl = cl,
             {
                 library(Rcpp)
             })
clusterCall(cl, worker.init)
param_estims_phase2 <- parLapply(cl = cl,
                    X= dat,
                    fun = run_ABC_rejection_phase2, 
                    N = 9)         
stopCluster(cl)
end.time <- Sys.time()
time.taken <- end.time - start.time  
time.taken                           # Display total estimation time

# param_estims_phase2 has been saved in the output-data/parameter estimates folder
saveRDS(param_estims_phase2, file = glue::glue(wd.output.data, "param_estims_phase2.RDS"))

# Also, save to relevant pig herd model location (input folders for phases 2 and 3)
saveRDS(param_estims_phase2, file = here::here("ASF_model", "pig_herd_component", "Phase2", "Model_Predict", "input", "param_estims_phase2.RDS")) 
saveRDS(param_estims_phase2, file = here::here("ASF_model", "pig_herd_component", "Phase3", "Model_Predict", "input", "param_estims_phase2.RDS")) 





## ALTERNATIVELY, RUN IN PARALLEL MODE ##

source("~/Phase 2/scripts/parameter estimation/perform_estimation_phase2_parallel.R")

