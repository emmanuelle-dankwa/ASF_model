###########################################
# AFRICAN SWINE FEVER MODEL FOR WILD BOAR #
#      ASF CHALLENGE - UK TEAM            #
#                                         #
#      PREPARE INPUT DATA AT PHASE 2      #
###########################################


## SCRIPT SECTIONS:

# 1. SET UP
# 2. SELECT INITIAL AREA OF FOCUS
# 3. SPECIFY NUMBER OF PATCHES & PATCH BOUNDARIES 
# 4. COMPUTE DIMENSIONS OF AREA OF FOCUS    
# 5. INTERVENTIONS - FENCE & BUFFER
# 6. DETERMINE COORDINATES OF ALL PATCHES AND ADMINISTRATIVE REGION TO WHICH THEY BELONG 
# 7. DETERMINE THE POPULATION SIZE OF EACH PATCH & THE PATCH TO WHICH EACH BOAR BELONGS
# 8. SEED INFECTIONS AT DAY 0
# 9. DETERMINE THE INFECTION STATUS OF PATCHES  BASED ON THE INFECTION STATUS OF BOAR  
# 10. COMPUTE NUMBER OF OBSERVED INFECTIONS AND DETERMINE LOCATIONS 
# 11. REMOVALS OF WILD BOAR BY HUNTING OR SEARCH 
# 12. SAVE OUTPUT DATA



##################################################################
##                            SET UP                            ##
##################################################################


## Import data ##

dataFile <- read.csv(file = glue(wd.output.data, "other/merged_expected_wild_boar_phase2.csv"), header = T, sep = ",")  # Load observed and simulated boar locations; # "merged_expected_wild_boar_phase2.csv" created in data-prep-1-phase2.Rmd script
sizeData <- dim(dataFile)                                     # (by day 0 = day 36 of hunting season; see "data-prep-1-phase2.Rmd"); must be equal to sum(hunting_bag$expected.remaining)
dataFile$status[which(is.na(dataFile$status))] <- "Unknown"   # Replace all NA statuses to unknown


## Setting up required variables.... ##

nBoar <- sizeData[1]                                             # Number of boar (both observed and simulated)
locations <- dataFile[, -6]                                      # Object for storing WB locations, date of suspicion, mode of detection and whether the data point is observed or simulated.
locations$infectionStatus <- numeric(nBoar)                      # Vector for storing infection status of boar, as determined by the model. First few infections are based on observed data. 
locations$infectionStatus[dataFile$status=="Positive"] <- 1      # At infected WB locations, assign '1' 
names(locations)[which(names(locations) == "date")] <- "date.removed"    # Rename "date" column to "date.removed". Hunted or detected wild boar (by passive surveillance or active search) are immediately removed once hunted or detected. 










##################################################################
##                  SELECT INITIAL AREA OF FOCUS               ##
##################################################################

# First, restrict attention to only central part of map (the part near infected wild boar),
# to make infection pressure calculations quicker (because fewer susceptible boar)


 minx = 7.25*(10^5)
 maxx = 8.5*(10^5)
 miny = 6.3*(10^6)
 maxy = 6.45*(10^6)


 
 ### DROP BOARS OUTSIDE DEFINED BOUNDARIES ###
 
 
 whichToDelete <- which(locations$X < minx 
                        | locations$X > maxx 
                        | locations$Y < miny 
                        | locations$Y > maxy)          # Identify WB locations 'far' from initial (detected) infected area
locations <- locations[-whichToDelete, ]               # Exclude these from WB location and infection matrices
 nBoar <- nrow(locations)                              # Update number of wild boar locations 
 
 
 
 
 
 ##################################################################
 ##        SPECIFY NUMBER OF PATCHES & PATCH BOUNDARIES         ##
 ##################################################################
 
 # Specify number of patches and patch boundaries
 
 npatches_x <- 50                                               # this is number of patches in x-direction
 npatches_y <- 50                                               # this is number of patches in y-direction
 patchboundaries_x <- seq(minx, maxx, by=(maxx - minx)/npatches_x)
 patchboundaries_y <- seq(miny,  maxy, by= (maxy - miny)/npatches_y)
 
 
 # Compute patch centers in x and y directions. 
 
 patchcentres_x <- numeric(length(patchboundaries_x) - 1)             # vector to store x coordinates of patch centers
 patchcentres_y <- numeric(length(patchboundaries_y) - 1)             # vector to store y coordinates of patch centers
 
 for(i in 1:(length(patchboundaries_y) - 1)){
   patchcentres_y[i] = (patchboundaries_y[i] + patchboundaries_y[i + 1])/2
   patchcentres_x[i] <- (patchboundaries_x[i] + patchboundaries_x[i + 1])/2
 }
 
 patchcentres <- data.frame(X = patchcentres_x, Y= patchcentres_y)
 nrow(patchcentres)
 
 
 # Determine coordinates of ALL patches (npatches_x * n_patches_y in number)
 
 all.patch.centres <- tidyr::crossing(X = patchcentres$X, Y = patchcentres$Y) 
 
 
 
 
 ##################################################################
 ##               COMPUTE DIMENSIONS OF AREA OF FOCUS            ##
 ##################################################################
 
 # UNCOMMENT CODE BELOW TO COMPUTE DIMENSIONS OF MARKED OUT AREA #
 
# ### TOTAL AREA & PERIMETER ###
#  
#  ## Total area ##
#  # Method 1  (Use formula for area of a rectangle)
#  section.area <- ((maxx- minx)*(maxy-miny))/1000000  # divide by 1000000 for km2
#  
#  # Method 2 (Use pracma package)
#  area.of.section <-  pracma::polyarea(x = c(minx, maxx, maxx, minx), y = c(miny, miny, maxy, maxy))/1000000 # in km^2
#  
#  ## Check that 
#  section.area == area.of.section
#  
#  
#  ## Total perimeter ##
#  # Method 1 (Use formula)
#  section.perimeter <- 2*((maxx-minx)+ (maxy-miny))/1000
#  
#  
#  # Method 2 (Use package)
#  perimeter.of.section <- spatstat::perimeter(as.owin(W = c(xmin = minx , xmax = maxx, ymin = miny,  ymax = maxy)))/1000 # in km
#  
#  ## Check that 
#  section.perimeter == perimeter.of.section
#  
#  
# # View
# section.area;section.perimeter
#  
#  
#  
#  ### PATCH AREA & PERIMETER ###
#  
#  
#  ## Patch area ##
#  #  Method 1 (Use formula)
#  dist.in.x.direction <- (patchcentres$X[2] - patchcentres$X[1])
#  dist.in.y.direction <- (patchcentres$Y[2] - patchcentres$Y[1])
#  patch.area <- (dist.in.x.direction*dist.in.y.direction)/1000000   # in km^2
#  
#  # Method 2 (Divide total area by number of patches)
#  area.of.patch = area.of.section/(npatches_x*npatches_y)
#  
#  ## Check that
#  patch.area == area.of.patch
#  
#  
#  ## Patch perimeter ## 
#  # Method 1 (Use formula)
#  patch.perimeter <- 2*((patchcentres$X[2]-patchcentres$X[1]) + (patchcentres$Y[2] - patchcentres$Y[1])) /1000 # in km
#  
#  # Method 2 (Use package)
#  perimeter.of.patch <- spatstat::perimeter(as.owin(W = c(xmin =patchcentres$X[1]  , xmax =patchcentres$X[2] , ymin = patchcentres$Y[1] ,  ymax = patchcentres$Y[2] )))/1000 # in km 
#  
#  ## Check that 
#  patch.perimeter == perimeter.of.patch
#  
#  
#  # View
#  
#  patch.area; patch.perimeter
#  
#  # Print results
#  cat("Section area:", section.area, "km2",  "\n", 
#      "Section perimeter:", section.perimeter, "km", "\n",
#      "\n",
#      "Number of patches:", npatches_x*npatches_y, "\n",
#      "\n",
#      "Area per patch:", patch.area, "km2", "\n",
#      "Perimeter per patch:", patch.perimeter, "km", "\n",
#      "\n",
#      "Length in x-direction (section):",(maxx - minx)/1000, "km", "\n",
#      "Length in y-direction (section):",(maxy - miny)/1000, "km", "\n", 
#      "\n",
#      "Length in x-direction (patch):",(patchcentres$X[2]-patchcentres$X[1])/1000, "km", "\n",
#      "Length in y-direction (patch):",(patchcentres$Y[2]-patchcentres$Y[1])/1000, "km", "\n"
#       )
#  
#  






 
 
 
 
 
 
 
 ##################################################################
 ##               INTERVENTIONS - FENCE & BUFFER                ##
 ##################################################################
 
 # Determine patches that fall within fence (for reference for coordinates, see Phase 1 update document from Island officials)
 
 A <- c(773676.4, 6347189)
 B <- c(833676.4, 6347189)
 C <- c(833676.4, 6437189)
 D <- c(773676.4, 6437189)
 
 fence.coordinates <- data.frame(id = LETTERS[1:4], 
                                 X = c(A[1], B[1], C[1], D[1]),
                                 Y = c(A[2], B[2], C[2], D[2]))
 
 
 # Update fenced area to include 15 km buffer
 
 buffer.width <- 15000    # in meters
 
 A1 <- c(773676.4-buffer.width, 6347189-buffer.width)
 B1 <- c(833676.4+buffer.width, 6347189-buffer.width)
 C1 <- c(833676.4+buffer.width, 6437189+buffer.width)
 D1 <- c(773676.4-buffer.width, 6437189+buffer.width)
 
 
 zone.coordinates <- data.frame(id = LETTERS[1:4], 
                                X = c(A1[1], B1[1], C1[1], D1[1]),
                                Y = c(A1[2], B1[2], C1[2], D1[2]))
 
 
 
 ## CHECKS ##
 
 # # plot(zone.coordinates$X, zone.coordinates$Y)
 # # points(fence.coordinates$X, fence.coordinates$Y, col = "red")
 # 
 # # fence.area <- pracma::polyarea(fence.coordinates$X, fence.coordinates$Y) # 5400km^2
 # # buffer.fence.area <- pracma::polyarea(zone.coordinates$X, zone.coordinates$Y) # 10800 km^2
 # #
 # # # Perimeters
 # #
 # # ## fence.area
 # # spatstat::perimeter(as.owin(W = c(xmin = A[1] , xmax = B[1], ymin = A[2],  ymax = C[2]))) # 3e+05 m = 300 km
 # #
 # # ## buffer.fence.area
 # # spatstat::perimeter(as.owin(W = c(xmin = A1[1] , xmax = B1[1], ymin = A1[2],  ymax = C1[2]))) # 420km

 ###
 
 
 
 # Determine responses to "Is patch i in fence or buffer"?
 
 in.fence.buffer <- sp::point.in.polygon(point.x = all.patch.centres$X, point.y= all.patch.centres$Y,
                                         pol.x = zone.coordinates$X, pol.y = zone.coordinates$Y)
 
 in.fence.buffer.matrix <- matrix(in.fence.buffer, nrow = npatches_x, ncol = npatches_y)
 
 
 in.fence <- sp::point.in.polygon(point.x = all.patch.centres$X, point.y= all.patch.centres$Y,
                                  pol.x = fence.coordinates$X, pol.y = fence.coordinates$Y)
 
 in.fence.matrix <- matrix(in.fence, nrow = npatches_x, ncol = npatches_y)
 
 
 
 
 
 
 
#############################################################################################
##  DETERMINE COORDINATES OF ALL PATCHES AND ADMINISTRATIVE REGION TO WHICH THEY BELONG  ##
#############################################################################################

# Determine the administrative regions to which patches belong. (Patches are characterized only by the coordinates of their centers.)

merry_shp2 <- st_read(glue(wd.raw.data, "Island_ADMIN.shp"))           # Read shape file 
bps2 <- st_as_sf(all.patch.centres, coords = c("X", "Y"), 
                 crs = "+proj=lcc +lat_0=46.5 +lon_0=3 +lat_1=44 +lat_2=49 +x_0=700000 +y_0=6600000 +ellps=GRS80 +units=m +no_defs")

bps2_trans <- st_transform(bps2, crs = "+proj=lcc +lat_0=46.5 +lon_0=3 +lat_1=44 +lat_2=49 +x_0=700000 +y_0=6600000 +ellps=GRS80 +units=m +no_defs")
MS2_trans <- st_as_sf(merry_shp2)
MS2_trans <- st_transform(MS2_trans,  crs = "+proj=lcc +lat_0=46.5 +lon_0=3 +lat_1=44 +lat_2=49 +x_0=700000 +y_0=6600000 +ellps=GRS80 +units=m +no_defs")


# Join
boar_per_area <- st_join(bps2_trans, MS2_trans, join = st_intersects)

table(boar_per_area$ID)

all.patch.centres[,"region"] <- boar_per_area$ID

table(all.patch.centres$region)


### Sort out NA regions ###

## There are some patches that are not assigned a region because these fall outside the island borders
no_region <- all.patch.centres[which(is.na(all.patch.centres$region)),] # There are 91 == nrow(no_region) of those.

## Make a coordinate object from these data
coord_no_region_df <- no_region[,c("X","Y")]

## Make into a spatialpointsdataframe with crs matching the above

no_region_spdf <- SpatialPointsDataFrame(coords = coord_no_region_df, data = no_region,
                                         proj4string = CRS("+proj=lcc +lat_0=46.5 +lon_0=3 +lat_1=44 +lat_2=49 +x_0=700000 +y_0=6600000 +ellps=GRS80 +units=m +no_defs"))

no_region <- data.frame(X = no_region_spdf$X, Y = no_region_spdf$Y)


###CHECKS ###
## Determine number of wild boar in unassigned regions ##

# nboar <- c()
# for(i in 1:nrow(no_region)){
# 
#   x_ind <-  which(patchcentres$X==no_region$X[i])
#   y_ind <- which(patchcentres$Y==no_region$Y[i])
# 
#   nboar[i] <- nBoarsMatrix[x_ind, y_ind]
# 
# }

####

## Assign the boar to the nearest polygon 

n <- length(no_region_spdf)
nearestpolygon <- character(n)
distToNearestpolygon <- numeric(n)


for (i in seq_along(nearestpolygon)) {
  gDists <- gDistance(no_region_spdf[i,], merry_shp, byid=TRUE)
  nearestpolygon[i] <- merry_shp$ID[which.min(gDists)]
  distToNearestpolygon[i] <- min(gDists)
}


## Assign these to the table

no_region$region <- nearestpolygon


## Now add to the original data; patch centres with administrative regions

all.patch.centres <- left_join(all.patch.centres, no_region, by = c( "X", "Y"))%>% 
      mutate(region=coalesce(region.x, region.y)) %>%
      dplyr::select(-region.x, -region.y)


# Check that there are no NA values
sum(is.na(all.patch.centres$region))==0 # should be TRUE
table(all.patch.centres$region)         # all patches

all.patch.centres$number.of.boar <- numeric(nrow(all.patch.centres))
all.patch.centres$patch.id <- 1:2500




########################################################################################
## DETERMINE THE POPULATION SIZE OF EACH PATCH & THE PATCH TO WHICH EACH BOAR BELONGS ##
#######################################################################################


# Compute number of wild boar in each patch 
# Determine the patch of each wild boar in locations matrix

nBoarsMatrix <- matrix(0, nrow=npatches_x, ncol=npatches_y)          # Allocate matrix for number of boars in each patch
infectionStatusMatrix <- matrix(0, nrow=npatches_x, ncol=npatches_y) # Allocate matrix for infection status

locations$patch <- rep(0, nBoar)                                     #  Column for storing the patch number for each boar
locations$region <- rep(0, nBoar)                                    #  Column for storing the region ID for each boar
locations$index <- 1:nrow(locations)                                 #  Assign indices to boar
locations$date.infected <- rep(0, nrow(locations))                   #  Column for storing infection dates 


for (i in 1:(length(patchboundaries_x) - 1)){
  for(j in 1:(length(patchboundaries_y) -1)){
    whichOnes <- which((locations$X >= patchboundaries_x[i]) & (locations$X < patchboundaries_x[i+1]) &  # capture indices of wild boar locations in each patch
                         (locations$Y >= patchboundaries_y[j]) & (locations$Y < patchboundaries_y[j+1]))
    # Identify patch to which each boar belongs
    
    patch.number <- which(all.patch.centres$X==patchcentres_x[i] & all.patch.centres$Y==patchcentres_y[j])
    
    # Assign patch.number and region to rows corresponding to wild boar locations which fall within the patch
    
    locations[whichOnes, "patch"] <- patch.number
    locations[whichOnes, "region"] <- all.patch.centres[patch.number, "region"]$region
    
    # Count the number of boars in patch
    nBoarsMatrix[patch.number] <- length(whichOnes)                          # Save number of wild boars in patch
    
  }
}



#############################################################################
##                       SEED INFECTIONS AT DAY 0                          ##
#############################################################################



# We assume that positive wild boar detected from day 1 to day 8 were infectious at day 1
locations[!(locations$date<8 & locations$status=="Positive"), "infectionStatus" ] <- 0    # Aside boar detected from days 0 to day 8, set infection status for all boar to 0 (negative). 

# Also, assign positive status to x simulated boar, where x = 4 * (number of observed positive boar hunted from day 1 to 59)
a <- locations[(locations$date<=59 & locations$infectionStatus==1),  ] 
set.to.positive <- sample(x = which(is.na(locations$det) & locations$patch %in% unique(a$patch)), size = 4*nrow(a), replace = F) # Unobserved infected boar should be in the same or neighbouring patches 

locations[set.to.positive, "infectionStatus"] <- 1                                                            # Unobserved positive boar 
locations[set.to.positive, "date.removed"] <- sample(x = rep(a$date,4), size = length(set.to.positive), replace = F)  # Assign date as observed 
locations[set.to.positive, "date.infected"] <- 1 # Assume that first few positive boar were infected on day 1

locations$date.removed2 <- 0                     # Create column for saving observed removal dates in the model simulations 
locations$date.removed2[locations$date.infected != 0] <- round(runif(20, min = 6, max = 14)) # Assign removal dates to seed (i.e., initial positive boar)







######################################################################################################
##          DETERMINE THE INFECTION STATUS OF PATCHES  BASED ON THE INFECTION STATUS OF BOAR        ##
######################################################################################################


##  Determine infection status of patch (at day 0) ##
for (i in 1:(length(patchboundaries_x) - 1)){
  for(j in 1:(length(patchboundaries_y) -1)){
    whichOnes <- which((locations$X >= patchboundaries_x[i]) & (locations$X < patchboundaries_x[i+1]) &  # capture indices of wild boar locations in each patch
                         (locations$Y >= patchboundaries_y[j]) & (locations$Y < patchboundaries_y[j+1]))
    
    # Identify patch to which each boar belongs
    
    patch.number <- which(all.patch.centres$X==patchcentres_x[i] & all.patch.centres$Y==patchcentres_y[j])
    
    if(length(which(locations$infectionStatus[whichOnes] == 1)) > 0){                 # Determine state of infection of WB in the patch
      infectionStatusMatrix[patch.number] <- 1                                        # Entire patch is infectious if at least one wild boar in the patch is
    }
    
  }}






##################################################################
## COMPUTE NUMBER OF OBSERVED INFECTIONS AND DETERMINE LOCATIONS ##
##################################################################

# Organize daily counts of observed positive/negative wild boar:


daily.counts <- table(dataFile$date, dataFile$status) # No counts for 'Unknown' category because no dates provided 
observed.negative <- data.frame("day" = c(1:nrow(daily.counts)), "count" = daily.counts[,1])  # negative counts
observed.positive <- data.frame("day" = c(1:nrow(daily.counts)), "count" = daily.counts[,2])  # positive counts

# Check that 

sum(observed.positive$count) == sum(397, 1610) # must be TRUE. 397 from days 1-50; 
                                                    # 1610 new wild boar from days 51-80; 
                                                    # Total 2007 by day 80; see Update files from organizers
                                                    # (number of positive detected wild boar by day 80)


## Track locations of infected boar from day 1 to day 80
## Compile locations into a list for each day

observed.positive.locations <- list()

for(i in c(1:max(dataFile$date, na.rm = TRUE))){
  j <- which(c(1:max(dataFile$date, na.rm = TRUE)) == i)
  observed.positive.locations[[j]] <- dataFile[which(dataFile$status=="Positive" & dataFile$date==i) , c("X", "Y")]
  if(j>=2){
    observed.positive.locations[[j]] <- rbind(observed.positive.locations[[j-1]], observed.positive.locations[[j]])
  }
}




##################################################################
  ##    REMOVALS OF WILD BOAR BY HUNTING OR SEARCH             ##
##################################################################



## WITHIN ZONE ##


## In this section, we compute the number of boar hunted each day within the fence-buffer (zone) 
## To do this, we use observed search and hunting data. 
## For hunting data, multiply by 5 if timings <= 59 or if timings >= 60 and outside the zone, else treat as observed (before day 60, only 20% of hunted boar are tested; 
##                                                                          thereafter, all boar found/removed in the zone were tested while 20% testing continued outside the zone)

## All found boar (by active search (AS) or passive surveillance (PS)) were tested so we use figures on found boar as reported. 


## Hunted ##

timings.max <- 80   # or max(locations$date.removed, na.rm = T)
nboar.in.zone.hunted.each.day.vec <- c()
for (i in 1:timings.max){                   # 61 corresponds to day after fence was implemented
  nboar.in.zone.hunted.each.day.vec[i] <- (nrow(locations[which((locations$patch %in% c(which(in.fence.buffer.matrix==1))) & (locations$date.removed == i) & (locations$det %in% c("PT", "NT"))),  ])) 
  
}

nboar.in.zone.hunted.each.day.vec <- nboar.in.zone.hunted.each.day.vec * c(rep(5, 59), rep(1, timings.max - 59))




## Found (AS or PS) ##

nboar.in.zone.found.each.day.vec <- c()
for (i in 1:timings.max){                   # 61 corresponds to day after fence was implemented
  nboar.in.zone.found.each.day.vec[i] <- nrow(locations[which((locations$patch %in% c(which(in.fence.buffer.matrix==1))) & (locations$date.removed == i) & (locations$det %in% c("PS", "AS", "NAS"))),  ])
  
}



# Positive - found #

nboar.in.zone.found.positive.vec <- c()
for (i in 1:timings.max){                   # 61 corresponds to day after fence was implemented
  nboar.in.zone.found.positive.vec[i] <- nrow(locations[which((locations$patch %in% c(which(in.fence.buffer.matrix==1))) & (locations$date.removed == i) & (locations$det %in% c("PS", "AS"))),  ])
}

# nboar.in.zone.found.each.day.vec - nboar.in.zone.found.positive.vec # The results show that the majority of carcasses found within the zone were positive.






##  OUTSIDE ZONE   ##


## In this section, we compute the number of boar hunted each day outside the fence-buffer
## To do this, we use observed search and hunting data. 
## For hunting data, multiply by 5 (outside the zone, only 20% of hunted boar are tested)
## Use active search and passive surveillance figures as observed


## Hunted ##

nboar.out.zone.hunted.each.day.vec <- c()
for (i in 1:timings.max){
  nboar.out.zone.hunted.each.day.vec[i] <- 5*(nrow(locations[which((locations$patch %in% c(which(in.fence.buffer.matrix==0))) & (locations$date.removed == i) & (locations$det %in% c("PT", "NT"))),  ])) 
  
}


## Found (AS or PS) ##

nboar.out.zone.found.each.day.vec <- c()
for (i in 1:timings.max){                   # 61 corresponds to day after fence was implemented
  nboar.out.zone.found.each.day.vec[i] <- nrow(locations[which((locations$patch %in% c(which(in.fence.buffer.matrix==0))) & (locations$date.removed == i) & (locations$det %in% c("AS", "NAS", "PS"))),  ])
  
}





## ORGANIZE INTO DATA FRAME ##


# Combine removals into one object

removals <- data.frame(in.zone = nboar.in.zone.hunted.each.day.vec+nboar.in.zone.found.each.day.vec,
                       in.zone.found =  nboar.in.zone.found.each.day.vec,
                       in.zone.hunted = nboar.in.zone.hunted.each.day.vec,
                       out.zone = nboar.out.zone.hunted.each.day.vec +nboar.out.zone.found.each.day.vec,
                       out.zone.found = nboar.out.zone.found.each.day.vec,
                       out.zone.hunted =  nboar.out.zone.hunted.each.day.vec,
                       total = nboar.in.zone.hunted.each.day.vec+nboar.in.zone.found.each.day.vec
                       +nboar.out.zone.hunted.each.day.vec +nboar.out.zone.found.each.day.vec)





# Total removed by day 80: 
sum(removals$total)
# [1] 25572
# Total removed in zone
sum(removals$in.zone)
# [1] 19567
# Total removed out zone
sum(removals$out.zone)
# [1] 6005





##################################################################
##                  SAVE OUTPUT DATA                           ##
##################################################################


## USED DIRECTLY IN THE ANALYSIS ##

saveRDS(patchcentres, file = glue(wd.output.data, "model input/patchcentres.RDS"))                     # Patch centres in X and Y directions
saveRDS(infectionStatusMatrix, file = glue(wd.output.data, "model input/infectionStatusMatrix.RDS")) # Infection status of patches
saveRDS(nBoarsMatrix, file = glue(wd.output.data, "model input/nBoarsMatrix.RDS"))                   # Number of wild boar per patch
saveRDS(locations, file = glue(wd.output.data, "model input/locations.RDS"))                       # Data on wild boar remaining in landscape by day 0
saveRDS(all.patch.centres, file = glue(wd.output.data, "model input/all.patch.centres.RDS"))         # Coordinates of all patch centres
saveRDS(observed.positive,  file = glue(wd.output.data, "model input/observed.positive.RDS") )       # Daily observed count of positive wild boar
saveRDS(observed.positive.locations,  file = glue(wd.output.data, "model input/observed.positive.locations.RDS") )       # Daily observed count of positive wild boar
saveRDS(in.fence.buffer.matrix, file = glue(wd.output.data, "model input/in.fence.buffer.matrix.RDS")) # Indicator matrix showing whether patch is in fence-buffer zone
saveRDS(in.fence.matrix, file = glue(wd.output.data, "model input/in.fence.matrix.RDS"))             # Indicator matrix showing whether patch is in fence
saveRDS(removals, file = glue(wd.output.data, "model input/removals.RDS"))                           # Daily observed removals



## OTHER (NOT USED DIRECTLY IN MODEL) ##

saveRDS(observed.negative, file = glue(wd.output.data, "other/observed.negative.RDS"))         # Daily observed count of negative wild boar 

# SAVE RELEVANT DATA TO PIG HERD MODEL LOCATION
saveRDS(patchcentres, file = here::here("ASF_model", "pig_herd_component", "Phase2", "Model_Predict", "input", "patchcentres.RDS")) 

