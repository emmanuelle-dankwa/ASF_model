### PREAMBLE ####
### THIS SCRIPT CONTAINS CODE FOR 
## IMPLEMENTING A TRANSMISSION MODEL FOR WILD BOAR ###

## ASF CHALLENGE, PHASE 2 - UK TEAM ###


# See model script, model_phase_2_wild_boar.R, for details on function arguments.

sample_model_output_phase2 <- model_phase2(beta = 0.006,             # chosen as mean of prior estimation interval 
                                    alpha = 870,                      # fixed alpha 
                                    timings = 1,                       # first day  
                                    timings.max = 80,                  # last day of observation
                                    verbose = T)                       # print simulation progress




# Save output
# sample_model_output.RDS already exists in the output-data folder
# Uncomment code below if you would like to save new version.

# saveRDS(sample_model_output_phase2, file = glue::glue(wd.output.data, "model output/sample_model_output_phase2.RDS")) 



