### THIS SCRIPT CONTAINS CODE FOR PREDICTIONS FOR A TRANSMISSION MODEL FOR WILD BOAR #### 
### ASF CHALLENGE, PHASE 2 - UK TEAM  ###


##### FUNCTION FOR RUNNING SIMULATIONS UNDER VARIOUS SCENARIOS #####

## Arguments ##

# beta:               Transmission rate
# alpha:              Spatial scale
# hunt.test.prop:     Proportion of hunted boar that are tested in a "normal hunting pressure" scenario. 
# timings:            First day for simulation
# timings.max:        Last day of simulation
# increased pressure: Increased hunting pressure?
# forward simulation: Does model simulation include unobserved days?
# verbose:            Print simulation progress?     
# fence:              Has fence been implemented?

## Other inputs: see 'preamble_data_model_phase2.R' 



# 2 scenarios:

# Fence + normal hunting pressure: forward simulation starts at day 60 ( i.e. take the infection status matrix, nBoarsMatrix and locations at day 59)
# Fence + increased hunting pressure: forward simulation starts at day 81 ( i.e. take the infection status matrix, nBoarsMatrix and locations at day 80)
## Checks in place to ensure timings match the scenario being assessed. 


prediction_model_phase2 <- function(beta, 
                                alpha = 870,
                                hunt.test.prop = 0.2,
                                timings.max, 
                                dt=1, 
                                fence = TRUE, 
                                increased.pressure=TRUE,
                                forward.simulation = FALSE,
                                timings = 1,
                                verbose = F,
                                locations,
                                infectionStatusMatrix,
                                nBoarsMatrix,
                                normal.pressure.reference.date = 60){ 
  
  ##########################################################################################################
  ##########################################################################################################
  
  ## Input Quality Checks ##
  if(increased.pressure & !fence){
    stop("Increased pressure can only be implemented within fence. Set 'fence' to TRUE.")
  }
  
  # if(forward.simulation & increased.pressure & timings != 81){
  #   stop("The model is set up to begin forward simulation under increased hunting pressure at day 81. Set 'timings' to 81.")
  # }
  
  # if(forward.simulation & !increased.pressure & timings != 60){
  #   stop("The model is set up to begin forward simulation under normal hunting pressure at day 60. Set 'timings' to 60.")
  # }
  
  if(timings > timings.max){
    stop("Start date ('timings') must be less than end date ('timings.max')")  
  }
  
  
  ## Define VALUES ##:
  
  npatches_x <- npatches_y <-  nrow(patchcentres)
  patchcentres_x <- patchcentres$X
  patchcentres_y <- patchcentres$Y
  patch.ids <- c(1:2500)
  
  timeVals <- c() # Empty vector for storing event times
  wildBoarVals <- c()  # Number of infected wild boar
  recNumHere <- 1
  statusEachTimeStep <- list()
  patches.in.fence <- which(in.fence.matrix==1)         # patches in fence 
  patches.in.zone <- which(in.fence.buffer.matrix==1)   # patches in fence-buffer (zone)
  
  
  ##########################################################################################################
  ##########################################################################################################
  
  # If increased pressure, remove from updated.boar all boar with date.removed less than or equal to day 80, since updated.boar has boar up to the current time so we can't have in there boar removed in the past (that's why we remove all boar with removal dates in the past (earlier than day 80 [for increased pressure] or day 60 [for normal pressure])
  # If normal pressure, remove all boar with date.removed less than or equal to day 59, since updated.boar has boar up to the current time
  if(increased.pressure){
    updated.boar <- locations[-which(locations$date.removed2 <= 80 & locations$date.removed2 != 0), ]
  }else{
    updated.boar <- locations[-which((locations$date.removed2 <= normal.pressure.reference.date - 1 & locations$date.removed2 != 0)), ] # nprf = 60
    updated.boar$infectionStatus[updated.boar$date.infected>=normal.pressure.reference.date] <- 0 # nprf = 60 # Reset all infection statuses that have infection dates on day 60 and beyond, as we have not yet observed these under this scenario. 
    updated.boar$date.removed2[updated.boar$date.removed2>=normal.pressure.reference.date] <- 0 # nprf = 60 Reset all removal dates that are day 60 and beyond, as these have not yet been observed under this scenario.  
  }
  
  while(sum(infectionStatusMatrix==1) > 0 & timings <= timings.max){
    
    
    ##########################################################################################################
    ##########################################################################################################
    
    ## WORK OUT INFECTIOUS PRESSURE ON EACH PATCH ##
    
    infectiousPressure <- double(npatches_x*npatches_y)                            # matrix for storing values for infectious pressure on WB
    
    row_I <- as.data.frame(which(infectionStatusMatrix == 1, arr.ind = TRUE))$row  # save row indices for infected patches 
    col_I <- as.data.frame(which(infectionStatusMatrix == 1, arr.ind = TRUE))$col  # save column indices for infected patches 
    
    row <- as.data.frame(which(infectionStatusMatrix == 0, arr.ind = TRUE))$row   # save row indices  for susceptible patches
    col <- as.data.frame(which(infectionStatusMatrix == 0, arr.ind = TRUE))$col   # save column indices for susceptible patches
    
    LinIdx <- (col-1)* nrow(infectionStatusMatrix) + row                         # matrix indices of susceptible patches
    LinIdx_I <- (col_I-1)* nrow(infectionStatusMatrix) + row_I                   # matrix indices of infected patches (a patch is infectious if it has at least one infectious boar)
    
    # Identify susceptible patch position in relation to fence
    suscPatchInFence <- data.frame(which(in.fence.matrix==1 & infectionStatusMatrix==0, arr.ind = TRUE))
    suscPatchNotInFence <- data.frame(which(in.fence.matrix==0 & infectionStatusMatrix==0, arr.ind = TRUE)) 
    
    
    
    numb.inf.boar.in.inf.patches <- numbboarstateC(LinIdx_I = LinIdx_I, updatedboar = updated.boar, fn = id, marker = 1)
    numb.susc.boar.in.inf.patches <- numbboarstateC(LinIdx_I = LinIdx_I, updatedboar = updated.boar, fn = id, marker = 0)
    
    
    ##########################################################################################################
    ########################################## PATCH-LEVEL INFECTION PRESSURE ################################
    
    
    if(fence&timings>=60){     # IMPLEMENT FENCE FROM DAY 60
      
      for(i in 1:length(row_I)){ # for all infectious patches,
        
        # If infectious patch is in fence,
        if(in.fence.matrix[row_I[i], col_I[i]]==1){ # if infected patch is in fence, infection pressure only exerted on others in fence and received by others in fence 
          
          ## Compute infectious pressure on susceptible within-fence patches ##
          
          infectiousPressure[(suscPatchInFence$col-1)*npatches_x + suscPatchInFence$row] <- 
            infectiousPressure[(suscPatchInFence$col-1)*npatches_x + suscPatchInFence$row] +              # infection pressure on susceptible WB = (infection pressure on susceptible WB) + number of WB in susceptible patch * number of infectious WB in infectious patch [i,j] + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
            nBoarsMatrix[(suscPatchInFence$col-1)*npatches_x + suscPatchInFence$row] *  numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[suscPatchInFence$row] - patchcentres_x[row_I[i]])^2 + (patchcentres_y[suscPatchInFence$col] - patchcentres_y[col_I[i]])^2))/alpha))
          
          
          ## Compute infectious pressure on infected within-fence patches ##
          
          
          # # Identify indices of infected patches in fence (This may include patch j itself; future version - exclude patch j and calculate pressures on patch j according to the distances between infectious boar and susceptible boar)
          index.inf.patches.in.fence <- which(LinIdx_I %in% patches.in.fence)
          
          
          infectiousPressure[LinIdx_I[index.inf.patches.in.fence]] <-  infectiousPressure[LinIdx_I[index.inf.patches.in.fence]] +
            numb.susc.boar.in.inf.patches[index.inf.patches.in.fence] *                                      # this gives the number of susceptible boar in these patches
            numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[row_I[index.inf.patches.in.fence]] - patchcentres_x[row_I[i]])^2 + (patchcentres_y[col_I[index.inf.patches.in.fence]] - patchcentres_y[col_I[i]])^2))/alpha))
          
          
        }else{                                     # if patch is not in fence, infection pressure only exerted on others outside fence
          
          ## Compute infectious pressure on susceptible out-of-fence patches ##
          infectiousPressure[(suscPatchNotInFence$col-1)*npatches_x + suscPatchNotInFence$row] <- 
            infectiousPressure[(suscPatchNotInFence$col-1)*npatches_x + suscPatchNotInFence$row] +              # infection pressure on susceptible WB = (infection pressure on susceptible WB) + number of WB in susceptible patch * number of WB in patch [i,j] + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
            nBoarsMatrix[(suscPatchNotInFence$col-1)*npatches_x + suscPatchNotInFence$row] *  numb.inf.boar.in.inf.patches[i] *
            (beta*exp(-(sqrt((patchcentres_x[suscPatchNotInFence$row] - patchcentres_x[row_I[i]])^2 + (patchcentres_y[suscPatchNotInFence$col] - patchcentres_y[col_I[i]])^2))/alpha))
          
          
          
          ## Compute infectious pressure on infected out-of-fence patches ##
          
          # Identify indices of infected patches outside fence 
          index.inf.patches.out.fence <- which(!(LinIdx_I %in% patches.in.fence))
          
          
          infectiousPressure[LinIdx_I[index.inf.patches.out.fence]] <-  infectiousPressure[LinIdx_I[index.inf.patches.out.fence]] +
            numb.susc.boar.in.inf.patches[index.inf.patches.out.fence]* # this gives the number of susceptible boar in these patches
            numb.inf.boar.in.inf.patches[i]*
            (beta*exp(-(sqrt((patchcentres_x[row_I[index.inf.patches.out.fence]] - patchcentres_x[row_I[i]])^2 + (patchcentres_y[col_I[index.inf.patches.out.fence]] - patchcentres_y[col_I[i]])^2))/alpha))
          
        }
        
      }
      
      
    }else{         # IF LESS THAN DAY 60 OR FENCE = FALSE, COMPUTE PRESSURES 'AS USUAL'
      
      for(i in 1:length(row_I)){
        # Compute infectious pressure on susceptible patches
        infectiousPressure[LinIdx] <- infectiousPressure[LinIdx] +              # infection pressure on susceptible patch = (infection pressure on susceptible patch) + number of susceptible WB in susceptible patch * number of infectious WB in infected patch ([i,j]) + beta*exp(-d/alpha), where d = sqrt((S_x - I_x)^2 + (S_y - I_y)^2), where S and I represent the susceptible patch and the infected patch respectively. 
          nBoarsMatrix[LinIdx] * numb.inf.boar.in.inf.patches[i] * 
          beta*exp(-(sqrt((patchcentres_x[row] - patchcentres_x[row_I[i]])^2 + (patchcentres_y[col] - patchcentres_y[col_I[i]])^2))/alpha)
        
        
        # Compute infectious pressure on infectious patches
        infectiousPressure[LinIdx_I] <- infectiousPressure[LinIdx_I] +
          numb.susc.boar.in.inf.patches * numb.inf.boar.in.inf.patches[i] *
          (beta*exp(-(sqrt((patchcentres_x[row_I] - patchcentres_x[row_I[i]])^2 + (patchcentres_y[col_I] - patchcentres_y[col_I[i]])^2))/alpha))
        
        
      }
    }    
    
    ##########################################################################################################'
    ##########################################################################################################'
    
    ## DETERMINE THE NUMBER OF NEW INFECTIONS IN EACH PATCH ##
    
    newInfect <- simulC(lambda = infectiousPressure)      # for all patches, determine how many boar will become infected using the infectious pressure as rate.
    
    ######################################################################################################
    ########  GIVEN NUMBER OF EXPECTED INFECTIONS IN BOAR, CHOOSE THE LOCATION OF BOAR TO INFECT  ########
    
    patches.with.new.inf <- which(newInfect>0)                      # Pick up indices of patches with new infections
    infectionStatusMatrix[patches.with.new.inf] <- 1                # Update infection status of patch in infection Status Matrix.
    
    if(length(patches.with.new.inf) != 0){                          # Only calculate if there are no new infections 
      for(j in 1:length(patches.with.new.inf)){
        susc.boar.within.patch.j <- which(updated.boar$patch==patches.with.new.inf[j] & updated.boar$infectionStatus==0)
        # Choose boar for which no data is available on mode of detection
        
        indexInfect.in.patch.j <- sample(x =  susc.boar.within.patch.j, 
                                         size = min(newInfect[patches.with.new.inf][j], length(susc.boar.within.patch.j)),  # Cannot infect more boar than are susceptible in patch.
                                         replace = F)
        
        locations[locations$index %in% updated.boar[indexInfect.in.patch.j, "index"], c("infectionStatus", "date.infected")] <- c(rep(1, length(indexInfect.in.patch.j)), rep(timings, length(indexInfect.in.patch.j)))
        updated.boar[indexInfect.in.patch.j,  "infectionStatus"] <- rep(1, length(indexInfect.in.patch.j))
        
        
      }                                                                                                                                
      
    }
    
    
    ######################################################################################################
    #######################################  DECREASE BOAR POPULATION  ###################################
    
    # For details on this section, see Removals' section in the summary file.
    
    
    if(increased.pressure){ # that is, timings > 80
      
      ####################
      ### WITHIN ZONE ###
      ####################
      
      # Compute, as a fraction of the remaining boar, the number of boar to be removed 
      number.remove.in.zone <- round(sum(nBoarsMatrix[which(in.fence.buffer.matrix==1)]) * rexp(1, 1/0.01)) # Fractions are the min and max of fractions of remaining boar removed daily, from days 70 to 80, 0.01 to 0.014; observed to be decreasing (from days 1 to 59, fractions ranged between 0.002 and 0.004; from days 61 to 69, 0.01 to 0.017)
      
      # Choice of fraction arbitrary
      boar.in.zone.removed1 <- sample(x = which(updated.boar$patch %in% patches.in.zone), 
                                      size = number.remove.in.zone) # 0.01 of remaining 
      
      if(length(boar.in.zone.removed1) < number.remove.in.zone){
        
        toBeSampled <- x = which(!(updated.boar$index %in% updated.boar[boar.in.zone.removed1, "index"]) & updated.boar$patch %in% patches.in.zone)
        boar.in.zone.removed2 <- sample( x = toBeSampled,
                                         size = min(toBeSampled, number.remove.in.zone - length(boar.in.zone.removed1 )))
        
        
        boar.in.zone.removed <- c(boar.in.zone.removed1,
                                  boar.in.zone.removed2)
      }else{
        boar.in.zone.removed <- boar.in.zone.removed1
      }
      
      
      
      ## DECREASE NUMBERS WITHIN ZONE ##
      
      nBoarsMatrix[which(in.fence.buffer.matrix==1)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==1)], number.remove.in.zone)
      
      
      
      ####################
      ### OUTSIDE ZONE ###
      ####################
      
      
      number.remove.out.zone <- round(sum(nBoarsMatrix[which(in.fence.buffer.matrix==0)]) *  runif(1, 0.001, 0.005)) # ; fractions removed outside zone more variable compared to 'in-zone'. Between days 70 to 80, they range between ~0.004 and ~0.008. 
      
      boar.out.zone.removed <- sample(x = which(!(updated.boar$patch %in% patches.in.zone)), size = number.remove.out.zone) 
      
      
      ## DECREASE NUMBERS OUTSIDE ZONE ##
      
      
      nBoarsMatrix[which(in.fence.buffer.matrix==0)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==0)], number.remove.out.zone)
      
      
      
    }else{ # if increased pressure is FALSE, remove at the observed rates from days 1 to 59. 
      # Timings for this scenario begin at day 60. For increased pressure  = TRUE, timings begin at day 81 if forward.simulation is true.
      
      if(timings > 59 & timings <= 80){
        
        ####################
        ### WITHIN ZONE ###
        ####################
        
        number.remove.in.zone <- round(sum(nBoarsMatrix[which(in.fence.buffer.matrix==1)]) *  runif(1, 0.001, 0.005)) # Fractions indicated are the range of fractions of remaining boar removed daily in the zone, from days 1 to 59
        boar.in.zone.removed <- sample(x = which(updated.boar$patch %in% patches.in.zone), size = number.remove.in.zone) # 0.01 of remaining 
        
        
        ## DECREASE NUMBERS WITHIN ZONE ##
        
        nBoarsMatrix[which(in.fence.buffer.matrix==1)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==1)], number.remove.in.zone)
        
        
        
        
        ####################
        ### OUTSIDE ZONE ###
        ####################
        
        
        ## Remove hunted and found boar as in data and as predicted by model
        
        toBeSampled1.out.zone <- which(updated.boar$infectionStatus == 1 & !(updated.boar$patch %in% patches.in.zone) & updated.boar$patch %in% updated.boar$patch[updated.boar$date.removed == timings & updated.boar$det %in% c("AS", "NAS", "PS")])
        set1.out.zone <- sample(x = toBeSampled1.out.zone,
                                size = min(removals$out.zone.found[timings], length(toBeSampled1.out.zone)),
                                replace = F)
        
        
        
        if(length(set1.out.zone) < removals$out.zone[timings]){ # If sum of identified removals is less than expected total removals, 
          toBeSampled.out.zone <- which(!(updated.boar$index %in% updated.boar[set1.out.zone, "index"]) & !(updated.boar$patch %in% patches.in.zone))
          
          set2.out.zone <- sample(x = toBeSampled.out.zone,
                                  size = min(length(toBeSampled.out.zone), removals$out.zone[timings] - length(set1.out.zone)), 
                                  replace = F)
          
          
          # Save indices of removed boar
          boar.out.zone.removed <- c(set1.out.zone, set2.out.zone)         
          
        }else{
          
          boar.out.zone.removed <- set1.out.zone
          
        } 
        
        
        ## DECREASE NUMBERS OUTSIDE ZONE ##
        
        nBoarsMatrix[which(in.fence.buffer.matrix==0)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==0)], removals$out.zone[timings])
        
        
        
        
      }else{ # if timings > 80 
        
        
        ####################
        ### WITHIN ZONE ###
        ####################
        
        
        
        number.remove.in.zone <- round(sum(nBoarsMatrix[which(in.fence.buffer.matrix==1)]) * runif(1, 0.001, 0.005)) # Fractions indicated are the range of fractions of remaining boar removed daily in the zone , from days 1 to 59
        boar.in.zone.removed <- sample(x = which(updated.boar$patch %in% patches.in.zone), size = number.remove.in.zone) # 0.01 of remaining 
        
        
        ## DECREASE NUMBERS WITHIN ZONE ##
        
        nBoarsMatrix[which(in.fence.buffer.matrix==1)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==1)], number.remove.in.zone)
        
        
        
        ####################
        ### OUTSIDE ZONE ###
        ####################
        
        
        number.remove.out.zone <- round(sum(nBoarsMatrix[which(in.fence.buffer.matrix==0)]) * runif(1, 0.001, 0.005)) #  Fractions indicated are the range of fractions of remaining boar removed daily outside the zone, from days 70 to 80. The range from days 1 to 59 is 0.001 and 0.005
        
        boar.out.zone.removed <- sample(x = which(!(updated.boar$patch %in% patches.in.zone)), size = number.remove.out.zone) 
        
        
        ## DECREASE NUMBERS OUTSIDE ZONE ##
        
        
        nBoarsMatrix[which(in.fence.buffer.matrix==0)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==0)], number.remove.out.zone)
        
        
      }
    }
    
    
    
    boar.removed <- c(boar.in.zone.removed,
                      boar.out.zone.removed)
    
    ## RECORD THE REMOVAL DATES OF BOAR ##
    
    locations[locations$index %in% updated.boar[c(boar.removed), "index"],  "date.removed2"] <- timings
    
    
    
    ## RECORD THE NUMBER OF DETECTED POSITIVE BOAR AMONG REMOVED BOAR ##
    
    
    found.out.zone <- sum(updated.boar$infectionStatus[boar.removed] == 1 & updated.boar$det[boar.removed] %in% c("AS", "PS") & !(updated.boar$patch[boar.removed] %in% patches.in.zone))
    wildBoarVals[recNumHere] <-  sum(updated.boar$infectionStatus[boar.in.zone.removed] == 1) + (found.out.zone + round((sum(updated.boar$infectionStatus[boar.out.zone.removed] == 1) - found.out.zone)*hunt.test.prop)) # First term: all positive boar removed in zone (100% of hunted tested, all found boar are reportedr); Second term: positive boar removed outside zone (20% of hunted tested, none found)
    
    
    # For the normal hunting pressure scenario, we are assuming that all hunted boar in the fenced area are tested as they are in the baseline scenario. 
    
    
    statusEachTimeStep[[recNumHere]] <- infectionStatusMatrix
    
    
    ### UPDATE INFECTION STATUS MATRIX 
    ### UPDATE BOAR NUMBERS BY LOCATIONS 
    
    # Assign 0 to patches with no infected boar
    updated.boar <- updated.boar[-boar.removed, ]
    pos.patches <- unique(updated.boar$patch[updated.boar$infectionStatus>0])
    infectionStatusMatrix[!(patch.ids %in% pos.patches)] <- 0 
    
    ## RECORD TIME ##
    
    timeVals[recNumHere] <- timings
    
    # Removals occur at the end of day t coinciding with the start of day t+1
    
    ## UPDATE BOAR NUMBERS ##
    
    
    
    ######################################################################################################
    #######################################  UPDATE COUNTER #################################################
    
    if(verbose){cat('t =', timings, ';' , "W=", sum(wildBoarVals), "\n")}
    # Update time 
    timings <-  timings + dt 
    
    # Update iteration number
    
    recNumHere <- recNumHere + 1  
    
    
  }
  
  #[length(wildBoarVals)]
  
  ###########################                                           ###############################################################################
  ############################# SHOW SIMULATION PROGRESS & ORGANIZE DATA ##################################
  
  
  df <- as_tibble(data.frame("day" = timeVals, "new.cases.wb" = wildBoarVals,  "cumulative.cases.wb" = cumsum(wildBoarVals)))
  # df <- df %>% mutate(new.cases.wb = cumulative.cases.wb - c(0, head(cumulative.cases.wb, -1)))# calculate daily cases from cumulative. 
  
  return(list(summarized.res = df, status.matrices = statusEachTimeStep, locations = locations))  
}
