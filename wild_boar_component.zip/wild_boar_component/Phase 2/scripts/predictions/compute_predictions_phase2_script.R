###########################################
# AFRICAN SWINE FEVER MODEL FOR WILD BOAR #
#      ASF CHALLENGE - UK TEAM            #
#                                         #
# Compute projections for Phase 2 (day 81-
#    110 under various scenarios          #
###########################################



### SET UP  ####

# Load packages # 
library(parallel)
library(glue)
library(dplyr)

# Specify directories #
wd.output.data <- "./output-data/"    # Directory for output data 


# Load input data #
source("./scripts/run model/preamble_data_model_phase2.R")             


# Load model #

source("./scripts/prediction/prediction_model_phase2.R")                    


# Load functions #

source("./scripts/functions/all_functions_phase2.R")  


# Load parameter estimates #

res <- readRDS(file = "./output-data/parameter estimates/param_estims_phase2.RDS")


# Update matrix to match day 60 (for each patch, subtract the number of boar removed up to day 59)
#nBoarsMatrix <- nBoarsMatrix_full
nBoarsMatrix[which(in.fence.buffer.matrix==0)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==0)], cumsum(removals$out.zone)[59]) 
nBoarsMatrix[which(in.fence.buffer.matrix==1)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==1)], cumsum(removals$in.zone)[59])
nBoarsMatrix.i <- nBoarsMatrix




##### SCENARIOS #####



# ## Fence and increased hunting pressure (day 81-day 110) ##
# 
# # Compute the number of boar remaining in the island by day 81.
nBoarsMatrix[which(in.fence.buffer.matrix==0)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==0)], sum(removals$out.zone))
nBoarsMatrix[which(in.fence.buffer.matrix==1)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==1)], sum(removals$in.zone))
#nBoarsMatrix.i <- nBoarsMatrix

# ## Check that
 sum(nBoarsMatrix) == nrow(locations) - sum(removals$total[1:80])
# 
# 
# # Create list to save outputs
# forward.run.increased.pressure.110 <- list()
# 
# 
for(i in 1:nrow(res$estims)){

print(i)  # Show progress of simulation
# Obtain infection information at day 80, as predicted by accepted simulations
locations <- res$locations[[i]]             # Boar locations and infection statuses
infectionStatusMatrix <- res$mat[[i]][[80]] # Patch infection statuses


# Run model forwards to day 110
res_i <- prediction_model_phase2(beta = res$estims[i, ],
                                 alpha = 870,
                                 timings = 81,
                                 timings.max = 110,
                                 fence = TRUE,
                                 forward.simulation = TRUE,
                                 increased.pressure = TRUE,
                                 verbose = T)
                              #   nBoarsMatrix = nBoarsMatrix.i)

forward.run.increased.pressure.110$time.series[[i]] <- res_i$summarized.res
forward.run.increased.pressure.110$status.matrices[[i]] <- res_i$status.matrices
forward.run.increased.pressure.110$locations[[i]] <- res_i$locations


}

# rm(list = setdiff(ls(), "forward.run.increased.pressure.110"))
# # Save predictions
saveRDS(forward.run.increased.pressure.110, file =  glue(wd.output.data, "predictions/forward.run.increased.pressure.110.RDS"))









## Fence and normal hunting pressure (day 80 - day 110) ##
 
# # # The reference date for predictions for the normal hunting pressure scenario is 
# # # day 60, since day 59 was the last day of observation for this scenario. 
# 
# 
# # Compute the number of boar remaining by day 60
nBoarsMatrix <- nBoarsMatrix_full
nBoarsMatrix[which(in.fence.buffer.matrix==0)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==0)], cumsum(removals$out.zone)[59])
nBoarsMatrix[which(in.fence.buffer.matrix==1)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==1)], cumsum(removals$in.zone)[59])


# 
# # Create list to save outputs
forward.run.normal.pressure.110 <- list()
# 
# 
for(i in 1:500){
  print(i)

  locations <- res$locations[[i]]             # Boar locations and infection statuses
  infectionStatusMatrix <- res$mat[[i]][[59]] # Patch infection statuses


  res_i <- prediction_model_phase2(beta = res$estims[i, ],
                                   alpha = 870,
                                   timings = 60,
                                   timings.max = 140,
                                   fence = TRUE,
                                   forward.simulation = TRUE,
                                   increased.pressure = FALSE,
                                   verbose = F)
                                #   nBoarsMatrix = nBoarsMatrix.i)

  forward.run.normal.pressure.110$time.series[[i]] <- res_i$summarized.res
  forward.run.normal.pressure.110$status.matrices[[i]] <- res_i$status.matrices
  forward.run.normal.pressure.110$locations[[i]] <- res_i$locations

}


#rm(list = setdiff(ls(), "forward.run.normal.pressure.110"))


# Save predictions
saveRDS(forward.run.normal.pressure.110, file =  glue(wd.output.data, "predictions/forward.run.normal.pressure.110.RDS"))











# ### Normal hunting pressure (to day 140) ###
#
#
# # For predictions to day 140, only the increased hunting pressure scenario was considered.
# The model was run forwards using predictions from the increased hunting pressure scenario at day 140.

# Create list to store forward simulations
forward.run.normal.pressure.140 <- list()
#

for(i in 1:500){
  
  print(i)
  
  
  locations.i <- res$locations[[i]]             # Boar locations and infection statuses
  infectionStatusMatrix.i <- res$mat[[i]][[59]] # Patch infection statuse
  
  
  ## Obtain status at day 140 ##
  
  # Locations matrix at day 140
  locations.i <- forward.run.normal.pressure.110$locations[[i]]
  
  # Assign transition dates to infected boar, as these are deterministic and not saved during the simulation
  locations.i$infectionStatus[locations.i$date.infected>=(140-4)] <- 1
  locations.i$date.death.recovery[locations.i$infectionStatus==1] <- locations.i$date.infected[locations.i$infectionStatus==1]+ 14
  
  
  # Infection status matrix at day 110
  infectionStatusMatrix.i <- forward.run.normal.pressure.110$status.matrices[[i]][[(110-81)+1]]
  
  
  # Boar count at day 110
  nBoarsMatrix <- nBoarsMatrix_full
  nBoarsMatrix[which(in.fence.buffer.matrix==0)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==0)], sum(removals$out.zone.removed) + sum(locations.i$date.removed2>=81 & locations.i$date.removed2 <= 110 & !(locations.i$patch %in%  which(in.fence.buffer.matrix==1))))
  
  nBoarsMatrix[which(in.fence.buffer.matrix==1)] <- update.boar.numbers(nBoarsMatrix[which(in.fence.buffer.matrix==1)], sum(removals$in.zone.removed) +  sum(locations.i$date.removed2>=81 & locations.i$date.removed2 <= 110  & (locations.i$patch %in%  which(in.fence.buffer.matrix==1))))
  
  nBoarsMatrix.i <- nBoarsMatrix
  
  
  # Run model forwards to day 140; see
  res_i <- prediction_model_phase2(beta = res$estims[i, ],
                                   alpha = 1000,
                                   timings = 60,
                                   timings.max = 140,
                                   fence = TRUE,
                                   forward.simulation = TRUE,
                                   increased.pressure = FALSE,
                                   verbose = F,
                                   locations = locations.i,
                                   infectionStatusMatrix = infectionStatusMatrix.i,
                                   nBoarsMatrix = nBoarsMatrix.i,
                                   normal.pressure.reference.date = 60)
  
  
  forward.run.normal.pressure.140$time.series[[i]] <- res_i$summarized.res
  forward.run.normal.pressure.140$status.matrices[[i]] <- res_i$status.matrices
  forward.run.normal.pressure.140$locations[[i]] <- res_i$locations
  
}

rm(list = setdiff(ls(), "forward.run.normal.pressure.140"))
# Save predictions
saveRDS(forward.run.normal.pressure.140, file =  glue(wd.output.data, "predictions/forward.run.normal.pressure.140.RDS"))





